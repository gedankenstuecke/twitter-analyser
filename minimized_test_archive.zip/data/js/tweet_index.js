var tweet_index =  [ {
  "file_name" : "data\/js\/tweets\/2009_01.js",
  "year" : 2009,
  "var_name" : "tweets_2009_01",
  "tweet_count" : 885,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2008_12.js",
  "year" : 2008,
  "var_name" : "tweets_2008_12",
  "tweet_count" : 527,
  "month" : 12
} ]

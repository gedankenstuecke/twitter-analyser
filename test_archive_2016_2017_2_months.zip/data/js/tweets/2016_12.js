Grailbird.data.tweets_2016_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/815272172390383621\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/6EzMZmQwqG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C1BtuCaXEAARSnm.jpg",
      "id_str" : "815272170242904064",
      "id" : 815272170242904064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1BtuCaXEAARSnm.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/6EzMZmQwqG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815272172390383621",
  "text" : "It's that day of the year again when the two cats sandwich the pillow. https:\/\/t.co\/6EzMZmQwqG",
  "id" : 815272172390383621,
  "created_at" : "2016-12-31 19:03:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Lumley",
      "screen_name" : "tslumley",
      "indices" : [ 3, 12 ],
      "id_str" : "1168003974",
      "id" : 1168003974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/L80PjTOBna",
      "expanded_url" : "http:\/\/notstatschat.tumblr.com\/post\/155194690691\/the-iris-data",
      "display_url" : "notstatschat.tumblr.com\/post\/155194690\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "815234730761261058",
  "text" : "RT @tslumley: I wrote a rantlet about the 'iris' data and fake questions\nhttps:\/\/t.co\/L80PjTOBna",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/L80PjTOBna",
        "expanded_url" : "http:\/\/notstatschat.tumblr.com\/post\/155194690691\/the-iris-data",
        "display_url" : "notstatschat.tumblr.com\/post\/155194690\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "815064913311764480",
    "text" : "I wrote a rantlet about the 'iris' data and fake questions\nhttps:\/\/t.co\/L80PjTOBna",
    "id" : 815064913311764480,
    "created_at" : "2016-12-31 05:19:53 +0000",
    "user" : {
      "name" : "Thomas Lumley",
      "screen_name" : "tslumley",
      "protected" : false,
      "id_str" : "1168003974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3237872431\/07ecae166f2898fc9da007a5de720cb3_normal.jpeg",
      "id" : 1168003974,
      "verified" : false
    }
  },
  "id" : 815234730761261058,
  "created_at" : "2016-12-31 16:34:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shireen Mitchell the original",
      "screen_name" : "digitalsista",
      "indices" : [ 89, 102 ],
      "id_str" : "14268957",
      "id" : 14268957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/q4krnA2E35",
      "expanded_url" : "https:\/\/medium.com\/athena-talks\/tech-companies-have-enabled-harassment-and-racism-instead-of-ending-it-heres-how-cd94e0b59c7?source=twitterShare-aaeb714c1b80-1483195744",
      "display_url" : "medium.com\/athena-talks\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "815208186726780928",
  "text" : "\u201CTech companies have enabled harassment and racism instead of ending it. Here\u2019s how.\u201D by @digitalsista https:\/\/t.co\/q4krnA2E35",
  "id" : 815208186726780928,
  "created_at" : "2016-12-31 14:49:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/wcJdgm5LPl",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BOqCSsijux6\/",
      "display_url" : "instagram.com\/p\/BOqCSsijux6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "814950164792299525",
  "text" : "\uD83D\uDC36 (best \uD83C\uDF84 gift ever) https:\/\/t.co\/wcJdgm5LPl",
  "id" : 814950164792299525,
  "created_at" : "2016-12-30 21:43:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/WJ8Xs6RCm7",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BOqBe4LD-pI\/",
      "display_url" : "instagram.com\/p\/BOqBe4LD-pI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "814948390165479424",
  "text" : "Homewards https:\/\/t.co\/WJ8Xs6RCm7",
  "id" : 814948390165479424,
  "created_at" : "2016-12-30 21:36:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 26, 35 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 40, 53 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/aLEUjdvYPr",
      "expanded_url" : "https:\/\/twitter.com\/MsPhelps\/status\/814581004388225024",
      "display_url" : "twitter.com\/MsPhelps\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "814581004388225024",
  "geo" : { },
  "id_str" : "814833025804595200",
  "in_reply_to_user_id" : 22963112,
  "text" : "Always a pleasure to help @MsPhelps and @jeroenbosman in visualizing the usage of scholarly communication tools! https:\/\/t.co\/aLEUjdvYPr",
  "id" : 814833025804595200,
  "in_reply_to_status_id" : 814581004388225024,
  "created_at" : "2016-12-30 13:58:26 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814633319165992960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403798395176, 8.753416173734928 ]
  },
  "id_str" : "814790773837283329",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute let me know when in march, so I can help :D",
  "id" : 814790773837283329,
  "in_reply_to_status_id" : 814633319165992960,
  "created_at" : "2016-12-30 11:10:33 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814616382096740355",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403808752576, 8.753415519444024 ]
  },
  "id_str" : "814630742948986880",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute damn it. And I\u2019m slacking off at home. Wish I\u2019d be there! When will you be back in Z\u00FCrich?",
  "id" : 814630742948986880,
  "in_reply_to_status_id" : 814616382096740355,
  "created_at" : "2016-12-30 00:34:38 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josefine",
      "screen_name" : "josefine",
      "indices" : [ 0, 9 ],
      "id_str" : "14054240",
      "id" : 14054240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814517888291930113",
  "geo" : { },
  "id_str" : "814518947978637312",
  "in_reply_to_user_id" : 14054240,
  "text" : "@josefine Ich werd also besser nicht die Luft anhalten bis es aufh\u00F6rt zu meckern \uD83D\uDE02",
  "id" : 814518947978637312,
  "in_reply_to_status_id" : 814517888291930113,
  "created_at" : "2016-12-29 17:10:24 +0000",
  "in_reply_to_screen_name" : "josefine",
  "in_reply_to_user_id_str" : "14054240",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josefine",
      "screen_name" : "josefine",
      "indices" : [ 0, 9 ],
      "id_str" : "14054240",
      "id" : 14054240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814516803049320454",
  "geo" : { },
  "id_str" : "814516972125818880",
  "in_reply_to_user_id" : 14054240,
  "text" : "@josefine eins k\u00F6nnte ja erwarten das Mac OS die Warnungen irgendwann frustriert aufgibt. :p",
  "id" : 814516972125818880,
  "in_reply_to_status_id" : 814516803049320454,
  "created_at" : "2016-12-29 17:02:33 +0000",
  "in_reply_to_screen_name" : "josefine",
  "in_reply_to_user_id_str" : "14054240",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/814514920960229376\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/lc0H3l8PQW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C0289nQWgAAcQ-0.jpg",
      "id_str" : "814514874319536128",
      "id" : 814514874319536128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0289nQWgAAcQ-0.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/lc0H3l8PQW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233761576443, 8.627636140553513 ]
  },
  "id_str" : "814514920960229376",
  "text" : "On a good note, I did find the computer that stores all my old photos. On the other hand\u2026 https:\/\/t.co\/lc0H3l8PQW",
  "id" : 814514920960229376,
  "created_at" : "2016-12-29 16:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/tbFHXlGc1j",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/gedankenstuecke\/116390387\/",
      "display_url" : "flickr.com\/photos\/gedanke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "814457801749786625",
  "text" : "I totally forgot that I already did Bioinformatics back in 2006. Petty sure this qualifies, right? https:\/\/t.co\/tbFHXlGc1j",
  "id" : 814457801749786625,
  "created_at" : "2016-12-29 13:07:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/gIfxB58f6I",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/814417389676732416",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "814429978532151296",
  "text" : "Reminds me: Does anyone have recommendations for female tattoo artists in\/around Frankfurt? https:\/\/t.co\/gIfxB58f6I",
  "id" : 814429978532151296,
  "created_at" : "2016-12-29 11:16:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 0, 10 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 11, 25 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 26, 34 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/2rs2l1CabA",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Photo_51",
      "display_url" : "en.m.wikipedia.org\/wiki\/Photo_51"
    } ]
  },
  "in_reply_to_status_id_str" : "814404260783759360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403867682244, 8.753420235418941 ]
  },
  "id_str" : "814404758375137280",
  "in_reply_to_user_id" : 734667419055230976,
  "text" : "@l_matthia @Protohedgehog @mbeisen made my first inquiries to get https:\/\/t.co\/2rs2l1CabA done last week!",
  "id" : 814404758375137280,
  "in_reply_to_status_id" : 814404260783759360,
  "created_at" : "2016-12-29 09:36:39 +0000",
  "in_reply_to_screen_name" : "l_matthia",
  "in_reply_to_user_id_str" : "734667419055230976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403399795763, 8.753418776212309 ]
  },
  "id_str" : "814246798705520640",
  "text" : "\u00ABEverything is ill-lubricated\u2026\u00BB \u2014 \u00ABIs that the porn parody of the Jonathan Safran Foer book?\u00BB",
  "id" : 814246798705520640,
  "created_at" : "2016-12-28 23:08:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 69, 75 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/oxcSDr7gBG",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/And_the_Band_Played_On_(film)",
      "display_url" : "en.wikipedia.org\/wiki\/And_the_B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "814065057470484480",
  "text" : "Finally saw the movie adaptation of \u2018And the Band Played On\u2019. Thanks @ozaed for hinting me to it! https:\/\/t.co\/oxcSDr7gBG",
  "id" : 814065057470484480,
  "created_at" : "2016-12-28 11:06:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 15, 28 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/814054985600290817\/photo\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/4nnGONbyfd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C0waqo2XcAAq6nh.jpg",
      "id_str" : "814054952469491712",
      "id" : 814054952469491712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0waqo2XcAAq6nh.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/4nnGONbyfd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395619479608, 8.753627990915072 ]
  },
  "id_str" : "814054985600290817",
  "text" : "Also thanks to @repositiveio, the cute \uD83E\uDD8E always makes me happy when I see it. You should to stuffed animals of it. \uD83C\uDF84\uD83C\uDF81\uD83C\uDF89 https:\/\/t.co\/4nnGONbyfd",
  "id" : 814054985600290817,
  "created_at" : "2016-12-28 10:26:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vin\u24EAdh Ilang\u24EAvan",
      "screen_name" : "InquisitiveVi",
      "indices" : [ 36, 50 ],
      "id_str" : "3443391621",
      "id" : 3443391621
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/814054539502514176\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/8WPMynmPj9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C0waP6_WgAAuchR.jpg",
      "id_str" : "814054493482549248",
      "id" : 814054493482549248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0waP6_WgAAuchR.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/8WPMynmPj9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395619479608, 8.753627990915072 ]
  },
  "id_str" : "814054539502514176",
  "text" : "Thanks so much for the holiday card @InquisitiveVi! \uD83C\uDF89\uD83C\uDF84 https:\/\/t.co\/8WPMynmPj9",
  "id" : 814054539502514176,
  "created_at" : "2016-12-28 10:25:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/813793432112136192\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/ql7j5SUHE1",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C0sszqLXcAE9CKv.jpg",
      "id_str" : "813793423677419521",
      "id" : 813793423677419521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C0sszqLXcAE9CKv.jpg",
      "sizes" : [ {
        "h" : 258,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/ql7j5SUHE1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813791959819042816",
  "geo" : { },
  "id_str" : "813793432112136192",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @beaugunderson so, whom shall we donate to this year? https:\/\/t.co\/ql7j5SUHE1",
  "id" : 813793432112136192,
  "in_reply_to_status_id" : 813791959819042816,
  "created_at" : "2016-12-27 17:07:28 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R-Ladies SF",
      "screen_name" : "RLadiesSF",
      "indices" : [ 3, 13 ],
      "id_str" : "881530736",
      "id" : 881530736
    }, {
      "name" : "useR!2017",
      "screen_name" : "useR_Brussels",
      "indices" : [ 76, 90 ],
      "id_str" : "736216890662658048",
      "id" : 736216890662658048
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "useR2017",
      "indices" : [ 55, 64 ]
    }, {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813791624140623876",
  "text" : "RT @RLadiesSF: This is amazing! Childcare available at #useR2017. Thank you @UseR_Brussels! Hopefully setting a new #rstats conference stan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "useR!2017",
        "screen_name" : "useR_Brussels",
        "indices" : [ 61, 75 ],
        "id_str" : "736216890662658048",
        "id" : 736216890662658048
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RLadiesSF\/status\/813773057248477184\/photo\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/wa7D3BgCCt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C0saR3FVIAAdQAL.jpg",
        "id_str" : "813773051816910848",
        "id" : 813773051816910848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0saR3FVIAAdQAL.jpg",
        "sizes" : [ {
          "h" : 479,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/wa7D3BgCCt"
      } ],
      "hashtags" : [ {
        "text" : "useR2017",
        "indices" : [ 40, 49 ]
      }, {
        "text" : "rstats",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "813773057248477184",
    "text" : "This is amazing! Childcare available at #useR2017. Thank you @UseR_Brussels! Hopefully setting a new #rstats conference standard. \uD83D\uDCAA\uD83D\uDC9C\uD83D\uDC4F https:\/\/t.co\/wa7D3BgCCt",
    "id" : 813773057248477184,
    "created_at" : "2016-12-27 15:46:30 +0000",
    "user" : {
      "name" : "R-Ladies SF",
      "screen_name" : "RLadiesSF",
      "protected" : false,
      "id_str" : "881530736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/805889784593805312\/n4tIxCsW_normal.jpg",
      "id" : 881530736,
      "verified" : false
    }
  },
  "id" : 813791624140623876,
  "created_at" : "2016-12-27 17:00:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 0, 15 ],
      "id_str" : "173968705",
      "id" : 173968705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813763522849079296",
  "geo" : { },
  "id_str" : "813763803393495041",
  "in_reply_to_user_id" : 173968705,
  "text" : "@professor_dave Thank you, great talk! And hearing that you\u2019ll be there in January just doubled my nervousness levels! \uD83D\uDE02",
  "id" : 813763803393495041,
  "in_reply_to_status_id" : 813763522849079296,
  "created_at" : "2016-12-27 15:09:44 +0000",
  "in_reply_to_screen_name" : "professor_dave",
  "in_reply_to_user_id_str" : "173968705",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 8, 23 ],
      "id_str" : "173968705",
      "id" : 173968705
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar",
      "indices" : [ 46, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/PyBPcramZ1",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=8p937rh2xBY&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=8p937r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813745461370769408",
  "text" : "Watched @professor_dave\u2019s keynote of the last #LGBTSTEMinar before preparing mine. Hard to follow in his footsteps! https:\/\/t.co\/PyBPcramZ1",
  "id" : 813745461370769408,
  "created_at" : "2016-12-27 13:56:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/E4uukm9I6I",
      "expanded_url" : "https:\/\/hackernoon.com\/a-guide-to-giving-your-cats-their-annual-performance-review-fbf14610305?source=twitterShare-aaeb714c1b80-1482842122",
      "display_url" : "hackernoon.com\/a-guide-to-giv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813725250886176769",
  "text" : "I feel my cats get simpler performance reviews: \u00ABMade me step in their vomit 15 times. Well done, there's the bonus\u00BB https:\/\/t.co\/E4uukm9I6I",
  "id" : 813725250886176769,
  "created_at" : "2016-12-27 12:36:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Kalven",
      "screen_name" : "kalven",
      "indices" : [ 3, 10 ],
      "id_str" : "18659273",
      "id" : 18659273
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kalven\/status\/810244096577015808\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/kAQcGSSzGn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cz6QtdNXAAIqSp5.jpg",
      "id_str" : "810244093582442498",
      "id" : 810244093582442498,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cz6QtdNXAAIqSp5.jpg",
      "sizes" : [ {
        "h" : 911,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1016,
        "resize" : "fit",
        "w" : 1338
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1016,
        "resize" : "fit",
        "w" : 1338
      } ],
      "display_url" : "pic.twitter.com\/kAQcGSSzGn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/scGx74BeWO",
      "expanded_url" : "http:\/\/buff.ly\/2hTxSQq",
      "display_url" : "buff.ly\/2hTxSQq"
    } ]
  },
  "geo" : { },
  "id_str" : "813722588593655808",
  "text" : "RT @kalven: My dad on fighting the urge to become an \"internal emigre\" in the age of Trump: https:\/\/t.co\/scGx74BeWO https:\/\/t.co\/kAQcGSSzGn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kalven\/status\/810244096577015808\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/kAQcGSSzGn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cz6QtdNXAAIqSp5.jpg",
        "id_str" : "810244093582442498",
        "id" : 810244093582442498,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cz6QtdNXAAIqSp5.jpg",
        "sizes" : [ {
          "h" : 911,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1016,
          "resize" : "fit",
          "w" : 1338
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1016,
          "resize" : "fit",
          "w" : 1338
        } ],
        "display_url" : "pic.twitter.com\/kAQcGSSzGn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/scGx74BeWO",
        "expanded_url" : "http:\/\/buff.ly\/2hTxSQq",
        "display_url" : "buff.ly\/2hTxSQq"
      } ]
    },
    "geo" : { },
    "id_str" : "810244096577015808",
    "text" : "My dad on fighting the urge to become an \"internal emigre\" in the age of Trump: https:\/\/t.co\/scGx74BeWO https:\/\/t.co\/kAQcGSSzGn",
    "id" : 810244096577015808,
    "created_at" : "2016-12-17 22:03:40 +0000",
    "user" : {
      "name" : "Josh Kalven",
      "screen_name" : "kalven",
      "protected" : false,
      "id_str" : "18659273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616358981523542016\/5CO0hpJD_normal.jpg",
      "id" : 18659273,
      "verified" : false
    }
  },
  "id" : 813722588593655808,
  "created_at" : "2016-12-27 12:25:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10967883286077, 8.761923909195477 ]
  },
  "id_str" : "813702132494958592",
  "text" : "Filed my request for a new passport. \uD83C\uDF89",
  "id" : 813702132494958592,
  "created_at" : "2016-12-27 11:04:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/zYSVGiHrlZ",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/political-philosophy",
      "display_url" : "smbc-comics.com\/comic\/politica\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813696542595022848",
  "text" : "Political Philosophy https:\/\/t.co\/zYSVGiHrlZ",
  "id" : 813696542595022848,
  "created_at" : "2016-12-27 10:42:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scholastica",
      "screen_name" : "scholasticahq",
      "indices" : [ 3, 17 ],
      "id_str" : "270546697",
      "id" : 270546697
    }, {
      "name" : "ScienceOpen",
      "screen_name" : "Science_Open",
      "indices" : [ 100, 113 ],
      "id_str" : "1246397209",
      "id" : 1246397209
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 114, 130 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenResearch",
      "indices" : [ 29, 42 ]
    }, {
      "text" : "openscience",
      "indices" : [ 131, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/7asTQJt6tl",
      "expanded_url" : "http:\/\/bit.ly\/2hsH8e3",
      "display_url" : "bit.ly\/2hsH8e3"
    } ]
  },
  "geo" : { },
  "id_str" : "813695119438311424",
  "text" : "RT @scholasticahq: Advancing #OpenResearch - Q&amp;A with Bastian Greshake: https:\/\/t.co\/7asTQJt6tl @Science_Open @gedankenstuecke #openscience\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ScienceOpen",
        "screen_name" : "Science_Open",
        "indices" : [ 81, 94 ],
        "id_str" : "1246397209",
        "id" : 1246397209
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 95, 111 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenResearch",
        "indices" : [ 10, 23 ]
      }, {
        "text" : "openscience",
        "indices" : [ 112, 124 ]
      }, {
        "text" : "OA",
        "indices" : [ 125, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/7asTQJt6tl",
        "expanded_url" : "http:\/\/bit.ly\/2hsH8e3",
        "display_url" : "bit.ly\/2hsH8e3"
      } ]
    },
    "geo" : { },
    "id_str" : "813453326692052997",
    "text" : "Advancing #OpenResearch - Q&amp;A with Bastian Greshake: https:\/\/t.co\/7asTQJt6tl @Science_Open @gedankenstuecke #openscience #OA",
    "id" : 813453326692052997,
    "created_at" : "2016-12-26 18:36:00 +0000",
    "user" : {
      "name" : "scholastica",
      "screen_name" : "scholasticahq",
      "protected" : false,
      "id_str" : "270546697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455833465636651008\/6leKIXzy_normal.jpeg",
      "id" : 270546697,
      "verified" : false
    }
  },
  "id" : 813695119438311424,
  "created_at" : "2016-12-27 10:36:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/ZHECHUQDcX",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=lUARpT4JJew",
      "display_url" : "m.youtube.com\/watch?v=lUARpT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813359537596071936",
  "text" : "For the Christmas Reading https:\/\/t.co\/ZHECHUQDcX",
  "id" : 813359537596071936,
  "created_at" : "2016-12-26 12:23:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813204572206407681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403335091933, 8.753423853936393 ]
  },
  "id_str" : "813292659024470016",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna aww, Danke. Und frohe Weihnachten \uD83C\uDF81\uD83C\uDF84\uD83D\uDE18",
  "id" : 813292659024470016,
  "in_reply_to_status_id" : 813204572206407681,
  "created_at" : "2016-12-26 07:57:34 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397216104307, 8.75354546442926 ]
  },
  "id_str" : "813153812949204992",
  "text" : "Our Chrismukkah dinner covered largely agnostic participants from \uD83C\uDDF2\uD83C\uDDFD\uD83C\uDDEE\uD83C\uDDF7\uD83C\uDDE9\uD83C\uDDEA\uD83C\uDDEC\uD83C\uDDF7 and 2 1\/2 different cuisines. \uD83D\uDC96\uD83C\uDF84\uD83D\uDCA1\uD83E\uDD59\uD83C\uDF5C\uD83C\uDF70",
  "id" : 813153812949204992,
  "created_at" : "2016-12-25 22:45:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812693920702402560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403323736685, 8.75341803427175 ]
  },
  "id_str" : "812706936667996160",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb that\u2019s awesome. I love her work so much \uD83D\uDE0D",
  "id" : 812706936667996160,
  "in_reply_to_status_id" : 812693920702402560,
  "created_at" : "2016-12-24 17:10:07 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/jw9KxIWq5c",
      "expanded_url" : "http:\/\/www.theallusionist.org\/allusionist\/winterval",
      "display_url" : "theallusionist.org\/allusionist\/wi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395887802049, 8.753571501722854 ]
  },
  "id_str" : "812692292112941056",
  "text" : "\u05D7\u05E0\u05D5\u05DB\u05D4 \u05E9\u05DE\u05D7, merry Christmas and an awesome Winterval, you all! https:\/\/t.co\/jw9KxIWq5c \uD83D\uDCA1\uD83C\uDF84",
  "id" : 812692292112941056,
  "created_at" : "2016-12-24 16:11:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812611186713915392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403265123665, 8.753423489212254 ]
  },
  "id_str" : "812673700969455616",
  "in_reply_to_user_id" : 2968079445,
  "text" : "@AnneAdamPluen \uD83D\uDC96\uD83D\uDC98\uD83D\uDC4D",
  "id" : 812673700969455616,
  "in_reply_to_status_id" : 812611186713915392,
  "created_at" : "2016-12-24 14:58:03 +0000",
  "in_reply_to_screen_name" : "AnneHTTP404",
  "in_reply_to_user_id_str" : "2968079445",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 3, 16 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/neuroecology\/status\/812367945909334017\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/q3oMxGdqoE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C0YcPObWIAEUtTw.jpg",
      "id_str" : "812367830683361281",
      "id" : 812367830683361281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0YcPObWIAEUtTw.jpg",
      "sizes" : [ {
        "h" : 119,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 119,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 119,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 119,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 119,
        "resize" : "crop",
        "w" : 119
      } ],
      "display_url" : "pic.twitter.com\/q3oMxGdqoE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Fm45tNv9Sb",
      "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/dec\/22\/why-time-management-is-ruining-our-lives",
      "display_url" : "theguardian.com\/technology\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "812570202802126852",
  "text" : "RT @neuroecology: The average life is only 4000 weeks\n\nholy fuck what am i doing\n\nhttps:\/\/t.co\/Fm45tNv9Sb https:\/\/t.co\/q3oMxGdqoE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/neuroecology\/status\/812367945909334017\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/q3oMxGdqoE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C0YcPObWIAEUtTw.jpg",
        "id_str" : "812367830683361281",
        "id" : 812367830683361281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0YcPObWIAEUtTw.jpg",
        "sizes" : [ {
          "h" : 119,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 119,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 119,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 119,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 119,
          "resize" : "crop",
          "w" : 119
        } ],
        "display_url" : "pic.twitter.com\/q3oMxGdqoE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/Fm45tNv9Sb",
        "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/dec\/22\/why-time-management-is-ruining-our-lives",
        "display_url" : "theguardian.com\/technology\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "812367945909334017",
    "text" : "The average life is only 4000 weeks\n\nholy fuck what am i doing\n\nhttps:\/\/t.co\/Fm45tNv9Sb https:\/\/t.co\/q3oMxGdqoE",
    "id" : 812367945909334017,
    "created_at" : "2016-12-23 18:43:06 +0000",
    "user" : {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "protected" : false,
      "id_str" : "636023721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796806166332444673\/MihDU_e8_normal.jpg",
      "id" : 636023721,
      "verified" : true
    }
  },
  "id" : 812570202802126852,
  "created_at" : "2016-12-24 08:06:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812364858108755968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114032108599, 8.753421240100538 ]
  },
  "id_str" : "812566119655624704",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski yes, it\u2019s so weird. And they do get the X\/Y-karyotype from the test in any case. :(",
  "id" : 812566119655624704,
  "in_reply_to_status_id" : 812364858108755968,
  "created_at" : "2016-12-24 07:50:34 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812360048835956737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403249164147, 8.753422254243754 ]
  },
  "id_str" : "812360562487263232",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima also: drop me your address and I\u2019ll send some openSNP and Repositive stickers :D",
  "id" : 812360562487263232,
  "in_reply_to_status_id" : 812360048835956737,
  "created_at" : "2016-12-23 18:13:45 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/uuzmAatkEv",
      "expanded_url" : "http:\/\/asapbio.org\/stickers",
      "display_url" : "asapbio.org\/stickers"
    } ]
  },
  "in_reply_to_status_id_str" : "812360048835956737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403249164147, 8.753422254243754 ]
  },
  "id_str" : "812360423668322304",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima you can get some too if you go to https:\/\/t.co\/uuzmAatkEv \uD83D\uDE0A",
  "id" : 812360423668322304,
  "in_reply_to_status_id" : 812360048835956737,
  "created_at" : "2016-12-23 18:13:12 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/812357807102103552\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/0nON6BthNc",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C0YTHMpWQAAgfUW.jpg",
      "id_str" : "812357797161615360",
      "id" : 812357797161615360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C0YTHMpWQAAgfUW.jpg",
      "sizes" : [ {
        "h" : 202,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/0nON6BthNc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/c7SWChPFxf",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/811484178432851968",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "812357807102103552",
  "text" : "Finally managed to get it installed, at least the bits I wanted. https:\/\/t.co\/c7SWChPFxf https:\/\/t.co\/0nON6BthNc",
  "id" : 812357807102103552,
  "created_at" : "2016-12-23 18:02:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 3, 10 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Koalha\/status\/808267004167786497\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/356Q0td63Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzeKiXsWEAAt29f.jpg",
      "id_str" : "808266981216489472",
      "id" : 808266981216489472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzeKiXsWEAAt29f.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1170,
        "resize" : "fit",
        "w" : 2080
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/356Q0td63Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812356202105606145",
  "text" : "RT @Koalha: Laptop overheats and shuts down when I try to parallell-process spatial information. My solution: https:\/\/t.co\/356Q0td63Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Koalha\/status\/808267004167786497\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/356Q0td63Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CzeKiXsWEAAt29f.jpg",
        "id_str" : "808266981216489472",
        "id" : 808266981216489472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzeKiXsWEAAt29f.jpg",
        "sizes" : [ {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1170,
          "resize" : "fit",
          "w" : 2080
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/356Q0td63Q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "808267004167786497",
    "text" : "Laptop overheats and shuts down when I try to parallell-process spatial information. My solution: https:\/\/t.co\/356Q0td63Q",
    "id" : 808267004167786497,
    "created_at" : "2016-12-12 11:07:25 +0000",
    "user" : {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "protected" : false,
      "id_str" : "87993032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789342424397152256\/CkvkjMLb_normal.jpg",
      "id" : 87993032,
      "verified" : false
    }
  },
  "id" : 812356202105606145,
  "created_at" : "2016-12-23 17:56:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812354851980120064",
  "geo" : { },
  "id_str" : "812355100823945217",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha mh\u2026 that\u2019s indeed only twice the distance that I travel each weekend in any case. \uD83E\uDD14",
  "id" : 812355100823945217,
  "in_reply_to_status_id" : 812354851980120064,
  "created_at" : "2016-12-23 17:52:03 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812353493377937408",
  "geo" : { },
  "id_str" : "812353826070085632",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha bringing it down to how much? ;)",
  "id" : 812353826070085632,
  "in_reply_to_status_id" : 812353493377937408,
  "created_at" : "2016-12-23 17:46:59 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/iVJyx16GrS",
      "expanded_url" : "https:\/\/twitter.com\/Koalha\/status\/812343569017139202",
      "display_url" : "twitter.com\/Koalha\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403218439187, 8.75342219652592 ]
  },
  "id_str" : "812347759567192064",
  "text" : "These look so delicious! Why are you living so far away?! \uD83D\uDC45\uD83D\uDCA7\uD83C\uDF6A https:\/\/t.co\/iVJyx16GrS",
  "id" : 812347759567192064,
  "created_at" : "2016-12-23 17:22:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Polka",
      "screen_name" : "jessicapolka",
      "indices" : [ 54, 67 ],
      "id_str" : "252204344",
      "id" : 252204344
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/812301198007078912\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/fTXPu3t4W7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C0Xfn-FXAAE_k17.jpg",
      "id_str" : "812301185583611905",
      "id" : 812301185583611905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0Xfn-FXAAE_k17.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/fTXPu3t4W7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11180248409949, 8.75113400537845 ]
  },
  "id_str" : "812301198007078912",
  "text" : "Coming home from the office to find these. Thanks! \uD83D\uDC96\uD83D\uDE0D @jessicapolka https:\/\/t.co\/fTXPu3t4W7",
  "id" : 812301198007078912,
  "created_at" : "2016-12-23 14:17:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/cISClTfHh5",
      "expanded_url" : "https:\/\/twitter.com\/PersonalDataIO\/status\/812300814421295104",
      "display_url" : "twitter.com\/PersonalDataIO\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1118129746428, 8.751131984475718 ]
  },
  "id_str" : "812301035909816320",
  "text" : "\uD83D\uDE02\uD83D\uDE02\uD83D\uDE02\uD83D\uDE02 https:\/\/t.co\/cISClTfHh5",
  "id" : 812301035909816320,
  "created_at" : "2016-12-23 14:17:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812241757689774080",
  "geo" : { },
  "id_str" : "812243821874515968",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin totally understand that :D",
  "id" : 812243821874515968,
  "in_reply_to_status_id" : 812241757689774080,
  "created_at" : "2016-12-23 10:29:52 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/CVy5Uarx0b",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.2001624",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "812221565416960000",
  "geo" : { },
  "id_str" : "812221702516183040",
  "in_reply_to_user_id" : 14286491,
  "text" : "For the academically inclined: The paper on Lifemap is here. https:\/\/t.co\/CVy5Uarx0b",
  "id" : 812221702516183040,
  "in_reply_to_status_id" : 812221565416960000,
  "created_at" : "2016-12-23 09:01:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/812221565416960000\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/TN6URFcGsO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C0WXNTIWEAA2-26.jpg",
      "id_str" : "812221562539610112",
      "id" : 812221562539610112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0WXNTIWEAA2-26.jpg",
      "sizes" : [ {
        "h" : 629,
        "resize" : "fit",
        "w" : 901
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 901
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 901
      } ],
      "display_url" : "pic.twitter.com\/TN6URFcGsO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Jqu2FGX5AT",
      "expanded_url" : "http:\/\/lifemap.univ-lyon1.fr\/",
      "display_url" : "lifemap.univ-lyon1.fr"
    } ]
  },
  "geo" : { },
  "id_str" : "812221565416960000",
  "text" : "This is too much fun: A Google Maps-like interface to the Tree of Life! https:\/\/t.co\/Jqu2FGX5AT https:\/\/t.co\/TN6URFcGsO",
  "id" : 812221565416960000,
  "created_at" : "2016-12-23 09:01:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812210891550818304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10941643738198, 8.736905101694852 ]
  },
  "id_str" : "812212120557387776",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin i wondered when the first smart ass would come up with that :p",
  "id" : 812212120557387776,
  "in_reply_to_status_id" : 812210891550818304,
  "created_at" : "2016-12-23 08:23:54 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/JrrgavQwEV",
      "expanded_url" : "https:\/\/twitter.com\/joeycomeau\/status\/812044123037274112",
      "display_url" : "twitter.com\/joeycomeau\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091193938058, 8.818727970342959 ]
  },
  "id_str" : "812089051088097280",
  "text" : "Give him all your monies \uD83D\uDCB0 https:\/\/t.co\/JrrgavQwEV",
  "id" : 812089051088097280,
  "created_at" : "2016-12-23 00:14:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/rNxI9xEOZb",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/the-other-side-of-the-chessboard-2",
      "display_url" : "smbc-comics.com\/comic\/the-othe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "812059965770829825",
  "text" : "Being in \u201EApplied Bioinformatics\u201C feels exactly like that. https:\/\/t.co\/rNxI9xEOZb",
  "id" : 812059965770829825,
  "created_at" : "2016-12-22 22:19:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812011436767608834",
  "geo" : { },
  "id_str" : "812059717992321025",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim I had to Google that one first as I didn\u2019t grow up around here :D",
  "id" : 812059717992321025,
  "in_reply_to_status_id" : 812011436767608834,
  "created_at" : "2016-12-22 22:18:18 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clive Thompson",
      "screen_name" : "pomeranian99",
      "indices" : [ 3, 16 ],
      "id_str" : "661403",
      "id" : 661403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812058699627974656",
  "text" : "RT @pomeranian99: Why the headquarters of evil megacorporations in movies are always \"brooding Late Modernist\" architecture: https:\/\/t.co\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pomeranian99\/status\/812005919781515264\/photo\/1",
        "indices" : [ 131, 154 ],
        "url" : "https:\/\/t.co\/uGPMEvhrs2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C0TTEk-UcAAcnEO.jpg",
        "id_str" : "812005908431532032",
        "id" : 812005908431532032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0TTEk-UcAAcnEO.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/uGPMEvhrs2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/t0pYE5FAFa",
        "expanded_url" : "http:\/\/99percentinvisible.org\/article\/architecture-evil-dystopian-megacorps-speculative-fiction\/",
        "display_url" : "99percentinvisible.org\/article\/archit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "812005919781515264",
    "text" : "Why the headquarters of evil megacorporations in movies are always \"brooding Late Modernist\" architecture: https:\/\/t.co\/t0pYE5FAFa https:\/\/t.co\/uGPMEvhrs2",
    "id" : 812005919781515264,
    "created_at" : "2016-12-22 18:44:32 +0000",
    "user" : {
      "name" : "Clive Thompson",
      "screen_name" : "pomeranian99",
      "protected" : false,
      "id_str" : "661403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000407595163\/163d76384315dfd651daa13e44b724e4_normal.jpeg",
      "id" : 661403,
      "verified" : true
    }
  },
  "id" : 812058699627974656,
  "created_at" : "2016-12-22 22:14:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oana Carja",
      "screen_name" : "oanacarja",
      "indices" : [ 0, 10 ],
      "id_str" : "137386838",
      "id" : 137386838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812003685056188416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082439881108, 8.818658511804294 ]
  },
  "id_str" : "812025076405112834",
  "in_reply_to_user_id" : 137386838,
  "text" : "@oanacarja the wave in the mind? :)",
  "id" : 812025076405112834,
  "in_reply_to_status_id" : 812003685056188416,
  "created_at" : "2016-12-22 20:00:39 +0000",
  "in_reply_to_screen_name" : "oanacarja",
  "in_reply_to_user_id_str" : "137386838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812011001717596160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092803057693, 8.81891891793706 ]
  },
  "id_str" : "812011336733487108",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim oh, where did you grow up?!",
  "id" : 812011336733487108,
  "in_reply_to_status_id" : 812011001717596160,
  "created_at" : "2016-12-22 19:06:03 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/MyoMXrw1tJ",
      "expanded_url" : "https:\/\/twitter.com\/MozOpenLeaders\/status\/811974190014181377",
      "display_url" : "twitter.com\/MozOpenLeaders\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06097989161504, 8.81854332984315 ]
  },
  "id_str" : "812007104613650432",
  "text" : "Give it a try, it\u2019s an awesome program! https:\/\/t.co\/MyoMXrw1tJ",
  "id" : 812007104613650432,
  "created_at" : "2016-12-22 18:49:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812004965094977540",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06102982434597, 8.818687331592619 ]
  },
  "id_str" : "812005162588012544",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim yeah, so for now i can just put the mysql into docker to not mess around with the system install, but still \uD83D\uDE22\uD83D\uDE22\uD83D\uDE22",
  "id" : 812005162588012544,
  "in_reply_to_status_id" : 812004965094977540,
  "created_at" : "2016-12-22 18:41:31 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812003472837115904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091435830497, 8.81881417403251 ]
  },
  "id_str" : "812003630790348805",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim sure, but then it\u2019s so computationally expensive that you want to run it distributed on the cluster\u2026",
  "id" : 812003630790348805,
  "in_reply_to_status_id" : 812003472837115904,
  "created_at" : "2016-12-22 18:35:26 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812000470785019905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092280348794, 8.818797351906438 ]
  },
  "id_str" : "812000666881323008",
  "in_reply_to_user_id" : 14286491,
  "text" : "Seriously, if you write bioinformatics software that makes the enduser install their own MySQL you are doing it wrong.",
  "id" : 812000666881323008,
  "in_reply_to_status_id" : 812000470785019905,
  "created_at" : "2016-12-22 18:23:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811557777567023105",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084075707993, 8.818746970081348 ]
  },
  "id_str" : "812000470785019905",
  "in_reply_to_user_id" : 14286491,
  "text" : "After what is now basically a week of getting all dependencies for different tools installed I now need to downgrade MySQL\u2026",
  "id" : 812000470785019905,
  "in_reply_to_status_id" : 811557777567023105,
  "created_at" : "2016-12-22 18:22:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811621296899387393",
  "geo" : { },
  "id_str" : "811862182552014849",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie and should be back up. Thanks for the memo!",
  "id" : 811862182552014849,
  "in_reply_to_status_id" : 811621296899387393,
  "created_at" : "2016-12-22 09:13:22 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811621296899387393",
  "geo" : { },
  "id_str" : "811857472495513600",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie whops, thanks!",
  "id" : 811857472495513600,
  "in_reply_to_status_id" : 811621296899387393,
  "created_at" : "2016-12-22 08:54:39 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Char",
      "screen_name" : "CharleenDAdams",
      "indices" : [ 0, 15 ],
      "id_str" : "2350618921",
      "id" : 2350618921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811637709307543553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06098416638566, 8.818608624868856 ]
  },
  "id_str" : "811670384005251073",
  "in_reply_to_user_id" : 2350618921,
  "text" : "@CharleenDAdams enjoy!",
  "id" : 811670384005251073,
  "in_reply_to_status_id" : 811637709307543553,
  "created_at" : "2016-12-21 20:31:14 +0000",
  "in_reply_to_screen_name" : "CharleenDAdams",
  "in_reply_to_user_id_str" : "2350618921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 3, 9 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 54, 70 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811659999994855424",
  "text" : "RT @shefw: Highly recommended reading from our Fellow @daniellecrobins. Section on setting work boundaries esp helpful! https:\/\/t.co\/ayDSP6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "D Robinson, PhD",
        "screen_name" : "daniellecrobins",
        "indices" : [ 43, 59 ],
        "id_str" : "383289779",
        "id" : 383289779
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/ayDSP6K3iO",
        "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/811604646925975552",
        "display_url" : "twitter.com\/MozillaScience\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "811656829964947456",
    "text" : "Highly recommended reading from our Fellow @daniellecrobins. Section on setting work boundaries esp helpful! https:\/\/t.co\/ayDSP6K3iO",
    "id" : 811656829964947456,
    "created_at" : "2016-12-21 19:37:22 +0000",
    "user" : {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "protected" : false,
      "id_str" : "48636190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677947392080019456\/CHnYz4aV_normal.jpg",
      "id" : 48636190,
      "verified" : false
    }
  },
  "id" : 811659999994855424,
  "created_at" : "2016-12-21 19:49:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/4pqYlOEdgf",
      "expanded_url" : "https:\/\/twitter.com\/akcayerol\/status\/811206768667803648",
      "display_url" : "twitter.com\/akcayerol\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811605405319172097",
  "text" : "And 11 years later it\u2019s \u00B1 still the same. https:\/\/t.co\/4pqYlOEdgf",
  "id" : 811605405319172097,
  "created_at" : "2016-12-21 16:13:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/dN0xIiKAlR",
      "expanded_url" : "https:\/\/twitter.com\/SynFutures\/status\/811483556593680384",
      "display_url" : "twitter.com\/SynFutures\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237941689358, 8.627501146555401 ]
  },
  "id_str" : "811596882329948160",
  "text" : "\u00ABI know not with what weapons World War III will be fought\u2026 \u2026but this certainly is one option.\u00BB  \u2014 Einstein in a different timeline. https:\/\/t.co\/dN0xIiKAlR",
  "id" : 811596882329948160,
  "created_at" : "2016-12-21 15:39:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 3, 14 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    }, {
      "name" : "24 Days in December",
      "screen_name" : "24DaysInDec",
      "indices" : [ 28, 40 ],
      "id_str" : "4225412536",
      "id" : 4225412536
    }, {
      "name" : "Trans*Code CH",
      "screen_name" : "trans_code_ch",
      "indices" : [ 68, 82 ],
      "id_str" : "778983477966409728",
      "id" : 778983477966409728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/ArnSw6HRy9",
      "expanded_url" : "https:\/\/twitter.com\/24DaysInDec\/status\/811435173212516353",
      "display_url" : "twitter.com\/24DaysInDec\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811594565153161216",
  "text" : "RT @RaeKnowler: My post for @24DaysInDec has gone up! I wrote about @trans_code_ch and why it\u2019s important. https:\/\/t.co\/ArnSw6HRy9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "24 Days in December",
        "screen_name" : "24DaysInDec",
        "indices" : [ 12, 24 ],
        "id_str" : "4225412536",
        "id" : 4225412536
      }, {
        "name" : "Trans*Code CH",
        "screen_name" : "trans_code_ch",
        "indices" : [ 52, 66 ],
        "id_str" : "778983477966409728",
        "id" : 778983477966409728
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/ArnSw6HRy9",
        "expanded_url" : "https:\/\/twitter.com\/24DaysInDec\/status\/811435173212516353",
        "display_url" : "twitter.com\/24DaysInDec\/st\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "811435173212516353",
    "geo" : { },
    "id_str" : "811444502019899394",
    "in_reply_to_user_id" : 4225412536,
    "text" : "My post for @24DaysInDec has gone up! I wrote about @trans_code_ch and why it\u2019s important. https:\/\/t.co\/ArnSw6HRy9",
    "id" : 811444502019899394,
    "in_reply_to_status_id" : 811435173212516353,
    "created_at" : "2016-12-21 05:33:39 +0000",
    "in_reply_to_screen_name" : "24DaysInDec",
    "in_reply_to_user_id_str" : "4225412536",
    "user" : {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "protected" : false,
      "id_str" : "1244114060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897886763435294720\/nvIG3s3i_normal.jpg",
      "id" : 1244114060,
      "verified" : false
    }
  },
  "id" : 811594565153161216,
  "created_at" : "2016-12-21 15:29:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811576143723765760",
  "geo" : { },
  "id_str" : "811581015416307713",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 people would then be thrown out of flying cars for speaking Arabic\u2026  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 811581015416307713,
  "in_reply_to_status_id" : 811576143723765760,
  "created_at" : "2016-12-21 14:36:07 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811530959547928576",
  "geo" : { },
  "id_str" : "811571909460631553",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice where can I contribute to that Patreon?! \uD83D\uDCB8\uD83D\uDCB8",
  "id" : 811571909460631553,
  "in_reply_to_status_id" : 811530959547928576,
  "created_at" : "2016-12-21 13:59:56 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Cox",
      "screen_name" : "MrBrendanCox",
      "indices" : [ 3, 16 ],
      "id_str" : "133407633",
      "id" : 133407633
    }, {
      "name" : "Nigel Farage",
      "screen_name" : "Nigel_Farage",
      "indices" : [ 18, 31 ],
      "id_str" : "19017675",
      "id" : 19017675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811563164164911104",
  "text" : "RT @MrBrendanCox: @Nigel_Farage blaming politicians for the actions of extremists? That's a slippery slope Nigel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nigel Farage",
        "screen_name" : "Nigel_Farage",
        "indices" : [ 0, 13 ],
        "id_str" : "19017675",
        "id" : 19017675
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "811123023621267456",
    "geo" : { },
    "id_str" : "811124745013956608",
    "in_reply_to_user_id" : 19017675,
    "text" : "@Nigel_Farage blaming politicians for the actions of extremists? That's a slippery slope Nigel",
    "id" : 811124745013956608,
    "in_reply_to_status_id" : 811123023621267456,
    "created_at" : "2016-12-20 08:23:03 +0000",
    "in_reply_to_screen_name" : "Nigel_Farage",
    "in_reply_to_user_id_str" : "19017675",
    "user" : {
      "name" : "Brendan Cox",
      "screen_name" : "MrBrendanCox",
      "protected" : false,
      "id_str" : "133407633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743730795156647936\/sGJf0J_T_normal.jpg",
      "id" : 133407633,
      "verified" : true
    }
  },
  "id" : 811563164164911104,
  "created_at" : "2016-12-21 13:25:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/x76ZHZUvzD",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/3o8doQ03GPIv4b901q\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/3o8doQ03\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "811484178432851968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238013540703, 8.627500752989777 ]
  },
  "id_str" : "811557777567023105",
  "in_reply_to_user_id" : 14286491,
  "text" : "I\u2019m going $HOME, clear a $PATH\u2026 https:\/\/t.co\/x76ZHZUvzD",
  "id" : 811557777567023105,
  "in_reply_to_status_id" : 811484178432851968,
  "created_at" : "2016-12-21 13:03:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 16, 29 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811526190133428225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227649000144, 8.627510109997482 ]
  },
  "id_str" : "811526317749530629",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @schwessinger yes, took me forever to set it up back when. Don\u2019t feel like touching it ever since.",
  "id" : 811526317749530629,
  "in_reply_to_status_id" : 811526190133428225,
  "created_at" : "2016-12-21 10:58:46 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 16, 29 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811525656370507776",
  "geo" : { },
  "id_str" : "811525796816883712",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @schwessinger not yet, issue seems to be the hardcoded perl in GeneMark though as far as I can tell until now.",
  "id" : 811525796816883712,
  "in_reply_to_status_id" : 811525656370507776,
  "created_at" : "2016-12-21 10:56:42 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 0, 13 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811524608339759104",
  "geo" : { },
  "id_str" : "811525443899822080",
  "in_reply_to_user_id" : 1337118332,
  "text" : "@schwessinger thanks. Might give that a try in addition to Maker. :)",
  "id" : 811525443899822080,
  "in_reply_to_status_id" : 811524608339759104,
  "created_at" : "2016-12-21 10:55:17 +0000",
  "in_reply_to_screen_name" : "schwessinger",
  "in_reply_to_user_id_str" : "1337118332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 0, 13 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811519793077460992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723343279611, 8.62758224580183 ]
  },
  "id_str" : "811523833337409536",
  "in_reply_to_user_id" : 1337118332,
  "text" : "@schwessinger nice. Into which mix did you throw it in the end?",
  "id" : 811523833337409536,
  "in_reply_to_status_id" : 811519793077460992,
  "created_at" : "2016-12-21 10:48:53 +0000",
  "in_reply_to_screen_name" : "schwessinger",
  "in_reply_to_user_id_str" : "1337118332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 0, 13 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811511421389258752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17243898762847, 8.627555113030795 ]
  },
  "id_str" : "811511974186127360",
  "in_reply_to_user_id" : 1337118332,
  "text" : "@schwessinger as they are not using what\u2019s in $PATH but rather hardcoded \/user\/bin\u2026",
  "id" : 811511974186127360,
  "in_reply_to_status_id" : 811511421389258752,
  "created_at" : "2016-12-21 10:01:46 +0000",
  "in_reply_to_screen_name" : "schwessinger",
  "in_reply_to_user_id_str" : "1337118332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 0, 13 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811511421389258752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17243898762847, 8.627555113030795 ]
  },
  "id_str" : "811511822532706305",
  "in_reply_to_user_id" : 1337118332,
  "text" : "@schwessinger yeah, might do the same. Guess now I\u2019d have to edit all the GeneMark files to make them use the right perl\u2026",
  "id" : 811511822532706305,
  "in_reply_to_status_id" : 811511421389258752,
  "created_at" : "2016-12-21 10:01:10 +0000",
  "in_reply_to_screen_name" : "schwessinger",
  "in_reply_to_user_id_str" : "1337118332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 0, 13 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811509403295707137",
  "geo" : { },
  "id_str" : "811510863958069248",
  "in_reply_to_user_id" : 1337118332,
  "text" : "@schwessinger but then I went down the anaconda\/perlbrew rabbit hole to get all dependencies &amp; now I wait to be picked up by the red queen",
  "id" : 811510863958069248,
  "in_reply_to_status_id" : 811509403295707137,
  "created_at" : "2016-12-21 09:57:21 +0000",
  "in_reply_to_screen_name" : "schwessinger",
  "in_reply_to_user_id_str" : "1337118332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 0, 13 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811509403295707137",
  "geo" : { },
  "id_str" : "811510655157207044",
  "in_reply_to_user_id" : 1337118332,
  "text" : "@schwessinger that\u2019s such a relief. I thought it was just me, after all brew should have made it easy.",
  "id" : 811510655157207044,
  "in_reply_to_status_id" : 811509403295707137,
  "created_at" : "2016-12-21 09:56:31 +0000",
  "in_reply_to_screen_name" : "schwessinger",
  "in_reply_to_user_id_str" : "1337118332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 69, 83 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/8M6r6JNmLZ",
      "expanded_url" : "http:\/\/blog.scienceopen.com\/2016\/12\/people-making-a-difference-in-2016-open-science-stars\/",
      "display_url" : "blog.scienceopen.com\/2016\/12\/people\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228413346105, 8.62750254027698 ]
  },
  "id_str" : "811510454392680448",
  "text" : "Fitting the season: The Jesus Christ Open Science Superstars. Thanks @Protohedgehog for including me! \uD83C\uDF84\uD83E\uDD36\uD83C\uDFFF\uD83C\uDF85\uD83C\uDFFE https:\/\/t.co\/8M6r6JNmLZ",
  "id" : 811510454392680448,
  "created_at" : "2016-12-21 09:55:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/giHBwwOLiQ",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/heading-to-iceland-just-make-sure-you-dont-die-there",
      "display_url" : "atlasobscura.com\/articles\/headi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811505340487499776",
  "text" : "When your US-centric world view makes you think not embalming the dead is an Icelandic thing. \uD83D\uDE02 https:\/\/t.co\/giHBwwOLiQ",
  "id" : 811505340487499776,
  "created_at" : "2016-12-21 09:35:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/ZcLsftrZWZ",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/164",
      "display_url" : "existentialcomics.com\/comic\/164"
    } ]
  },
  "geo" : { },
  "id_str" : "811499154186846208",
  "text" : "This should have been a saturday-morning cartoon in my childhood\u2026 https:\/\/t.co\/ZcLsftrZWZ",
  "id" : 811499154186846208,
  "created_at" : "2016-12-21 09:10:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/jUv2OXODzY",
      "expanded_url" : "https:\/\/bmcecol.biomedcentral.com\/articles\/10.1186\/s12898-016-0083-y",
      "display_url" : "bmcecol.biomedcentral.com\/articles\/10.11\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "811488564777287680",
  "geo" : { },
  "id_str" : "811489242568331264",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad makes one wish to have gone into journalism, easy to publish crap. (but then this is on my pub list https:\/\/t.co\/jUv2OXODzY ) \uD83D\uDE02",
  "id" : 811489242568331264,
  "in_reply_to_status_id" : 811488564777287680,
  "created_at" : "2016-12-21 08:31:26 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/F3v9Q7Id6i",
      "expanded_url" : "https:\/\/www.vice.com\/en_uk\/article\/i-went-to-kristianstad-in-search-for-its-mystery-church-shitters",
      "display_url" : "vice.com\/en_uk\/article\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811486487137107968",
  "text" : "\u00ABI Went to Kristianstad In Search for Its Mystery Church Shitters\u00BB https:\/\/t.co\/F3v9Q7Id6i",
  "id" : 811486487137107968,
  "created_at" : "2016-12-21 08:20:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811483384060973056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233386213588, 8.627453270570296 ]
  },
  "id_str" : "811484310595391488",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas i certainly now that feeling. Also the \u201Cwait, did I really write this\u201D-feeling! \uD83D\uDE0A\uD83D\uDE02",
  "id" : 811484310595391488,
  "in_reply_to_status_id" : 811483384060973056,
  "created_at" : "2016-12-21 08:11:50 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17248335553108, 8.627535928882004 ]
  },
  "id_str" : "811484178432851968",
  "text" : "Spent already 2 days trying to install software called \u2018funannotate\u2019 thanks to dependency hell. Now I get why it\u2019s not called \u2018funinstall\u2019.",
  "id" : 811484178432851968,
  "created_at" : "2016-12-21 08:11:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 3, 16 ],
      "id_str" : "228437800",
      "id" : 228437800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/o8INWzhoXH",
      "expanded_url" : "http:\/\/pops.ci\/WrPR2S",
      "display_url" : "pops.ci\/WrPR2S"
    } ]
  },
  "geo" : { },
  "id_str" : "811350411609276416",
  "text" : "RT @atossaaraxia: Interesting PopSci piece on expat* culture in Shenzhen https:\/\/t.co\/o8INWzhoXH *really just anglo-expat but still good",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/o8INWzhoXH",
        "expanded_url" : "http:\/\/pops.ci\/WrPR2S",
        "display_url" : "pops.ci\/WrPR2S"
      } ]
    },
    "geo" : { },
    "id_str" : "811342661277728768",
    "text" : "Interesting PopSci piece on expat* culture in Shenzhen https:\/\/t.co\/o8INWzhoXH *really just anglo-expat but still good",
    "id" : 811342661277728768,
    "created_at" : "2016-12-20 22:48:59 +0000",
    "user" : {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "protected" : false,
      "id_str" : "228437800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707884522738728960\/VqnZwF27_normal.jpg",
      "id" : 228437800,
      "verified" : true
    }
  },
  "id" : 811350411609276416,
  "created_at" : "2016-12-20 23:19:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811342463742808064",
  "geo" : { },
  "id_str" : "811343234823766017",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim sure, in the worst case we can chat while i\u2019m stuck in the office :D",
  "id" : 811343234823766017,
  "in_reply_to_status_id" : 811342463742808064,
  "created_at" : "2016-12-20 22:51:15 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811341552207405056",
  "geo" : { },
  "id_str" : "811341905938223104",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Ok, will try my best to be there. Not 100% sure for the work plan on Fr.",
  "id" : 811341905938223104,
  "in_reply_to_status_id" : 811341552207405056,
  "created_at" : "2016-12-20 22:45:59 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elena Long",
      "screen_name" : "Elena_Long",
      "indices" : [ 11, 22 ],
      "id_str" : "90678527",
      "id" : 90678527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/RaVMhXkGle",
      "expanded_url" : "https:\/\/twitter.com\/mbeisen\/status\/810891609609043968",
      "display_url" : "twitter.com\/mbeisen\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0609895727132, 8.818592531614767 ]
  },
  "id_str" : "811334224091475969",
  "text" : "And so was @elena_long! Well deserved you both! \uD83D\uDC96 https:\/\/t.co\/RaVMhXkGle",
  "id" : 811334224091475969,
  "created_at" : "2016-12-20 22:15:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811309039565029376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06105511919601, 8.818661263220774 ]
  },
  "id_str" : "811332547917545472",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas you\u2019re reading your own book? :p",
  "id" : 811332547917545472,
  "in_reply_to_status_id" : 811309039565029376,
  "created_at" : "2016-12-20 22:08:47 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811257801490235392",
  "geo" : { },
  "id_str" : "811286396480655361",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim nah, have no idea. But should be T1. Where are you going to? :)",
  "id" : 811286396480655361,
  "in_reply_to_status_id" : 811257801490235392,
  "created_at" : "2016-12-20 19:05:24 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 3, 11 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    }, {
      "name" : "Lydia X. Z. Brown",
      "screen_name" : "autistichoya",
      "indices" : [ 51, 64 ],
      "id_str" : "611121924",
      "id" : 611121924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811236629859930117",
  "text" : "RT @_katsel: \u00ABAbleist words and terms to avoid\u00BB by @autistichoya.\nList of words NOT to use when talking about politics these days https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lydia X. Z. Brown",
        "screen_name" : "autistichoya",
        "indices" : [ 38, 51 ],
        "id_str" : "611121924",
        "id" : 611121924
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/PmfJsDu4xL",
        "expanded_url" : "http:\/\/www.autistichoya.com\/p\/ableist-words-and-terms-to-avoid.html",
        "display_url" : "autistichoya.com\/p\/ableist-word\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "811177638979051520",
    "text" : "\u00ABAbleist words and terms to avoid\u00BB by @autistichoya.\nList of words NOT to use when talking about politics these days https:\/\/t.co\/PmfJsDu4xL",
    "id" : 811177638979051520,
    "created_at" : "2016-12-20 11:53:14 +0000",
    "user" : {
      "name" : "Katharina",
      "screen_name" : "katheyrina",
      "protected" : false,
      "id_str" : "730326143295959040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885460122394349569\/oHlt5LK-_normal.jpg",
      "id" : 730326143295959040,
      "verified" : false
    }
  },
  "id" : 811236629859930117,
  "created_at" : "2016-12-20 15:47:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Slodkowicz",
      "screen_name" : "greg_slodkowicz",
      "indices" : [ 3, 19 ],
      "id_str" : "16602000",
      "id" : 16602000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811223358608183296",
  "text" : "RT @greg_slodkowicz: \"A Critical Assessment of Storytelling: Gene Ontology Categories and the Importance of Validating Genomic Scans\" https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/6TuAmZ772K",
        "expanded_url" : "http:\/\/mbe.oxfordjournals.org\/content\/29\/10\/3237.full",
        "display_url" : "mbe.oxfordjournals.org\/content\/29\/10\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "810853151620341760",
    "text" : "\"A Critical Assessment of Storytelling: Gene Ontology Categories and the Importance of Validating Genomic Scans\" https:\/\/t.co\/6TuAmZ772K",
    "id" : 810853151620341760,
    "created_at" : "2016-12-19 14:23:50 +0000",
    "user" : {
      "name" : "Greg Slodkowicz",
      "screen_name" : "greg_slodkowicz",
      "protected" : false,
      "id_str" : "16602000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613252087732936704\/bSRG2FY3_normal.jpg",
      "id" : 16602000,
      "verified" : false
    }
  },
  "id" : 811223358608183296,
  "created_at" : "2016-12-20 14:54:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811213986024878080",
  "geo" : { },
  "id_str" : "811220935881723905",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim don\u2019t know whether there\u2019s any Christmas market at FRA. But could meet for coffee or drinks in any case I think.",
  "id" : 811220935881723905,
  "in_reply_to_status_id" : 811213986024878080,
  "created_at" : "2016-12-20 14:45:17 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811181584816685057",
  "geo" : { },
  "id_str" : "811205096151384064",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim when\u2019s your layover on 23rd? And how long do you have?",
  "id" : 811205096151384064,
  "in_reply_to_status_id" : 811181584816685057,
  "created_at" : "2016-12-20 13:42:21 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 3, 13 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Matthew",
      "screen_name" : "MCeeP",
      "indices" : [ 21, 27 ],
      "id_str" : "359430064",
      "id" : 359430064
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 29, 37 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 39, 55 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 107, 114 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/GsaC92FWgs",
      "expanded_url" : "https:\/\/twitter.com\/ICTscienceEU\/status\/811165618238001153",
      "display_url" : "twitter.com\/ICTscienceEU\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811181226358964224",
  "text" : "RT @Helena_LB: I spy @MCeeP, @glyn_dk, @gedankenstuecke (\"At least no one is seriously using Matlab\"), and @McDawg! https:\/\/t.co\/GsaC92FWgs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew",
        "screen_name" : "MCeeP",
        "indices" : [ 6, 12 ],
        "id_str" : "359430064",
        "id" : 359430064
      }, {
        "name" : "Fiona Nielsen",
        "screen_name" : "glyn_dk",
        "indices" : [ 14, 22 ],
        "id_str" : "32340834",
        "id" : 32340834
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 24, 40 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
        "screen_name" : "McDawg",
        "indices" : [ 92, 99 ],
        "id_str" : "12432262",
        "id" : 12432262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/GsaC92FWgs",
        "expanded_url" : "https:\/\/twitter.com\/ICTscienceEU\/status\/811165618238001153",
        "display_url" : "twitter.com\/ICTscienceEU\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "811169562335019008",
    "text" : "I spy @MCeeP, @glyn_dk, @gedankenstuecke (\"At least no one is seriously using Matlab\"), and @McDawg! https:\/\/t.co\/GsaC92FWgs",
    "id" : 811169562335019008,
    "created_at" : "2016-12-20 11:21:09 +0000",
    "user" : {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "protected" : false,
      "id_str" : "234309722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875644318970634241\/AWFWlhkv_normal.jpg",
      "id" : 234309722,
      "verified" : false
    }
  },
  "id" : 811181226358964224,
  "created_at" : "2016-12-20 12:07:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811169562335019008",
  "geo" : { },
  "id_str" : "811180468842483712",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB making fun of neurosci since forever :P",
  "id" : 811180468842483712,
  "in_reply_to_status_id" : 811169562335019008,
  "created_at" : "2016-12-20 12:04:29 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811143492621713408",
  "geo" : { },
  "id_str" : "811143592148353024",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim thanks! And I know just solved the export by re-uploading them. :D",
  "id" : 811143592148353024,
  "in_reply_to_status_id" : 811143492621713408,
  "created_at" : "2016-12-20 09:37:57 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811138157047484416",
  "geo" : { },
  "id_str" : "811138635739361280",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds managed to snatch the last one from the local supermarket for my colleagues yesterday!",
  "id" : 811138635739361280,
  "in_reply_to_status_id" : 811138157047484416,
  "created_at" : "2016-12-20 09:18:15 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/eZoembEOAz",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/gedankenstuecke\/albums\/72157678064057385",
      "display_url" : "flickr.com\/photos\/gedanke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811137749269041153",
  "text" : "Managed to upload the panoramas taken during my US road trip. Is there a good way to mirror Instagram to Flickr? https:\/\/t.co\/eZoembEOAz",
  "id" : 811137749269041153,
  "created_at" : "2016-12-20 09:14:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 20, 30 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811115340272959488",
  "text" : "Happy Shab-e Yalda! @SCEdmunds",
  "id" : 811115340272959488,
  "created_at" : "2016-12-20 07:45:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "indices" : [ 3, 14 ],
      "id_str" : "44903491",
      "id" : 44903491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810992200888750084",
  "text" : "RT @roseveleth: \"If you believe that books have the power to do good, you also have to believe that they can do just as much harm.\" https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/6IXKscVIjY",
        "expanded_url" : "http:\/\/www.themillions.com\/2016\/12\/year-reading-kevin-nguyen.html",
        "display_url" : "themillions.com\/2016\/12\/year-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "810890413338923008",
    "text" : "\"If you believe that books have the power to do good, you also have to believe that they can do just as much harm.\" https:\/\/t.co\/6IXKscVIjY",
    "id" : 810890413338923008,
    "created_at" : "2016-12-19 16:51:54 +0000",
    "user" : {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "protected" : false,
      "id_str" : "44903491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782201676006588416\/GAIXvMwJ_normal.jpg",
      "id" : 44903491,
      "verified" : false
    }
  },
  "id" : 810992200888750084,
  "created_at" : "2016-12-19 23:36:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/o6lKoHaPNk",
      "expanded_url" : "https:\/\/youtube.com\/watch?v=AbGA08mM5u8",
      "display_url" : "youtube.com\/watch?v=AbGA08\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06105205571657, 8.81873542712117 ]
  },
  "id_str" : "810973834488795136",
  "text" : "\uD83D\uDCAA\uD83E\uDD12\uD83D\uDE22\uD83C\uDF21\uD83D\uDC8A https:\/\/t.co\/o6lKoHaPNk",
  "id" : 810973834488795136,
  "created_at" : "2016-12-19 22:23:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/rjuXxb4Qws",
      "expanded_url" : "https:\/\/twitter.com\/Longreads\/status\/810852691815596032",
      "display_url" : "twitter.com\/Longreads\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "810895756936802304",
  "text" : "Poverty, gentrification, survivor\u2019s guilt. A heartbreaking and depressing read. https:\/\/t.co\/rjuXxb4Qws",
  "id" : 810895756936802304,
  "created_at" : "2016-12-19 17:13:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/iCcvJVZl0d",
      "expanded_url" : "https:\/\/twitter.com\/dg_grimm\/status\/810746347322306560",
      "display_url" : "twitter.com\/dg_grimm\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "810796205043253248",
  "text" : "Look what finally arrived in a non-preprint form: easyGWAS for running &amp; comparing GWAS. https:\/\/t.co\/iCcvJVZl0d",
  "id" : 810796205043253248,
  "created_at" : "2016-12-19 10:37:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Beard",
      "screen_name" : "dabeard",
      "indices" : [ 3, 11 ],
      "id_str" : "28279637",
      "id" : 28279637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810485829143556096",
  "text" : "RT @dabeard: At 18 years old, he aimed his M-60 machine gun at fellow US soldiers to stop the My Lai massacre in Vietnam https:\/\/t.co\/E7ZXf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RIP",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/E7ZXfA4zw7",
        "expanded_url" : "http:\/\/www.nytimes.com\/2016\/12\/16\/world\/asia\/larry-colburn-my-lai-massacre-dies.html?hp&action=click&pgtype=Homepage&clickSource=story-heading&module=first-column-region&region=top-news&WT.nav=top-news&_r=0",
        "display_url" : "nytimes.com\/2016\/12\/16\/wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "810135015615070213",
    "text" : "At 18 years old, he aimed his M-60 machine gun at fellow US soldiers to stop the My Lai massacre in Vietnam https:\/\/t.co\/E7ZXfA4zw7 #RIP",
    "id" : 810135015615070213,
    "created_at" : "2016-12-17 14:50:13 +0000",
    "user" : {
      "name" : "David Beard",
      "screen_name" : "dabeard",
      "protected" : false,
      "id_str" : "28279637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3773956722\/060a643d3de230a1dc983716fb91125f_normal.jpeg",
      "id" : 28279637,
      "verified" : true
    }
  },
  "id" : 810485829143556096,
  "created_at" : "2016-12-18 14:04:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Hodgkinson",
      "screen_name" : "mattjhodgkinson",
      "indices" : [ 0, 16 ],
      "id_str" : "210787605",
      "id" : 210787605
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 17, 31 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Elisabeth Jacobs",
      "screen_name" : "jacobselisabeth",
      "indices" : [ 32, 48 ],
      "id_str" : "334241070",
      "id" : 334241070
    }, {
      "name" : "Guillaume Cabanac",
      "screen_name" : "gcabanac",
      "indices" : [ 49, 58 ],
      "id_str" : "237738266",
      "id" : 237738266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "810444293508923392",
  "geo" : { },
  "id_str" : "810460471295778816",
  "in_reply_to_user_id" : 210787605,
  "text" : "@mattjhodgkinson @Protohedgehog @jacobselisabeth @gcabanac thanks, hadn\u2019t seen that one!",
  "id" : 810460471295778816,
  "in_reply_to_status_id" : 810444293508923392,
  "created_at" : "2016-12-18 12:23:28 +0000",
  "in_reply_to_screen_name" : "mattjhodgkinson",
  "in_reply_to_user_id_str" : "210787605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Feldblum",
      "screen_name" : "chaifeldblum",
      "indices" : [ 3, 16 ],
      "id_str" : "28261043",
      "id" : 28261043
    }, {
      "name" : "Everyday Feminism",
      "screen_name" : "EvrydayFeminism",
      "indices" : [ 38, 54 ],
      "id_str" : "591920938",
      "id" : 591920938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ComingOut",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/sYyOVw33K2",
      "expanded_url" : "http:\/\/bit.ly\/2htb32K",
      "display_url" : "bit.ly\/2htb32K"
    } ]
  },
  "geo" : { },
  "id_str" : "810247298966032384",
  "text" : "RT @chaifeldblum: This is intense. RT @EvrydayFeminism: Why I Am Never, Ever, Ever #ComingOut of the Closet https:\/\/t.co\/sYyOVw33K2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Everyday Feminism",
        "screen_name" : "EvrydayFeminism",
        "indices" : [ 20, 36 ],
        "id_str" : "591920938",
        "id" : 591920938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ComingOut",
        "indices" : [ 65, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/sYyOVw33K2",
        "expanded_url" : "http:\/\/bit.ly\/2htb32K",
        "display_url" : "bit.ly\/2htb32K"
      } ]
    },
    "geo" : { },
    "id_str" : "810234381516361728",
    "text" : "This is intense. RT @EvrydayFeminism: Why I Am Never, Ever, Ever #ComingOut of the Closet https:\/\/t.co\/sYyOVw33K2",
    "id" : 810234381516361728,
    "created_at" : "2016-12-17 21:25:04 +0000",
    "user" : {
      "name" : "Chai Feldblum",
      "screen_name" : "chaifeldblum",
      "protected" : false,
      "id_str" : "28261043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1517751043\/Feldblum_Headshot_normal.jpg",
      "id" : 28261043,
      "verified" : true
    }
  },
  "id" : 810247298966032384,
  "created_at" : "2016-12-17 22:16:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35903375546781, 8.588094000035564 ]
  },
  "id_str" : "810246625297842176",
  "text" : "When you keep talking past each other because your dialects make you think you\u2019re speaking about \u2018Kat Tong\u2019 or \u2018cat tongue\u2019 respectively. \uD83D\uDE02",
  "id" : 810246625297842176,
  "created_at" : "2016-12-17 22:13:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809905326011142144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35919994779175, 8.58769256669351 ]
  },
  "id_str" : "809908079508733952",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser omg, that\u2019s awesome! Need to check these out. And we should make a new date for talking. Early next year, post-holidays?",
  "id" : 809908079508733952,
  "in_reply_to_status_id" : 809905326011142144,
  "created_at" : "2016-12-16 23:48:28 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/ipSDuVNizZ",
      "expanded_url" : "http:\/\/www.newyorker.com\/culture\/cultural-comment\/patti-smith-on-singing-at-bob-dylans-nobel-prize-ceremony",
      "display_url" : "newyorker.com\/culture\/cultur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809761443117723654",
  "text" : "\u00ABtime does not heal all wounds but gives us the tools to endure them\u00BB It\u2019s always good to read Patti Smith https:\/\/t.co\/ipSDuVNizZ",
  "id" : 809761443117723654,
  "created_at" : "2016-12-16 14:05:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809753104161927168",
  "geo" : { },
  "id_str" : "809753163712622592",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha I think the answer is \u201Eboth\u201C :D",
  "id" : 809753163712622592,
  "in_reply_to_status_id" : 809753104161927168,
  "created_at" : "2016-12-16 13:32:53 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otherpeoplesdata",
      "indices" : [ 18, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809750873266122752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238375489953, 8.627554542080231 ]
  },
  "id_str" : "809752547401596929",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha check out #otherpeoplesdata if you want to feel less alone.",
  "id" : 809752547401596929,
  "in_reply_to_status_id" : 809750873266122752,
  "created_at" : "2016-12-16 13:30:26 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 3, 17 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809751659047976960",
  "text" : "RT @AprilHathcock: The \"poor, homeless, &amp; immigrants\" you claim to serve w\/ur librarianing need &amp; deserve better than u &amp; ur ignorant privi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "809746524116754432",
    "geo" : { },
    "id_str" : "809746799514779648",
    "in_reply_to_user_id" : 3209949862,
    "text" : "The \"poor, homeless, &amp; immigrants\" you claim to serve w\/ur librarianing need &amp; deserve better than u &amp; ur ignorant privilege rn.",
    "id" : 809746799514779648,
    "in_reply_to_status_id" : 809746524116754432,
    "created_at" : "2016-12-16 13:07:36 +0000",
    "in_reply_to_screen_name" : "AprilHathcock",
    "in_reply_to_user_id_str" : "3209949862",
    "user" : {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "protected" : false,
      "id_str" : "3209949862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925100168277618693\/8UJUY3i2_normal.jpg",
      "id" : 3209949862,
      "verified" : false
    }
  },
  "id" : 809751659047976960,
  "created_at" : "2016-12-16 13:26:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809748036565999616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219500536135, 8.627592208947286 ]
  },
  "id_str" : "809751238665453568",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye looks like you\u2019re pushing the right buttons!",
  "id" : 809751238665453568,
  "in_reply_to_status_id" : 809748036565999616,
  "created_at" : "2016-12-16 13:25:14 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809735449589805056",
  "geo" : { },
  "id_str" : "809740867447689216",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin I was always suspicious of the \u201Evalue added\u201C-claims by traditional publishers. But I wasn\u2019t aware that it\u2019s even darker\u2026",
  "id" : 809740867447689216,
  "in_reply_to_status_id" : 809735449589805056,
  "created_at" : "2016-12-16 12:44:01 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/YvS6G1myl8",
      "expanded_url" : "http:\/\/www.nature.com\/nm\/journal\/v15\/n6\/full\/nm0609-598a.html",
      "display_url" : "nature.com\/nm\/journal\/v15\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "809734610745757696",
  "geo" : { },
  "id_str" : "809735388457799680",
  "in_reply_to_user_id" : 14286491,
  "text" : "I can\u2019t wait for the \u201EAustralasian Journal of Craniometry\u201C\n &amp; other Scientific Racism-Fake-Journals by them\u2026  c.f. https:\/\/t.co\/YvS6G1myl8",
  "id" : 809735388457799680,
  "in_reply_to_status_id" : 809734610745757696,
  "created_at" : "2016-12-16 12:22:15 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/XxpUFPgZhd",
      "expanded_url" : "https:\/\/twitter.com\/neilstewart\/status\/809398921789378560",
      "display_url" : "twitter.com\/neilstewart\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809734610745757696",
  "text" : "Basically Elsevier is now scamming universities out of public money, use it to fund Nazi-propaganda &amp; they like it\u2026 https:\/\/t.co\/XxpUFPgZhd",
  "id" : 809734610745757696,
  "created_at" : "2016-12-16 12:19:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/mLdeZku6ek",
      "expanded_url" : "https:\/\/sc.mogicons.com\/l\/troll-face-22.png",
      "display_url" : "sc.mogicons.com\/l\/troll-face-2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "809689634192158720",
  "geo" : { },
  "id_str" : "809694008909955072",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski https:\/\/t.co\/mLdeZku6ek",
  "id" : 809694008909955072,
  "in_reply_to_status_id" : 809689634192158720,
  "created_at" : "2016-12-16 09:37:49 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 3, 12 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809684201050087424",
  "text" : "RT @merenbey: Have you also been curious about wavy coverage patterns in mapping results? Good! Here is a blog post on that: https:\/\/t.co\/Z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/ZspVAjhtUS",
        "expanded_url" : "http:\/\/merenlab.org\/2016\/12\/14\/coverage-variation\/",
        "display_url" : "merenlab.org\/2016\/12\/14\/cov\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "809374274842689536",
    "text" : "Have you also been curious about wavy coverage patterns in mapping results? Good! Here is a blog post on that: https:\/\/t.co\/ZspVAjhtUS",
    "id" : 809374274842689536,
    "created_at" : "2016-12-15 12:27:19 +0000",
    "user" : {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "protected" : false,
      "id_str" : "16029156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932426163896700929\/1lby7KPx_normal.jpg",
      "id" : 16029156,
      "verified" : false
    }
  },
  "id" : 809684201050087424,
  "created_at" : "2016-12-16 08:58:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809684115968688128",
  "text" : "RescueTime files Editiorial Manager under \u2018productive\u2019 and I really want to disagree\u2026",
  "id" : 809684115968688128,
  "created_at" : "2016-12-16 08:58:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 13, 21 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/7oSCc9CBKf",
      "expanded_url" : "https:\/\/twitter.com\/statnews\/status\/809541090714013697",
      "display_url" : "twitter.com\/statnews\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06079820408879, 8.818716565986142 ]
  },
  "id_str" : "809550946439229441",
  "text" : "One for you, @Seplute \uD83D\uDC1E\uD83D\uDC1B\uD83D\uDE02 https:\/\/t.co\/7oSCc9CBKf",
  "id" : 809550946439229441,
  "created_at" : "2016-12-16 00:09:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STAT",
      "screen_name" : "statnews",
      "indices" : [ 3, 12 ],
      "id_str" : "3290364847",
      "id" : 3290364847
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/statnews\/status\/809541090714013697\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/J4tgjGgrf8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzwRU9vWIAAwFl8.png",
      "id_str" : "809541084888047616",
      "id" : 809541084888047616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzwRU9vWIAAwFl8.png",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 3200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/J4tgjGgrf8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/FyUnhYxipf",
      "expanded_url" : "http:\/\/bit.ly\/2gOQl0t",
      "display_url" : "bit.ly\/2gOQl0t"
    } ]
  },
  "geo" : { },
  "id_str" : "809550805858656256",
  "text" : "RT @statnews: One man's hunt for the bug responsible for over 12,000 deaths a year. https:\/\/t.co\/FyUnhYxipf https:\/\/t.co\/J4tgjGgrf8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/statnews\/status\/809541090714013697\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/J4tgjGgrf8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CzwRU9vWIAAwFl8.png",
        "id_str" : "809541084888047616",
        "id" : 809541084888047616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzwRU9vWIAAwFl8.png",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 3200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/J4tgjGgrf8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/FyUnhYxipf",
        "expanded_url" : "http:\/\/bit.ly\/2gOQl0t",
        "display_url" : "bit.ly\/2gOQl0t"
      } ]
    },
    "geo" : { },
    "id_str" : "809541090714013697",
    "text" : "One man's hunt for the bug responsible for over 12,000 deaths a year. https:\/\/t.co\/FyUnhYxipf https:\/\/t.co\/J4tgjGgrf8",
    "id" : 809541090714013697,
    "created_at" : "2016-12-15 23:30:11 +0000",
    "user" : {
      "name" : "STAT",
      "screen_name" : "statnews",
      "protected" : false,
      "id_str" : "3290364847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659400347161489408\/eo_k_dq8_normal.png",
      "id" : 3290364847,
      "verified" : true
    }
  },
  "id" : 809550805858656256,
  "created_at" : "2016-12-16 00:08:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809534800302194689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095399153424, 8.8185579981737 ]
  },
  "id_str" : "809535564416479233",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes have fun with it! :)",
  "id" : 809535564416479233,
  "in_reply_to_status_id" : 809534800302194689,
  "created_at" : "2016-12-15 23:08:13 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/5fvFmahekd",
      "expanded_url" : "http:\/\/everytimezone.com\/",
      "display_url" : "everytimezone.com"
    } ]
  },
  "in_reply_to_status_id_str" : "809520203235135488",
  "geo" : { },
  "id_str" : "809527930602868736",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes https:\/\/t.co\/5fvFmahekd helped me a lot to get a better feeling for TZs!",
  "id" : 809527930602868736,
  "in_reply_to_status_id" : 809520203235135488,
  "created_at" : "2016-12-15 22:37:53 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "PersonalData.IO",
      "screen_name" : "PersonalDataIO",
      "indices" : [ 10, 25 ],
      "id_str" : "736639776821018626",
      "id" : 736639776821018626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809392284894691330",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227648999707, 8.627510110005009 ]
  },
  "id_str" : "809392664969904128",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @PersonalDataIO thanks! \uD83D\uDE02",
  "id" : 809392664969904128,
  "in_reply_to_status_id" : 809392284894691330,
  "created_at" : "2016-12-15 13:40:23 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/QYQ441lXSO",
      "expanded_url" : "https:\/\/twitter.com\/PersonalDataIO\/status\/809387876878315520",
      "display_url" : "twitter.com\/PersonalDataIO\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219662776839, 8.627612010148443 ]
  },
  "id_str" : "809390395012550658",
  "text" : "Let\u2019s do a bit of different \u2018open science\u2019. \uD83D\uDD2C\uD83D\uDCCA\uD83C\uDFF7 https:\/\/t.co\/QYQ441lXSO",
  "id" : 809390395012550658,
  "created_at" : "2016-12-15 13:31:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maximilian Haack",
      "screen_name" : "coffeejunk",
      "indices" : [ 0, 11 ],
      "id_str" : "14201785",
      "id" : 14201785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809326119799300097",
  "geo" : { },
  "id_str" : "809326471525310464",
  "in_reply_to_user_id" : 14201785,
  "text" : "@coffeejunk yeah, though I think the biggest problem was the useless fabric outer layer the German passports used to have for a while.",
  "id" : 809326471525310464,
  "in_reply_to_status_id" : 809326119799300097,
  "created_at" : "2016-12-15 09:17:22 +0000",
  "in_reply_to_screen_name" : "coffeejunk",
  "in_reply_to_user_id_str" : "14201785",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maximilian Haack",
      "screen_name" : "coffeejunk",
      "indices" : [ 0, 11 ],
      "id_str" : "14201785",
      "id" : 14201785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809325713983619072",
  "geo" : { },
  "id_str" : "809325949649121280",
  "in_reply_to_user_id" : 14201785,
  "text" : "@coffeejunk exactly how most border guards reacted lately when I was trying to enter a country. \uD83D\uDE02",
  "id" : 809325949649121280,
  "in_reply_to_status_id" : 809325713983619072,
  "created_at" : "2016-12-15 09:15:17 +0000",
  "in_reply_to_screen_name" : "coffeejunk",
  "in_reply_to_user_id_str" : "14201785",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/809324892868976642\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/6cVF8L1VS7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CztMs0nXgAA3VTQ.jpg",
      "id_str" : "809324890964852736",
      "id" : 809324890964852736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CztMs0nXgAA3VTQ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/6cVF8L1VS7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809324892868976642",
  "text" : "At last I managed to make an appointment to replace this 'well-travelled' piece of ID. https:\/\/t.co\/6cVF8L1VS7",
  "id" : 809324892868976642,
  "created_at" : "2016-12-15 09:11:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Biggs",
      "screen_name" : "dianacbiggs",
      "indices" : [ 57, 69 ],
      "id_str" : "20681763",
      "id" : 20681763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/M7ZjQllCSh",
      "expanded_url" : "https:\/\/medium.com\/athena-talks\/how-to-get-more-women-in-tech-a-hackathon-case-study-ab37c032f1bf?source=twitterShare-aaeb714c1b80-1481755008",
      "display_url" : "medium.com\/athena-talks\/h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809165324029399040",
  "text" : "How to Get More Women in Tech: A Hackathon Case Study by @dianacbiggs https:\/\/t.co\/M7ZjQllCSh",
  "id" : 809165324029399040,
  "created_at" : "2016-12-14 22:37:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809162559173623808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078044391725, 8.818554444032609 ]
  },
  "id_str" : "809163340589236226",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H thx!",
  "id" : 809163340589236226,
  "in_reply_to_status_id" : 809162559173623808,
  "created_at" : "2016-12-14 22:29:08 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Crazy Scientist, PhD",
      "screen_name" : "wandedob",
      "indices" : [ 11, 20 ],
      "id_str" : "253685928",
      "id" : 253685928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/f8wFZpWICS",
      "expanded_url" : "http:\/\/www.nature.com\/news\/why-scientists-must-share-their-research-code-1.20504",
      "display_url" : "nature.com\/news\/why-scien\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "808967365161586688",
  "geo" : { },
  "id_str" : "808968501440446465",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @wandedob along the lines of https:\/\/t.co\/f8wFZpWICS ?",
  "id" : 808968501440446465,
  "in_reply_to_status_id" : 808967365161586688,
  "created_at" : "2016-12-14 09:34:55 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dixie",
      "screen_name" : "timiat",
      "indices" : [ 0, 7 ],
      "id_str" : "10388582",
      "id" : 10388582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "808965926196563968",
  "geo" : { },
  "id_str" : "808966081717137409",
  "in_reply_to_user_id" : 10388582,
  "text" : "@timiat yeah, but the first is basically for a fun reason, the latter not so much.",
  "id" : 808966081717137409,
  "in_reply_to_status_id" : 808965926196563968,
  "created_at" : "2016-12-14 09:25:18 +0000",
  "in_reply_to_screen_name" : "timiat",
  "in_reply_to_user_id_str" : "10388582",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/dHaYlsrla3",
      "expanded_url" : "https:\/\/psmag.com\/here-are-four-myths-about-diversity-in-science-75ceb5088b4c?source=twitterShare-aaeb714c1b80-1481706581",
      "display_url" : "psmag.com\/here-are-four-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808962215273463808",
  "text" : "Four Myths About Diversity in Science https:\/\/t.co\/dHaYlsrla3",
  "id" : 808962215273463808,
  "created_at" : "2016-12-14 09:09:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078531736461, 8.818668425564915 ]
  },
  "id_str" : "808924603116560386",
  "text" : "I used to sleep little because I was so amazed by the world. By now it\u2019s existential angst and terror that prevents me from falling asleep.",
  "id" : 808924603116560386,
  "created_at" : "2016-12-14 06:40:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tal Yarkoni",
      "screen_name" : "talyarkoni",
      "indices" : [ 105, 116 ],
      "id_str" : "82511170",
      "id" : 82511170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/r1Hd3Nkzkx",
      "expanded_url" : "http:\/\/www.talyarkoni.org\/blog\/2016\/12\/12\/why-i-still-wont-review-for-or-publish-with-elsevier-and-think-you-shouldnt-either\/",
      "display_url" : "talyarkoni.org\/blog\/2016\/12\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808809881704759296",
  "text" : "\u00ABWhy I still won\u2019t review for or publish with Elsevier\u2013and think you shouldn\u2019t either\u00BB Great overview by @talyarkoni https:\/\/t.co\/r1Hd3Nkzkx",
  "id" : 808809881704759296,
  "created_at" : "2016-12-13 23:04:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808782513208430592",
  "text" : "RT @wilbanks: Data sharing as protective mechanism. Also, my dad - a climate scientist who devoted his life to this stuff - finds this sad\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/dk2JZQ9W3f",
        "expanded_url" : "https:\/\/twitter.com\/alicebell\/status\/808718127978651648",
        "display_url" : "twitter.com\/alicebell\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "808722513584914436",
    "text" : "Data sharing as protective mechanism. Also, my dad - a climate scientist who devoted his life to this stuff - finds this sad and depressing. https:\/\/t.co\/dk2JZQ9W3f",
    "id" : 808722513584914436,
    "created_at" : "2016-12-13 17:17:27 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 808782513208430592,
  "created_at" : "2016-12-13 21:15:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trans*Code CH",
      "screen_name" : "trans_code_ch",
      "indices" : [ 0, 14 ],
      "id_str" : "778983477966409728",
      "id" : 778983477966409728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "808743605372383232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06079223368109, 8.818664494088216 ]
  },
  "id_str" : "808779728123559936",
  "in_reply_to_user_id" : 778983477966409728,
  "text" : "@trans_code_ch this time I\u2019ll do better on not oversleeping! \uD83E\uDD1E",
  "id" : 808779728123559936,
  "in_reply_to_status_id" : 808743605372383232,
  "created_at" : "2016-12-13 21:04:48 +0000",
  "in_reply_to_screen_name" : "trans_code_ch",
  "in_reply_to_user_id_str" : "778983477966409728",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808775963169406977",
  "text" : "RT @EmilyGorcenski: For all the warrior metaphors we use to ply egos in tech, the industry broadly lacks courage to stand against morally r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "808663448984965120",
    "geo" : { },
    "id_str" : "808663911834730496",
    "in_reply_to_user_id" : 1483064670,
    "text" : "For all the warrior metaphors we use to ply egos in tech, the industry broadly lacks courage to stand against morally reprehensible acts.",
    "id" : 808663911834730496,
    "in_reply_to_status_id" : 808663448984965120,
    "created_at" : "2016-12-13 13:24:35 +0000",
    "in_reply_to_screen_name" : "EmilyGorcenski",
    "in_reply_to_user_id_str" : "1483064670",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 808775963169406977,
  "created_at" : "2016-12-13 20:49:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Zara Rahman",
      "screen_name" : "zararah",
      "indices" : [ 54, 62 ],
      "id_str" : "222865265",
      "id" : 222865265
    }, {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "indices" : [ 67, 82 ],
      "id_str" : "2262399740",
      "id" : 2262399740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/IBrrzSRmRL",
      "expanded_url" : "https:\/\/modelviewculture.com\/pieces\/2016-a-year-of-data-driven-confusion",
      "display_url" : "modelviewculture.com\/pieces\/2016-a-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808769280884035584",
  "text" : "RT @o_guest: 2016: A Year of Data-Driven Confusion by @zararah via @modelviewmedia https:\/\/t.co\/IBrrzSRmRL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zara Rahman",
        "screen_name" : "zararah",
        "indices" : [ 41, 49 ],
        "id_str" : "222865265",
        "id" : 222865265
      }, {
        "name" : "Model View Culture",
        "screen_name" : "ModelViewMedia",
        "indices" : [ 54, 69 ],
        "id_str" : "2262399740",
        "id" : 2262399740
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/IBrrzSRmRL",
        "expanded_url" : "https:\/\/modelviewculture.com\/pieces\/2016-a-year-of-data-driven-confusion",
        "display_url" : "modelviewculture.com\/pieces\/2016-a-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "808713237416046592",
    "text" : "2016: A Year of Data-Driven Confusion by @zararah via @modelviewmedia https:\/\/t.co\/IBrrzSRmRL",
    "id" : 808713237416046592,
    "created_at" : "2016-12-13 16:40:35 +0000",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 808769280884035584,
  "created_at" : "2016-12-13 20:23:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "808693425855930368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228230125363, 8.627504669607474 ]
  },
  "id_str" : "808706725729697792",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo @meganbeckett2 congrats! \uD83C\uDF89\uD83C\uDF7E\uD83C\uDF88",
  "id" : 808706725729697792,
  "in_reply_to_status_id" : 808693425855930368,
  "created_at" : "2016-12-13 16:14:43 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/wO5RpYZKmS",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/0e9a3374f4f20b1409c598273d9f6d1b\/tumblr_n1fixeSAS21s5bh5uo1_250.gif",
      "display_url" : "25.media.tumblr.com\/0e9a3374f4f20b\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "808695770438389760",
  "geo" : { },
  "id_str" : "808696424405827585",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABCongratulations! You're really good at reading, and probably a lot of other things, too!\u00BB https:\/\/t.co\/wO5RpYZKmS \uD83D\uDE02",
  "id" : 808696424405827585,
  "in_reply_to_status_id" : 808695770438389760,
  "created_at" : "2016-12-13 15:33:47 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/6HizfybQgB",
      "expanded_url" : "https:\/\/www.goodreads.com\/user\/year_in_books\/2016\/5925863",
      "display_url" : "goodreads.com\/user\/year_in_b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808695770438389760",
  "text" : "At least in some respects 2016 was not that bad it seems https:\/\/t.co\/6HizfybQgB",
  "id" : 808695770438389760,
  "created_at" : "2016-12-13 15:31:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isabelle M C\u00F4t\u00E9",
      "screen_name" : "redlipblenny",
      "indices" : [ 3, 16 ],
      "id_str" : "590068644",
      "id" : 590068644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808661985810321408",
  "text" : "RT @redlipblenny: Now properly cooled down, I sent this to the editor who transmitted a savage review. Let's bring civility back to peer re\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/redlipblenny\/status\/808607552888066048\/photo\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/NTYmcCKjOm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Czi_NaNWQAA8jnH.jpg",
        "id_str" : "808606370207514624",
        "id" : 808606370207514624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Czi_NaNWQAA8jnH.jpg",
        "sizes" : [ {
          "h" : 185,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 557,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 326,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 774,
          "resize" : "fit",
          "w" : 2845
        } ],
        "display_url" : "pic.twitter.com\/NTYmcCKjOm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "808607552888066048",
    "text" : "Now properly cooled down, I sent this to the editor who transmitted a savage review. Let's bring civility back to peer review! https:\/\/t.co\/NTYmcCKjOm",
    "id" : 808607552888066048,
    "created_at" : "2016-12-13 09:40:38 +0000",
    "user" : {
      "name" : "Isabelle M C\u00F4t\u00E9",
      "screen_name" : "redlipblenny",
      "protected" : false,
      "id_str" : "590068644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000342826320\/7db7c576d6d95535e3ef815c25bc7f09_normal.jpeg",
      "id" : 590068644,
      "verified" : false
    }
  },
  "id" : 808661985810321408,
  "created_at" : "2016-12-13 13:16:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Howard J. Wu",
      "screen_name" : "MisterWu78",
      "indices" : [ 0, 11 ],
      "id_str" : "22278512",
      "id" : 22278512
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 12, 19 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/jw9KxIWq5c",
      "expanded_url" : "http:\/\/www.theallusionist.org\/allusionist\/winterval",
      "display_url" : "theallusionist.org\/allusionist\/wi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "808640341515509760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218992359343, 8.62767225772857 ]
  },
  "id_str" : "808645826994180096",
  "in_reply_to_user_id" : 22278512,
  "text" : "@MisterWu78 @Koalha that\u2019s what we got Winterval for. https:\/\/t.co\/jw9KxIWq5c",
  "id" : 808645826994180096,
  "in_reply_to_status_id" : 808640341515509760,
  "created_at" : "2016-12-13 12:12:43 +0000",
  "in_reply_to_screen_name" : "MisterWu78",
  "in_reply_to_user_id_str" : "22278512",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juh",
      "screen_name" : "__juh__",
      "indices" : [ 0, 8 ],
      "id_str" : "20516838",
      "id" : 20516838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "808607820283281410",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223772723816, 8.627543081433046 ]
  },
  "id_str" : "808612358486654977",
  "in_reply_to_user_id" : 20516838,
  "text" : "@__juh__ Danke, sobald ich die Platte wiedergefunden habe :D",
  "id" : 808612358486654977,
  "in_reply_to_status_id" : 808607820283281410,
  "created_at" : "2016-12-13 09:59:44 +0000",
  "in_reply_to_screen_name" : "__juh__",
  "in_reply_to_user_id_str" : "20516838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/808602099714064384\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/pIGYjT2H80",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Czi7Uf6XcAARrp2.jpg",
      "id_str" : "808602093951086592",
      "id" : 808602093951086592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Czi7Uf6XcAARrp2.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/pIGYjT2H80"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242520788229, 8.627570608176331 ]
  },
  "id_str" : "808602099714064384",
  "text" : "Guess who was exhausted and needed a veeeery slow weekend. https:\/\/t.co\/pIGYjT2H80",
  "id" : 808602099714064384,
  "created_at" : "2016-12-13 09:18:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/T87IbQ8ePM",
      "expanded_url" : "https:\/\/twitter.com\/BioMickWatson\/status\/808600125622853633",
      "display_url" : "twitter.com\/BioMickWatson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808600986008846336",
  "text" : "If you can cite tweets you can cite personal communication. Oh, wait\u2026 https:\/\/t.co\/T87IbQ8ePM",
  "id" : 808600986008846336,
  "created_at" : "2016-12-13 09:14:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227646172529, 8.627509991077245 ]
  },
  "id_str" : "808594368210882560",
  "text" : "That bad feeling of kind of not knowing on which HDD you stored your 10 years worth of raw photos. \uD83D\uDE31\uD83D\uDCF8",
  "id" : 808594368210882560,
  "created_at" : "2016-12-13 08:48:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/vS2sd9LkmP",
      "expanded_url" : "https:\/\/twitter.com\/kelseyrkennedy\/status\/808400664535695360",
      "display_url" : "twitter.com\/kelseyrkennedy\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06075747444706, 8.81869437010544 ]
  },
  "id_str" : "808457040272248832",
  "text" : "Many scientists feel the same once they got the comments from reviewer #3. https:\/\/t.co\/vS2sd9LkmP",
  "id" : 808457040272248832,
  "created_at" : "2016-12-12 23:42:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/lWbfdNLXCl",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Miriam_Benjamin",
      "display_url" : "en.wikipedia.org\/wiki\/Miriam_Be\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "804762543323488256",
  "geo" : { },
  "id_str" : "808437235695710209",
  "in_reply_to_user_id" : 14286491,
  "text" : "Today\u2019s good night story was on Miriam Benjamin \uD83D\uDECE\uD83D\uDCA1\uD83D\uDC98 https:\/\/t.co\/lWbfdNLXCl",
  "id" : 808437235695710209,
  "in_reply_to_status_id" : 804762543323488256,
  "created_at" : "2016-12-12 22:23:51 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/VCcyAyMCxt",
      "expanded_url" : "http:\/\/us13.campaign-archive1.com\/?u=4051250396fe81f55034e2d49&id=afaa541323",
      "display_url" : "us13.campaign-archive1.com\/?u=4051250396f\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "808426367545208833",
  "geo" : { },
  "id_str" : "808426533975195649",
  "in_reply_to_user_id" : 2396006202,
  "text" : "@petergrabitz found it! https:\/\/t.co\/VCcyAyMCxt",
  "id" : 808426533975195649,
  "in_reply_to_status_id" : 808426367545208833,
  "created_at" : "2016-12-12 21:41:20 +0000",
  "in_reply_to_screen_name" : "PeterRolandG",
  "in_reply_to_user_id_str" : "2396006202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 33, 49 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/808423126245711872\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/RgvAU3tG9Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzgYf-NXcAAB9k9.jpg",
      "id_str" : "808423070667075584",
      "id" : 808423070667075584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzgYf-NXcAAB9k9.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/RgvAU3tG9Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084582973909, 8.818584169074047 ]
  },
  "id_str" : "808423126245711872",
  "text" : "tfw when you see yourself in the @creativecommons newsletter. \uD83D\uDE02 @petergrabitz https:\/\/t.co\/RgvAU3tG9Z",
  "id" : 808423126245711872,
  "created_at" : "2016-12-12 21:27:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 3, 11 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/_katsel\/status\/808407076246581249\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/K8Z3cEhLi4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzgJulzXcAAe1LK.jpg",
      "id_str" : "808406829139193856",
      "id" : 808406829139193856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzgJulzXcAAe1LK.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/K8Z3cEhLi4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808420224022286337",
  "text" : "RT @_katsel: I'm so angry I made a meme https:\/\/t.co\/K8Z3cEhLi4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/_katsel\/status\/808407076246581249\/photo\/1",
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/K8Z3cEhLi4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CzgJulzXcAAe1LK.jpg",
        "id_str" : "808406829139193856",
        "id" : 808406829139193856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzgJulzXcAAe1LK.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/K8Z3cEhLi4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "808407076246581249",
    "text" : "I'm so angry I made a meme https:\/\/t.co\/K8Z3cEhLi4",
    "id" : 808407076246581249,
    "created_at" : "2016-12-12 20:24:01 +0000",
    "user" : {
      "name" : "Katharina",
      "screen_name" : "katheyrina",
      "protected" : false,
      "id_str" : "730326143295959040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885460122394349569\/oHlt5LK-_normal.jpg",
      "id" : 730326143295959040,
      "verified" : false
    }
  },
  "id" : 808420224022286337,
  "created_at" : "2016-12-12 21:16:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ci6MHBJPYQ",
      "expanded_url" : "https:\/\/twitter.com\/statnews\/status\/808401147258175488",
      "display_url" : "twitter.com\/statnews\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090003939983, 8.818763880263035 ]
  },
  "id_str" : "808419323463270401",
  "text" : "Yep, the \u2018old white dude\u2019-kind of privilege\u2026 https:\/\/t.co\/ci6MHBJPYQ",
  "id" : 808419323463270401,
  "created_at" : "2016-12-12 21:12:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "808398048489447424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081508083612, 8.818594067041248 ]
  },
  "id_str" : "808414210669559808",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski oh damn :(",
  "id" : 808414210669559808,
  "in_reply_to_status_id" : 808398048489447424,
  "created_at" : "2016-12-12 20:52:22 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/rgRRkaMK0x",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/28445426?source=ebfg_tw",
      "display_url" : "goodreads.com\/book\/show\/2844\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808406959951056896",
  "text" : "I'm missing Portland so much that I'll read this now. https:\/\/t.co\/rgRRkaMK0x",
  "id" : 808406959951056896,
  "created_at" : "2016-12-12 20:23:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/DFhnFAsJsz",
      "expanded_url" : "https:\/\/youtube.com\/watch?v=ii6kJaGiRaI",
      "display_url" : "youtube.com\/watch?v=ii6kJa\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089452711633, 8.818597242109597 ]
  },
  "id_str" : "808386056366288896",
  "text" : "Written for this year specifically\u2026 https:\/\/t.co\/DFhnFAsJsz",
  "id" : 808386056366288896,
  "created_at" : "2016-12-12 19:00:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/yEd8L3wbfz",
      "expanded_url" : "https:\/\/www.theguardian.com\/lifeandstyle\/2016\/dec\/12\/let-it-bleed-arts-revival-of-menstrual-blood?CMP=Share_iOSApp_Other",
      "display_url" : "theguardian.com\/lifeandstyle\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808348241540616192",
  "text" : "Let it bleed \u2013 art\u2019s revival of menstrual blood: \u00ABmenstruating is magic\u00BB  https:\/\/t.co\/yEd8L3wbfz",
  "id" : 808348241540616192,
  "created_at" : "2016-12-12 16:30:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/tTjcMIfRcq",
      "expanded_url" : "https:\/\/twitter.com\/CaraSantaMaria\/status\/808008450688983041",
      "display_url" : "twitter.com\/CaraSantaMaria\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35890798740774, 8.58824643307234 ]
  },
  "id_str" : "808027605744152576",
  "text" : "\u00ABWe have found every linguistic bias we looked for.\u00BB https:\/\/t.co\/tTjcMIfRcq",
  "id" : 808027605744152576,
  "created_at" : "2016-12-11 19:16:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "807938077608046600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35889939595699, 8.589084120475304 ]
  },
  "id_str" : "807938256864247808",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDE22\uD83D\uDE4F",
  "id" : 807938256864247808,
  "in_reply_to_status_id" : 807938077608046600,
  "created_at" : "2016-12-11 13:21:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "807536786721406976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35927309415569, 8.587882098703213 ]
  },
  "id_str" : "807937886104518656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot 4, plus the needed voltage converters :p",
  "id" : 807937886104518656,
  "in_reply_to_status_id" : 807536786721406976,
  "created_at" : "2016-12-11 13:19:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Howard J. Wu",
      "screen_name" : "MisterWu78",
      "indices" : [ 0, 11 ],
      "id_str" : "22278512",
      "id" : 22278512
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 12, 19 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/SRtaDJYefb",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Joulutorttu",
      "display_url" : "en.m.wikipedia.org\/wiki\/Joulutort\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "807636771492110336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36091290833543, 8.57181796761399 ]
  },
  "id_str" : "807646736240050176",
  "in_reply_to_user_id" : 22278512,
  "text" : "@MisterWu78 @Koalha https:\/\/t.co\/SRtaDJYefb actually",
  "id" : 807646736240050176,
  "in_reply_to_status_id" : 807636771492110336,
  "created_at" : "2016-12-10 18:02:41 +0000",
  "in_reply_to_screen_name" : "MisterWu78",
  "in_reply_to_user_id_str" : "22278512",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/P4AAElxXlx",
      "expanded_url" : "https:\/\/psmag.com\/creating-equity-by-teaching-equality-the-implications-of-californias-lgbtq-inclusive-framework-c4e4db55ad35?source=twitterShare-aaeb714c1b80-1481376527",
      "display_url" : "psmag.com\/creating-equit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "807577844050182144",
  "text" : "Creating Equity by Teaching Equality https:\/\/t.co\/P4AAElxXlx",
  "id" : 807577844050182144,
  "created_at" : "2016-12-10 13:28:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 7, 14 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "807564417873440768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35928255802402, 8.587673244658749 ]
  },
  "id_str" : "807577049611304960",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Koalha the moment that I wouldn\u2019t want to eat sweets will be my last. :D",
  "id" : 807577049611304960,
  "in_reply_to_status_id" : 807564417873440768,
  "created_at" : "2016-12-10 13:25:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/807548180426530816\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/LhkMuVuNZn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzT8xhiXEAAtUNu.jpg",
      "id_str" : "807548160952438784",
      "id" : 807548160952438784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzT8xhiXEAAtUNu.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/LhkMuVuNZn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "807546560955449344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35921321959923, 8.587593613507153 ]
  },
  "id_str" : "807548180426530816",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha you\u2019re right! https:\/\/t.co\/LhkMuVuNZn",
  "id" : 807548180426530816,
  "in_reply_to_status_id" : 807546560955449344,
  "created_at" : "2016-12-10 11:31:04 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "807544852959395841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35928641015447, 8.587654444730175 ]
  },
  "id_str" : "807545436542238720",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha it\u2019s my more or less regular weekly commute :D",
  "id" : 807545436542238720,
  "in_reply_to_status_id" : 807544852959395841,
  "created_at" : "2016-12-10 11:20:10 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "807544576894468096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35923144302832, 8.587615131790198 ]
  },
  "id_str" : "807545326555058176",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha that was my first reaction when I saw them actually, comes with the passport. \uD83D\uDE02",
  "id" : 807545326555058176,
  "in_reply_to_status_id" : 807544576894468096,
  "created_at" : "2016-12-10 11:19:43 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 34, 41 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/807543154987724800\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/tBYri8qc8b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzT4I6AWQAAyRIe.jpg",
      "id_str" : "807543065099517952",
      "id" : 807543065099517952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzT4I6AWQAAyRIe.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/tBYri8qc8b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35921286652763, 8.587626684005254 ]
  },
  "id_str" : "807543154987724800",
  "text" : "Look what I found in Switzerland, @Koalha! https:\/\/t.co\/tBYri8qc8b",
  "id" : 807543154987724800,
  "created_at" : "2016-12-10 11:11:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 3, 11 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Francis S. Collins",
      "screen_name" : "NIHDirector",
      "indices" : [ 14, 26 ],
      "id_str" : "124237063",
      "id" : 124237063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807506734852046848",
  "text" : "RT @mbeisen: .@NIHDirector writes public blog post about science and music linking to three articles, none of which are available to public\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Francis S. Collins",
        "screen_name" : "NIHDirector",
        "indices" : [ 1, 13 ],
        "id_str" : "124237063",
        "id" : 124237063
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/0MHnS6bWCu",
        "expanded_url" : "https:\/\/twitter.com\/NIHDirector\/status\/806873055159025664",
        "display_url" : "twitter.com\/NIHDirector\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "806878996927348736",
    "text" : ".@NIHDirector writes public blog post about science and music linking to three articles, none of which are available to public https:\/\/t.co\/0MHnS6bWCu",
    "id" : 806878996927348736,
    "created_at" : "2016-12-08 15:11:58 +0000",
    "user" : {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "protected" : false,
      "id_str" : "19843630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893602583478239236\/Gkp75Fa5_normal.jpg",
      "id" : 19843630,
      "verified" : true
    }
  },
  "id" : 807506734852046848,
  "created_at" : "2016-12-10 08:46:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/zRSD2GXW64",
      "expanded_url" : "https:\/\/i.makeagif.com\/media\/8-22-2015\/IGJalx.gif",
      "display_url" : "i.makeagif.com\/media\/8-22-201\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35967183872516, 8.587902732383185 ]
  },
  "id_str" : "807309212934094848",
  "text" : "Basically how I expect all my long distance trips to end. So far the poor car keeps surprising me. https:\/\/t.co\/zRSD2GXW64",
  "id" : 807309212934094848,
  "created_at" : "2016-12-09 19:41:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/q8Ti2DRv55",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/807121212946071552",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082866730765, 8.818663364750225 ]
  },
  "id_str" : "807123407456337920",
  "text" : "Worst Travel Guitar ever. https:\/\/t.co\/q8Ti2DRv55",
  "id" : 807123407456337920,
  "created_at" : "2016-12-09 07:23:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0607769088918, 8.818528769651422 ]
  },
  "id_str" : "806969957179412480",
  "text" : "Brain status: All of Twitter is discussing this dinosaur in amber and I\u2019m all misreading is \u2018feathered dildo\u2019\u2026",
  "id" : 806969957179412480,
  "created_at" : "2016-12-08 21:13:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806892330791895041",
  "geo" : { },
  "id_str" : "806914390427574272",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABThere are four useful MySQL commands: \u2018drop table\u2019, \u2018drop database\u2019 and \u2018quit\u2019.\u00BB \u2013 \u00ABAnd the last one?\u00BB \u2013 \u00ABHowever you uninstall it\u2026\u00BB",
  "id" : 806914390427574272,
  "in_reply_to_status_id" : 806892330791895041,
  "created_at" : "2016-12-08 17:32:37 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806892330791895041",
  "text" : "Teaching MySQL with the MySQL-Workbench. The best way to make sure that people won\u2019t touch databases with a ten foot pole.",
  "id" : 806892330791895041,
  "created_at" : "2016-12-08 16:04:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F Rodriguez-Sanchez",
      "screen_name" : "frod_san",
      "indices" : [ 3, 12 ],
      "id_str" : "326299187",
      "id" : 326299187
    }, {
      "name" : "Jake VanderPlas",
      "screen_name" : "jakevdp",
      "indices" : [ 93, 101 ],
      "id_str" : "768197780",
      "id" : 768197780
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/aZSRZnBte7",
      "expanded_url" : "https:\/\/zenodo.org\/record\/49577\/files\/In_Defense_of_Extreme_Openness.pdf",
      "display_url" : "zenodo.org\/record\/49577\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "806802534048272386",
  "text" : "RT @frod_san: 'In defense of extreme openness' https:\/\/t.co\/aZSRZnBte7. Compelling slides by @jakevdp on #openscience benefits",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jake VanderPlas",
        "screen_name" : "jakevdp",
        "indices" : [ 79, 87 ],
        "id_str" : "768197780",
        "id" : 768197780
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/aZSRZnBte7",
        "expanded_url" : "https:\/\/zenodo.org\/record\/49577\/files\/In_Defense_of_Extreme_Openness.pdf",
        "display_url" : "zenodo.org\/record\/49577\/f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "806467773115285505",
    "text" : "'In defense of extreme openness' https:\/\/t.co\/aZSRZnBte7. Compelling slides by @jakevdp on #openscience benefits",
    "id" : 806467773115285505,
    "created_at" : "2016-12-07 11:57:55 +0000",
    "user" : {
      "name" : "F Rodriguez-Sanchez",
      "screen_name" : "frod_san",
      "protected" : false,
      "id_str" : "326299187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726771918\/8eff91c8cabe7eb6736f0ca05c2d3ee4_normal.jpeg",
      "id" : 326299187,
      "verified" : false
    }
  },
  "id" : 806802534048272386,
  "created_at" : "2016-12-08 10:08:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806800140417658881",
  "geo" : { },
  "id_str" : "806801240113876992",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal yeah, if there was only SF I\u2019d rather not do any OSS :D",
  "id" : 806801240113876992,
  "in_reply_to_status_id" : 806800140417658881,
  "created_at" : "2016-12-08 10:02:59 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806795031486951426",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232105559857, 8.627556246105694 ]
  },
  "id_str" : "806799375821258754",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel yes, same problem. But at least there\u2019s a way to easily fork it that\u2019s visible to others.",
  "id" : 806799375821258754,
  "in_reply_to_status_id" : 806795031486951426,
  "created_at" : "2016-12-08 09:55:35 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 3, 11 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806799243008614401",
  "text" : "RT @_katsel: @gedankenstuecke Same if you abandon github projects and stop merging pull requests or reacting to issues :\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "806791944936402946",
    "geo" : { },
    "id_str" : "806795031486951426",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Same if you abandon github projects and stop merging pull requests or reacting to issues :\/",
    "id" : 806795031486951426,
    "in_reply_to_status_id" : 806791944936402946,
    "created_at" : "2016-12-08 09:38:19 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Katharina",
      "screen_name" : "katheyrina",
      "protected" : false,
      "id_str" : "730326143295959040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885460122394349569\/oHlt5LK-_normal.jpg",
      "id" : 730326143295959040,
      "verified" : false
    }
  },
  "id" : 806799243008614401,
  "created_at" : "2016-12-08 09:55:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806794217653551106",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230047620852, 8.627563718538221 ]
  },
  "id_str" : "806794511846232065",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal meant any public VCS for that matter. Ok, maybe not Sourceforge.",
  "id" : 806794511846232065,
  "in_reply_to_status_id" : 806794217653551106,
  "created_at" : "2016-12-08 09:36:15 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reatch",
      "screen_name" : "reat_ch",
      "indices" : [ 0, 8 ],
      "id_str" : "2659464876",
      "id" : 2659464876
    }, {
      "name" : "Servan Gr\u00FCninger",
      "screen_name" : "SGruninger",
      "indices" : [ 9, 20 ],
      "id_str" : "1361723136",
      "id" : 1361723136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/ITuV2q8xaE",
      "expanded_url" : "http:\/\/www.barrypopik.com\/index.php\/new_york_city\/entry\/everyone_is_entitled_to_his_own_opinion_but_not_his_own_facts",
      "display_url" : "barrypopik.com\/index.php\/new_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "806573898766680077",
  "geo" : { },
  "id_str" : "806792915808681984",
  "in_reply_to_user_id" : 2659464876,
  "text" : "@reat_ch @SGruninger Fakt: Prim\u00E4rquelle viel \u00E4lter. \uD83D\uDE09\uD83D\uDE02 https:\/\/t.co\/ITuV2q8xaE",
  "id" : 806792915808681984,
  "in_reply_to_status_id" : 806573898766680077,
  "created_at" : "2016-12-08 09:29:55 +0000",
  "in_reply_to_screen_name" : "reat_ch",
  "in_reply_to_user_id_str" : "2659464876",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806791944936402946",
  "text" : "If your software\u2019s not on GitHub you cheat me out of the chance of fixing the bugs I found for everyone\u2026",
  "id" : 806791944936402946,
  "created_at" : "2016-12-08 09:26:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 3, 14 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806790008254271488",
  "text" : "RT @LouWoodley: \"You wouldn't call someone hospitable unless they'd actually hosted another person. Inclusion is an *active* process.\" #moz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozAloha",
        "indices" : [ 119, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "806694476605366273",
    "text" : "\"You wouldn't call someone hospitable unless they'd actually hosted another person. Inclusion is an *active* process.\" #mozAloha",
    "id" : 806694476605366273,
    "created_at" : "2016-12-08 02:58:45 +0000",
    "user" : {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "protected" : false,
      "id_str" : "20342875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415633332408688640\/IRl4qNXY_normal.jpeg",
      "id" : 20342875,
      "verified" : false
    }
  },
  "id" : 806790008254271488,
  "created_at" : "2016-12-08 09:18:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/SoKdZReAdA",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNv8ohrjcln\/",
      "display_url" : "instagram.com\/p\/BNv8ohrjcln\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1730170954, 8.6300153675 ]
  },
  "id_str" : "806774950900080640",
  "text" : "It's all a blur @ Uni Frankfurt Campus Riedberg https:\/\/t.co\/SoKdZReAdA",
  "id" : 806774950900080640,
  "created_at" : "2016-12-08 08:18:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806633876437118976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402762788727, 8.75342137264055 ]
  },
  "id_str" : "806633981173186561",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes guess who\u2019s hunting for his charger right now!",
  "id" : 806633981173186561,
  "in_reply_to_status_id" : 806633876437118976,
  "created_at" : "2016-12-07 22:58:22 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806576898138513408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403749119236, 8.753406936611752 ]
  },
  "id_str" : "806577307687288839",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski I had to double check, but that\u2019s not the case. Would have been the worst teaching day ever.",
  "id" : 806577307687288839,
  "in_reply_to_status_id" : 806576898138513408,
  "created_at" : "2016-12-07 19:13:10 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403741701046, 8.753406152013474 ]
  },
  "id_str" : "806576615215992833",
  "text" : "Today I forgot: my office key, my public transport ticket and now even my headphones.",
  "id" : 806576615215992833,
  "created_at" : "2016-12-07 19:10:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806448778970415106",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17260494472759, 8.62745340158284 ]
  },
  "id_str" : "806450065657266181",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks!",
  "id" : 806450065657266181,
  "in_reply_to_status_id" : 806448778970415106,
  "created_at" : "2016-12-07 10:47:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806429974030782464",
  "geo" : { },
  "id_str" : "806433581585276929",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer How did the \u201EDarnkn\u201C even happen? \uD83D\uDE15",
  "id" : 806433581585276929,
  "in_reply_to_status_id" : 806429974030782464,
  "created_at" : "2016-12-07 09:42:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 28, 39 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806389031747645440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087029585402, 8.818446850435436 ]
  },
  "id_str" : "806390443135135745",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr yes, working with @LouWoodley should make sure of that!",
  "id" : 806390443135135745,
  "in_reply_to_status_id" : 806389031747645440,
  "created_at" : "2016-12-07 06:50:38 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/4e7Ym5x1rG",
      "expanded_url" : "https:\/\/twitter.com\/dog_rates\/status\/806269335417327617",
      "display_url" : "twitter.com\/dog_rates\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082452552784, 8.81870216908699 ]
  },
  "id_str" : "806286502561017858",
  "text" : "How to get through every single day. \uD83D\uDC4B\uD83D\uDC36 https:\/\/t.co\/4e7Ym5x1rG",
  "id" : 806286502561017858,
  "created_at" : "2016-12-06 23:57:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806260747860905984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088986324429, 8.818629580127858 ]
  },
  "id_str" : "806262892756606977",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye thanks!",
  "id" : 806262892756606977,
  "in_reply_to_status_id" : 806260747860905984,
  "created_at" : "2016-12-06 22:23:47 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beck Pitt",
      "screen_name" : "BeckPitt",
      "indices" : [ 0, 9 ],
      "id_str" : "176841064",
      "id" : 176841064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806193991087702017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085357769621, 8.818581669280867 ]
  },
  "id_str" : "806262773969801216",
  "in_reply_to_user_id" : 176841064,
  "text" : "@BeckPitt cheers \uD83C\uDF7B",
  "id" : 806262773969801216,
  "in_reply_to_status_id" : 806193991087702017,
  "created_at" : "2016-12-06 22:23:19 +0000",
  "in_reply_to_screen_name" : "BeckPitt",
  "in_reply_to_user_id_str" : "176841064",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806163316578091011",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081724239568, 8.818697496994146 ]
  },
  "id_str" : "806259912854700032",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr congratulations! \uD83C\uDF88",
  "id" : 806259912854700032,
  "in_reply_to_status_id" : 806163316578091011,
  "created_at" : "2016-12-06 22:11:57 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u033Ce\u0325b\u0353a\u0330s\u032Cti\u035Aa\u0349n\u034E M\u031Fo\u034Drr\u033B",
      "screen_name" : "blinry",
      "indices" : [ 3, 10 ],
      "id_str" : "53749209",
      "id" : 53749209
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 12, 28 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806123313059786753",
  "text" : "RT @blinry: @gedankenstuecke cat into a pipe is such a bad habit, though.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "806095391540252672",
    "geo" : { },
    "id_str" : "806100162510626816",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke cat into a pipe is such a bad habit, though.",
    "id" : 806100162510626816,
    "in_reply_to_status_id" : 806095391540252672,
    "created_at" : "2016-12-06 11:37:10 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "S\u033Ce\u0325b\u0353a\u0330s\u032Cti\u035Aa\u0349n\u034E M\u031Fo\u034Drr\u033B",
      "screen_name" : "blinry",
      "protected" : false,
      "id_str" : "53749209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877094494654562304\/w12Rwl23_normal.jpg",
      "id" : 53749209,
      "verified" : false
    }
  },
  "id" : 806123313059786753,
  "created_at" : "2016-12-06 13:09:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/d4ab66YLIG",
      "expanded_url" : "https:\/\/twitter.com\/NazeefaFatima\/status\/806005524940603392",
      "display_url" : "twitter.com\/NazeefaFatima\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236801242088, 8.627520767368209 ]
  },
  "id_str" : "806095391540252672",
  "text" : "What I\u2019ll show the students today. https:\/\/t.co\/d4ab66YLIG",
  "id" : 806095391540252672,
  "created_at" : "2016-12-06 11:18:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805892164064514048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088426309957, 8.818603493538074 ]
  },
  "id_str" : "805892311796301825",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb also nice! \uD83D\uDC4D",
  "id" : 805892311796301825,
  "in_reply_to_status_id" : 805892164064514048,
  "created_at" : "2016-12-05 21:51:14 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805887981781471232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086455838348, 8.818750086509954 ]
  },
  "id_str" : "805889266421207040",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb facetting by whatever the color is?",
  "id" : 805889266421207040,
  "in_reply_to_status_id" : 805887981781471232,
  "created_at" : "2016-12-05 21:39:08 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805881879278788608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090327781746, 8.818417079231017 ]
  },
  "id_str" : "805882711441342464",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb I remembered that we had that conversation once :D",
  "id" : 805882711441342464,
  "in_reply_to_status_id" : 805881879278788608,
  "created_at" : "2016-12-05 21:13:05 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/VRCdQmm0rJ",
      "expanded_url" : "https:\/\/github.com\/slowkow\/ggrepel",
      "display_url" : "github.com\/slowkow\/ggrepel"
    } ]
  },
  "in_reply_to_status_id_str" : "805864337948737536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092678850887, 8.818606100892856 ]
  },
  "id_str" : "805879799982018565",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb another case for https:\/\/t.co\/VRCdQmm0rJ? ;)",
  "id" : 805879799982018565,
  "in_reply_to_status_id" : 805864337948737536,
  "created_at" : "2016-12-05 21:01:31 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 3, 13 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/l7JIYohfuu",
      "expanded_url" : "https:\/\/twitter.com\/nazeefafatima\/status\/805786146513047553",
      "display_url" : "twitter.com\/nazeefafatima\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "805854798641827840",
  "text" : "RT @Julie_B92: Google needs to up its nerd game https:\/\/t.co\/l7JIYohfuu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/l7JIYohfuu",
        "expanded_url" : "https:\/\/twitter.com\/nazeefafatima\/status\/805786146513047553",
        "display_url" : "twitter.com\/nazeefafatima\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "805813929373003776",
    "text" : "Google needs to up its nerd game https:\/\/t.co\/l7JIYohfuu",
    "id" : 805813929373003776,
    "created_at" : "2016-12-05 16:39:46 +0000",
    "user" : {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "protected" : false,
      "id_str" : "1385861262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813827716151644160\/JvmX-W-T_normal.jpg",
      "id" : 1385861262,
      "verified" : false
    }
  },
  "id" : 805854798641827840,
  "created_at" : "2016-12-05 19:22:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805843218562744320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06100520496262, 8.81847443059908 ]
  },
  "id_str" : "805853770122936320",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice \uD83D\uDE4F\uD83D\uDE4F\uD83D\uDE4F",
  "id" : 805853770122936320,
  "in_reply_to_status_id" : 805843218562744320,
  "created_at" : "2016-12-05 19:18:05 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/iSd2xNf8d7",
      "expanded_url" : "https:\/\/femsplain.com\/the-internet-is-great-for-men-f71fe4407bc5?source=twitterShare-aaeb714c1b80-1480965368",
      "display_url" : "femsplain.com\/the-internet-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "805853322246836225",
  "text" : "The Internet Is Great (For Men) https:\/\/t.co\/iSd2xNf8d7",
  "id" : 805853322246836225,
  "created_at" : "2016-12-05 19:16:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 11, 24 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 25, 33 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805802585907195904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229475906095, 8.627519146865616 ]
  },
  "id_str" : "805811434055733249",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser @RaoOfPhysics @betatim \uD83D\uDC4C  \uD83D\uDE0A  \uD83D\uDE01  \uD83D\uDE0E",
  "id" : 805811434055733249,
  "in_reply_to_status_id" : 805802585907195904,
  "created_at" : "2016-12-05 16:29:51 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805704346704998401",
  "geo" : { },
  "id_str" : "805731044708204546",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 it\u2019s one of my favorite ones too! \uD83D\uDC96",
  "id" : 805731044708204546,
  "in_reply_to_status_id" : 805704346704998401,
  "created_at" : "2016-12-05 11:10:25 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/YypNiUc33x",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/o0vwzuFwCGAFO\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/o0vwzuFw\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "805703849046634496",
  "geo" : { },
  "id_str" : "805704079401959424",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 to make up for it: https:\/\/t.co\/YypNiUc33x",
  "id" : 805704079401959424,
  "in_reply_to_status_id" : 805703849046634496,
  "created_at" : "2016-12-05 09:23:16 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/805702249532063744\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/Vpb4yLfYFd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cy5t7JbW8AE03wj.png",
      "id_str" : "805702246256275457",
      "id" : 805702246256275457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cy5t7JbW8AE03wj.png",
      "sizes" : [ {
        "h" : 803,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 445
      } ],
      "display_url" : "pic.twitter.com\/Vpb4yLfYFd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805702249532063744",
  "text" : "Motivating students to use the bash, today\u2019s carrot: imgcat. https:\/\/t.co\/Vpb4yLfYFd",
  "id" : 805702249532063744,
  "created_at" : "2016-12-05 09:16:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/yX9m0Hm0Ej",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/qJxFuXXWpkdEI\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/qJxFuXXW\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "805690079213535232",
  "geo" : { },
  "id_str" : "805692299892183041",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog https:\/\/t.co\/yX9m0Hm0Ej",
  "id" : 805692299892183041,
  "in_reply_to_status_id" : 805690079213535232,
  "created_at" : "2016-12-05 08:36:27 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/RkeKf8YvAT",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/the-science-is-unsettled",
      "display_url" : "smbc-comics.com\/comic\/the-scie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "805687699042668544",
  "text" : "True story, each student of evolutionary biology &amp; paleontology has to give an oath to keep this secret. https:\/\/t.co\/RkeKf8YvAT",
  "id" : 805687699042668544,
  "created_at" : "2016-12-05 08:18:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/skRf3R11pM",
      "expanded_url" : "https:\/\/broadly.vice.com\/en_us\/article\/triple-talaq-instant-divorce-india",
      "display_url" : "broadly.vice.com\/en_us\/article\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "805687045872091136",
  "text" : "The Muslim Women Fighting to Ban Instantaneous Divorce in India https:\/\/t.co\/skRf3R11pM",
  "id" : 805687045872091136,
  "created_at" : "2016-12-05 08:15:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael augustine: dreamer, thinker, doer",
      "screen_name" : "mycoolaugustine",
      "indices" : [ 3, 19 ],
      "id_str" : "102611957",
      "id" : 102611957
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mycoolaugustine\/status\/805240612890951680\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/JcmnG294Kj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyzKDAqVEAEm307.jpg",
      "id_str" : "805240586458435585",
      "id" : 805240586458435585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyzKDAqVEAEm307.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/JcmnG294Kj"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/mycoolaugustine\/status\/805240612890951680\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/JcmnG294Kj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyzKDAqVEAAoigA.jpg",
      "id_str" : "805240586458435584",
      "id" : 805240586458435584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyzKDAqVEAAoigA.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/JcmnG294Kj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805569708053430272",
  "text" : "RT @mycoolaugustine: here's the real peril of unisex bathrooms https:\/\/t.co\/JcmnG294Kj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mycoolaugustine\/status\/805240612890951680\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/JcmnG294Kj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CyzKDAqVEAEm307.jpg",
        "id_str" : "805240586458435585",
        "id" : 805240586458435585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyzKDAqVEAEm307.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/JcmnG294Kj"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/mycoolaugustine\/status\/805240612890951680\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/JcmnG294Kj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CyzKDAqVEAAoigA.jpg",
        "id_str" : "805240586458435584",
        "id" : 805240586458435584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyzKDAqVEAAoigA.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/JcmnG294Kj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "805240612890951680",
    "text" : "here's the real peril of unisex bathrooms https:\/\/t.co\/JcmnG294Kj",
    "id" : 805240612890951680,
    "created_at" : "2016-12-04 02:41:37 +0000",
    "user" : {
      "name" : "michael augustine: dreamer, thinker, doer",
      "screen_name" : "mycoolaugustine",
      "protected" : false,
      "id_str" : "102611957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/869536248259411968\/E9s8yIk8_normal.jpg",
      "id" : 102611957,
      "verified" : false
    }
  },
  "id" : 805569708053430272,
  "created_at" : "2016-12-05 00:29:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Science",
      "screen_name" : "FakeScience",
      "indices" : [ 3, 15 ],
      "id_str" : "120252183",
      "id" : 120252183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FakeScience\/status\/805291042568343553\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/aUSpzN2lIs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyxhP8GW8AAWdO2.jpg",
      "id_str" : "805125359851204608",
      "id" : 805125359851204608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyxhP8GW8AAWdO2.jpg",
      "sizes" : [ {
        "h" : 550,
        "resize" : "fit",
        "w" : 424
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 424
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 424
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 424
      } ],
      "display_url" : "pic.twitter.com\/aUSpzN2lIs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805331810599239680",
  "text" : "RT @FakeScience: Beautiful. https:\/\/t.co\/aUSpzN2lIs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FakeScience\/status\/805291042568343553\/photo\/1",
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/aUSpzN2lIs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CyxhP8GW8AAWdO2.jpg",
        "id_str" : "805125359851204608",
        "id" : 805125359851204608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyxhP8GW8AAWdO2.jpg",
        "sizes" : [ {
          "h" : 550,
          "resize" : "fit",
          "w" : 424
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 424
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 424
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 424
        } ],
        "display_url" : "pic.twitter.com\/aUSpzN2lIs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "805291042568343553",
    "text" : "Beautiful. https:\/\/t.co\/aUSpzN2lIs",
    "id" : 805291042568343553,
    "created_at" : "2016-12-04 06:02:00 +0000",
    "user" : {
      "name" : "Fake Science",
      "screen_name" : "FakeScience",
      "protected" : false,
      "id_str" : "120252183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670456080875569152\/wnOFNz1Y_normal.jpg",
      "id" : 120252183,
      "verified" : false
    }
  },
  "id" : 805331810599239680,
  "created_at" : "2016-12-04 08:44:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805072237141364736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35931708845865, 8.587837257961723 ]
  },
  "id_str" : "805072335065780224",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye awesome, bookmarked for reading later!",
  "id" : 805072335065780224,
  "in_reply_to_status_id" : 805072237141364736,
  "created_at" : "2016-12-03 15:32:56 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804796669690843136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35931708845865, 8.587837257961723 ]
  },
  "id_str" : "805072246662451200",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Aluhut bis ins Grab?",
  "id" : 805072246662451200,
  "in_reply_to_status_id" : 804796669690843136,
  "created_at" : "2016-12-03 15:32:35 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804986652615643136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35931708845865, 8.587837257961723 ]
  },
  "id_str" : "805072176986685440",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye is this the article you talked about? :)",
  "id" : 805072176986685440,
  "in_reply_to_status_id" : 804986652615643136,
  "created_at" : "2016-12-03 15:32:19 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD2E Sam Maggs \uD83D\uDD2E",
      "screen_name" : "SamMaggs",
      "indices" : [ 16, 25 ],
      "id_str" : "191221920",
      "id" : 191221920
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/804762543323488256\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/8TmAwDKZhV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CysXQu3WgAAD41V.jpg",
      "id_str" : "804762534641303552",
      "id" : 804762534641303552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CysXQu3WgAAD41V.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8TmAwDKZhV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35851595488884, 8.586055217572676 ]
  },
  "id_str" : "804762543323488256",
  "text" : "Wonder Women by @SamMaggs is such a great book to read to each other! \uD83D\uDCDA\uD83D\uDC96 https:\/\/t.co\/8TmAwDKZhV",
  "id" : 804762543323488256,
  "created_at" : "2016-12-02 19:01:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804707051331010566",
  "text" : "RT @o_guest: Reminding everybody: Being called a bitch at work is NEVER OK. And it doesn't matter if it's a \"joke\" \u2014 it's just as sexist an\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/804704748591058944\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/mtWqGqvrue",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CyrirmaWQAERe5u.jpg",
        "id_str" : "804704722112364545",
        "id" : 804704722112364545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyrirmaWQAERe5u.jpg",
        "sizes" : [ {
          "h" : 523,
          "resize" : "fit",
          "w" : 386
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 386
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 386
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 386
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/mtWqGqvrue"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "804704748591058944",
    "text" : "Reminding everybody: Being called a bitch at work is NEVER OK. And it doesn't matter if it's a \"joke\" \u2014 it's just as sexist and as serious. https:\/\/t.co\/mtWqGqvrue",
    "id" : 804704748591058944,
    "created_at" : "2016-12-02 15:12:17 +0000",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 804707051331010566,
  "created_at" : "2016-12-02 15:21:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804680385443594240",
  "geo" : { },
  "id_str" : "804704756195356672",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot subtweeting me? :P",
  "id" : 804704756195356672,
  "in_reply_to_status_id" : 804680385443594240,
  "created_at" : "2016-12-02 15:12:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/excBa28pZC",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/804646290587930626",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804697832024342529",
  "text" : "I\u2019m so glad it\u2019s not only me doing this \uD83D\uDE07\uD83D\uDE33 https:\/\/t.co\/excBa28pZC",
  "id" : 804697832024342529,
  "created_at" : "2016-12-02 14:44:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "EyesOnALZ",
      "screen_name" : "eyesonalz",
      "indices" : [ 9, 19 ],
      "id_str" : "4294598053",
      "id" : 4294598053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/SGPLtWhdVC",
      "expanded_url" : "https:\/\/www.mail-tester.com\/",
      "display_url" : "mail-tester.com"
    } ]
  },
  "in_reply_to_status_id_str" : "804654538280026112",
  "geo" : { },
  "id_str" : "804677644923060224",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute @eyesonalz try https:\/\/t.co\/SGPLtWhdVC to see what you could improve, that\u2019s what we did. :-)",
  "id" : 804677644923060224,
  "in_reply_to_status_id" : 804654538280026112,
  "created_at" : "2016-12-02 13:24:35 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandi Dheensa",
      "screen_name" : "Sandi_Dheensa",
      "indices" : [ 0, 14 ],
      "id_str" : "1863518726",
      "id" : 1863518726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804647730345897984",
  "geo" : { },
  "id_str" : "804677239694643200",
  "in_reply_to_user_id" : 1863518726,
  "text" : "@Sandi_Dheensa no reference to it I think.",
  "id" : 804677239694643200,
  "in_reply_to_status_id" : 804647730345897984,
  "created_at" : "2016-12-02 13:22:58 +0000",
  "in_reply_to_screen_name" : "Sandi_Dheensa",
  "in_reply_to_user_id_str" : "1863518726",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804617315618787328",
  "geo" : { },
  "id_str" : "804645878631976961",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute having the same issue?",
  "id" : 804645878631976961,
  "in_reply_to_status_id" : 804617315618787328,
  "created_at" : "2016-12-02 11:18:21 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 10, 17 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "MyVariant.info",
      "screen_name" : "myvariantinfo",
      "indices" : [ 18, 32 ],
      "id_str" : "3023231568",
      "id" : 3023231568
    }, {
      "name" : "F\u24D0bi\u24D0n\u24D0 Kubke",
      "screen_name" : "Kubke",
      "indices" : [ 33, 39 ],
      "id_str" : "20491064",
      "id" : 20491064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804407616558497792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35932538786361, 8.587804815972188 ]
  },
  "id_str" : "804602073589366784",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @McDawg @myvariantinfo @Kubke every time I feel a bit down I look at this and then things are okay again. \uD83D\uDC96",
  "id" : 804602073589366784,
  "in_reply_to_status_id" : 804407616558497792,
  "created_at" : "2016-12-02 08:24:17 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/gyC7FT31gr",
      "expanded_url" : "https:\/\/twitter.com\/FakeLibStats\/status\/804337164507090945",
      "display_url" : "twitter.com\/FakeLibStats\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35932538786361, 8.587804815972188 ]
  },
  "id_str" : "804601799105712128",
  "text" : "Found my weekend activity. https:\/\/t.co\/gyC7FT31gr",
  "id" : 804601799105712128,
  "created_at" : "2016-12-02 08:23:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804406026963472384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35932538786361, 8.587804815972188 ]
  },
  "id_str" : "804601446813536256",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara congrats!",
  "id" : 804601446813536256,
  "in_reply_to_status_id" : 804406026963472384,
  "created_at" : "2016-12-02 08:21:48 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723970358489, 8.627579957470545 ]
  },
  "id_str" : "804593551430549508",
  "text" : "\u00ABI\u2019d even miss you a bit if you\u2019d publish junk in PNAS.\u00BB",
  "id" : 804593551430549508,
  "created_at" : "2016-12-02 07:50:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804367096775852034",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37183784147021, 8.550008164245956 ]
  },
  "id_str" : "804367530563342336",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski i bet for some it\u2019s measured in the height of the paper tower on their desk. \uD83D\uDCDA\uD83D\uDCDA\uD83D\uDCDA\uD83D\uDCDA",
  "id" : 804367530563342336,
  "in_reply_to_status_id" : 804367096775852034,
  "created_at" : "2016-12-01 16:52:18 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/O8Y6jIYYIJ",
      "expanded_url" : "http:\/\/africasacountry.com\/2015\/03\/the-unexpected-popularity-of-dire-straits-in-north-african-tuareg-communities\/",
      "display_url" : "africasacountry.com\/2015\/03\/the-un\u2026"
    }, {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/fjRoQ0LuZ5",
      "expanded_url" : "https:\/\/twitter.com\/TomWhitwell\/status\/804241781995012096",
      "display_url" : "twitter.com\/TomWhitwell\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37208378907578, 8.549743045449995 ]
  },
  "id_str" : "804365114040340480",
  "text" : "How I learned about \u00ABThe Unexpected Popularity of Dire Straits in North African Tuareg Communities\u00BB https:\/\/t.co\/O8Y6jIYYIJ https:\/\/t.co\/fjRoQ0LuZ5",
  "id" : 804365114040340480,
  "created_at" : "2016-12-01 16:42:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 10, 20 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804346624189276161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37218114393653, 8.549741132289153 ]
  },
  "id_str" : "804346776228601856",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @kaythaney my job here is done. \uD83D\uDE02",
  "id" : 804346776228601856,
  "in_reply_to_status_id" : 804346624189276161,
  "created_at" : "2016-12-01 15:29:50 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 10, 20 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/KyFsfgTSi0",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/2a6fjfpay3dmpr0\/bioinformagic.gif?dl=0",
      "display_url" : "dropbox.com\/s\/2a6fjfpay3dm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "804345849664962560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37219304452429, 8.549665522234221 ]
  },
  "id_str" : "804346367338496000",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @kaythaney file Names are not sensible meta data! https:\/\/t.co\/KyFsfgTSi0",
  "id" : 804346367338496000,
  "in_reply_to_status_id" : 804345849664962560,
  "created_at" : "2016-12-01 15:28:12 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 10, 18 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3719511088425, 8.549839379273866 ]
  },
  "id_str" : "804345361481474048",
  "text" : "@quominus @o_guest you\u2019ll do great. \uD83C\uDF89\uD83D\uDC98",
  "id" : 804345361481474048,
  "created_at" : "2016-12-01 15:24:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/vdAED9f3iy",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNNmVBODPht\/",
      "display_url" : "instagram.com\/p\/BNNmVBODPht\/"
    } ]
  },
  "geo" : { },
  "id_str" : "804345099920506881",
  "text" : "RT @gedankenstuecke: Endless Names @ National AIDS Memorial Grove https:\/\/t.co\/vdAED9f3iy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/vdAED9f3iy",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BNNmVBODPht\/",
        "display_url" : "instagram.com\/p\/BNNmVBODPht\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.77038, -122.4603 ]
    },
    "id_str" : "801940823357198336",
    "text" : "Endless Names @ National AIDS Memorial Grove https:\/\/t.co\/vdAED9f3iy",
    "id" : 801940823357198336,
    "created_at" : "2016-11-25 00:09:26 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 804345099920506881,
  "created_at" : "2016-12-01 15:23:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804336479480795136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37219086598576, 8.54965374270591 ]
  },
  "id_str" : "804340513029689344",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot but: finding your missing sex toy is priceless.",
  "id" : 804340513029689344,
  "in_reply_to_status_id" : 804336479480795136,
  "created_at" : "2016-12-01 15:04:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/J5WV1biKro",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/804332252691886080",
      "display_url" : "twitter.com\/Lobot\/status\/8\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37200283109471, 8.54975945541633 ]
  },
  "id_str" : "804336069974093824",
  "text" : "Finding Tuber melanosporum is so out. https:\/\/t.co\/J5WV1biKro",
  "id" : 804336069974093824,
  "created_at" : "2016-12-01 14:47:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Servan Gr\u00FCninger",
      "screen_name" : "SGruninger",
      "indices" : [ 0, 11 ],
      "id_str" : "1361723136",
      "id" : 1361723136
    }, {
      "name" : "Natalie Banner",
      "screen_name" : "natalie_banner",
      "indices" : [ 12, 27 ],
      "id_str" : "793682456",
      "id" : 793682456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804334288338620417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37200283109471, 8.54975945541633 ]
  },
  "id_str" : "804335297836224512",
  "in_reply_to_user_id" : 1361723136,
  "text" : "@SGruninger @natalie_banner (also: no matter which metaphor you use,it\u2019s basically just visual clutter without much benefit in this context)",
  "id" : 804335297836224512,
  "in_reply_to_status_id" : 804334288338620417,
  "created_at" : "2016-12-01 14:44:13 +0000",
  "in_reply_to_screen_name" : "SGruninger",
  "in_reply_to_user_id_str" : "1361723136",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Servan Gr\u00FCninger",
      "screen_name" : "SGruninger",
      "indices" : [ 17, 28 ],
      "id_str" : "1361723136",
      "id" : 1361723136
    }, {
      "name" : "Natalie Banner",
      "screen_name" : "natalie_banner",
      "indices" : [ 29, 44 ],
      "id_str" : "793682456",
      "id" : 793682456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/1nKj72A2tz",
      "expanded_url" : "http:\/\/photos1.blogger.com\/blogger\/803\/3347\/1600\/stevens%20mario.jpg",
      "display_url" : "photos1.blogger.com\/blogger\/803\/33\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "804334451912216580",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37199399628391, 8.549752595703183 ]
  },
  "id_str" : "804334715096432640",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @SGruninger @natalie_banner https:\/\/t.co\/1nKj72A2tz",
  "id" : 804334715096432640,
  "in_reply_to_status_id" : 804334451912216580,
  "created_at" : "2016-12-01 14:41:54 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Servan Gr\u00FCninger",
      "screen_name" : "SGruninger",
      "indices" : [ 0, 11 ],
      "id_str" : "1361723136",
      "id" : 1361723136
    }, {
      "name" : "Natalie Banner",
      "screen_name" : "natalie_banner",
      "indices" : [ 12, 27 ],
      "id_str" : "793682456",
      "id" : 793682456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804333287011389442",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37220244364664, 8.549669732925064 ]
  },
  "id_str" : "804333464271122433",
  "in_reply_to_user_id" : 1361723136,
  "text" : "@SGruninger @natalie_banner mine is: don\u2019t use any. I think in 2016 everyone knows what the internet is and has their own mental model of it",
  "id" : 804333464271122433,
  "in_reply_to_status_id" : 804333287011389442,
  "created_at" : "2016-12-01 14:36:56 +0000",
  "in_reply_to_screen_name" : "SGruninger",
  "in_reply_to_user_id_str" : "1361723136",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Banner",
      "screen_name" : "natalie_banner",
      "indices" : [ 3, 18 ],
      "id_str" : "793682456",
      "id" : 793682456
    }, {
      "name" : "Servan Gr\u00FCninger",
      "screen_name" : "SGruninger",
      "indices" : [ 20, 31 ],
      "id_str" : "1361723136",
      "id" : 1361723136
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 32, 48 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804333275665825793",
  "text" : "RT @natalie_banner: @SGruninger @gedankenstuecke I agree the 0s &amp; 1s pipeline isn't helpful! Disconnects ppl from discourse about data use\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Servan Gr\u00FCninger",
        "screen_name" : "SGruninger",
        "indices" : [ 0, 11 ],
        "id_str" : "1361723136",
        "id" : 1361723136
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 12, 28 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dighealthzh",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "804330901459046401",
    "geo" : { },
    "id_str" : "804332901785600000",
    "in_reply_to_user_id" : 1361723136,
    "text" : "@SGruninger @gedankenstuecke I agree the 0s &amp; 1s pipeline isn't helpful! Disconnects ppl from discourse about data use #dighealthzh",
    "id" : 804332901785600000,
    "in_reply_to_status_id" : 804330901459046401,
    "created_at" : "2016-12-01 14:34:42 +0000",
    "in_reply_to_screen_name" : "SGruninger",
    "in_reply_to_user_id_str" : "1361723136",
    "user" : {
      "name" : "Natalie Banner",
      "screen_name" : "natalie_banner",
      "protected" : false,
      "id_str" : "793682456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692744116212482048\/FmjYsaxO_normal.jpg",
      "id" : 793682456,
      "verified" : false
    }
  },
  "id" : 804333275665825793,
  "created_at" : "2016-12-01 14:36:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 0, 12 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804329474133295105",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37207943338641, 8.549738169985448 ]
  },
  "id_str" : "804330284430872576",
  "in_reply_to_user_id" : 214099847,
  "text" : "@jonfwilkins also: what\u2019s up with the blue? Did the matrix copyright the shade of green?",
  "id" : 804330284430872576,
  "in_reply_to_status_id" : 804329474133295105,
  "created_at" : "2016-12-01 14:24:18 +0000",
  "in_reply_to_screen_name" : "jonfwilkins",
  "in_reply_to_user_id_str" : "214099847",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804329498602852352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37207943338641, 8.549738169985448 ]
  },
  "id_str" : "804330148791287809",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock would have been more believable if they announced the logo with that right away. (Not sure if they did, but as I can\u2019t find out\u2026)",
  "id" : 804330148791287809,
  "in_reply_to_status_id" : 804329498602852352,
  "created_at" : "2016-12-01 14:23:45 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 11, 20 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/TluXSkL5iN",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/oh-snap-3o6ozC2VM9R0XSMNKo",
      "display_url" : "giphy.com\/gifs\/oh-snap-3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "804328359144648705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37219293887074, 8.549665716549425 ]
  },
  "id_str" : "804329696062296064",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney @wilbanks in that case i want to talk about something with him! https:\/\/t.co\/TluXSkL5iN",
  "id" : 804329696062296064,
  "in_reply_to_status_id" : 804328359144648705,
  "created_at" : "2016-12-01 14:21:57 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804328476182478848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37219293887074, 8.549665716549425 ]
  },
  "id_str" : "804328991150764036",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock totally doesn\u2019t sound post-hoc ;)",
  "id" : 804328991150764036,
  "in_reply_to_status_id" : 804328476182478848,
  "created_at" : "2016-12-01 14:19:09 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jB3PPanh50",
      "expanded_url" : "http:\/\/www.dac.us\/Uploads\/image\/CSC\/IA_CND_Internet_pipe_2.jpg",
      "display_url" : "dac.us\/Uploads\/image\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37207285524632, 8.549743400243086 ]
  },
  "id_str" : "804327677821931520",
  "text" : "Can we all please stop using images like the pipes in slides? Also: don\u2019t use left-handed DNA at health conferences\uD83D\uDE1E https:\/\/t.co\/jB3PPanh50",
  "id" : 804327677821931520,
  "created_at" : "2016-12-01 14:13:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/7jFxAhHPfV",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/804321863430246400",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "804321863430246400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37219355351179, 8.549665070880424 ]
  },
  "id_str" : "804322116652957696",
  "in_reply_to_user_id" : 14286491,
  "text" : "@chartgerink interesting to you too? :) https:\/\/t.co\/7jFxAhHPfV",
  "id" : 804322116652957696,
  "in_reply_to_status_id" : 804321863430246400,
  "created_at" : "2016-12-01 13:51:50 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 72, 85 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/nBk75dEwTk",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371%2Fjournal.pcbi.1005017&utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ploscompbiol%2FNewArticles+%28PLOS+Computational+Biology+-+New+Articles%29",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804321863430246400",
  "text" : "Text Mining Genotype-Phenotype Relationships from Biomedical Literature @PhilippBayer  https:\/\/t.co\/nBk75dEwTk",
  "id" : 804321863430246400,
  "created_at" : "2016-12-01 13:50:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804320371851853824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37207619804019, 8.549770279280924 ]
  },
  "id_str" : "804320630103560192",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot first date, second date, tomato date, butt of war date.",
  "id" : 804320630103560192,
  "in_reply_to_status_id" : 804320371851853824,
  "created_at" : "2016-12-01 13:45:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804318066796531712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3721482080261, 8.549824634414236 ]
  },
  "id_str" : "804319309648502786",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot finally an idea what to try next for a fun first date activity.",
  "id" : 804319309648502786,
  "in_reply_to_status_id" : 804318066796531712,
  "created_at" : "2016-12-01 13:40:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Banner",
      "screen_name" : "natalie_banner",
      "indices" : [ 85, 100 ],
      "id_str" : "793682456",
      "id" : 793682456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthZh",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3721482080261, 8.549824634414236 ]
  },
  "id_str" : "804318648831766529",
  "text" : "On the need for better language when discussing sharing data in a medical context by @natalie_banner #dighealthZh",
  "id" : 804318648831766529,
  "created_at" : "2016-12-01 13:38:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804315560016281600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37214744485837, 8.549840818048036 ]
  },
  "id_str" : "804315677389651969",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot clutching my pearls already! :p",
  "id" : 804315677389651969,
  "in_reply_to_status_id" : 804315560016281600,
  "created_at" : "2016-12-01 13:26:15 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/HK8z3tXv5P",
      "expanded_url" : "https:\/\/shift.newco.co\/an-open-letter-to-my-boss-ibm-ceo-ginni-rometty-cf40c3ed5ddb?source=twitterShare-aaeb714c1b80-1480598644",
      "display_url" : "shift.newco.co\/an-open-letter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804315223792427009",
  "text" : "\u00ABIBM\u2019s values: a willingness to legitimize threats to our country for financial gain\u00BB https:\/\/t.co\/HK8z3tXv5P",
  "id" : 804315223792427009,
  "created_at" : "2016-12-01 13:24:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 76, 85 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthZh",
      "indices" : [ 87, 99 ]
    }, {
      "text" : "digitalethics",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/A0Hwf66c49",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/804283890705793024",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "804283890705793024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37219214621631, 8.549686980419407 ]
  },
  "id_str" : "804286392494911488",
  "in_reply_to_user_id" : 14286491,
  "text" : "And if you want some help in wielding your \u2018right to access\u2019-stick: talk to @podehaye! #dighealthZh #digitalethics https:\/\/t.co\/A0Hwf66c49",
  "id" : 804286392494911488,
  "in_reply_to_status_id" : 804283890705793024,
  "created_at" : "2016-12-01 11:29:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthZh",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37219526637022, 8.54966389759598 ]
  },
  "id_str" : "804284538562236416",
  "text" : "Everyone here seems eager to show pictures of Obama, as mentioned earlier \u201Cas long as we still can\u201D. #dighealthZh",
  "id" : 804284538562236416,
  "created_at" : "2016-12-01 11:22:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthZh",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37219526637022, 8.54966389759598 ]
  },
  "id_str" : "804283890705793024",
  "text" : "Tania Simoncelli on making Myriad hand over BAM files using HIPAA as a stick. #dighealthZh",
  "id" : 804283890705793024,
  "created_at" : "2016-12-01 11:19:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804283045083828225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37219330134275, 8.549671590753013 ]
  },
  "id_str" : "804283313980669952",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel I\u2019d object to that \uD83D\uDE02",
  "id" : 804283313980669952,
  "in_reply_to_status_id" : 804283045083828225,
  "created_at" : "2016-12-01 11:17:39 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/ngfy518NxQ",
      "expanded_url" : "https:\/\/twitter.com\/froggleston\/status\/798530591385911296",
      "display_url" : "twitter.com\/froggleston\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804282540609695744",
  "text" : "RT @gedankenstuecke: Awesome, that\u2019s how I\u2019d feel. https:\/\/t.co\/ngfy518NxQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/ngfy518NxQ",
        "expanded_url" : "https:\/\/twitter.com\/froggleston\/status\/798530591385911296",
        "display_url" : "twitter.com\/froggleston\/st\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.89726638797568, -77.02380822978637 ]
    },
    "id_str" : "798574862868606976",
    "text" : "Awesome, that\u2019s how I\u2019d feel. https:\/\/t.co\/ngfy518NxQ",
    "id" : 798574862868606976,
    "created_at" : "2016-11-15 17:14:18 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 804282540609695744,
  "created_at" : "2016-12-01 11:14:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthZh",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37178376696218, 8.549843555037395 ]
  },
  "id_str" : "804282194013417472",
  "text" : "Big surprise: commercial interests are main reason for not sharing medical data. #dighealthZh",
  "id" : 804282194013417472,
  "created_at" : "2016-12-01 11:13:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthZh",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804278835269267457",
  "text" : "RT @Michele_Loi_ETH: Roger Brownsword: data commons promoting preconditions of humanity should remain not for profit. #dighealthZh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dighealthZh",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "804278447514206208",
    "text" : "Roger Brownsword: data commons promoting preconditions of humanity should remain not for profit. #dighealthZh",
    "id" : 804278447514206208,
    "created_at" : "2016-12-01 10:58:19 +0000",
    "user" : {
      "name" : "Michele Loi",
      "screen_name" : "Michele_Loi_UZH",
      "protected" : false,
      "id_str" : "21310106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620994736413913089\/zsNihOWN_normal.jpg",
      "id" : 21310106,
      "verified" : false
    }
  },
  "id" : 804278835269267457,
  "created_at" : "2016-12-01 10:59:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthzh",
      "indices" : [ 54, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/guZG70PaML",
      "expanded_url" : "https:\/\/twitter.com\/Michele_Loi_ETH\/status\/804274809962106880",
      "display_url" : "twitter.com\/Michele_Loi_ET\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37218931122518, 8.549661050773071 ]
  },
  "id_str" : "804275915245187072",
  "text" : "An interesting lens to view the data commons through. #dighealthzh https:\/\/t.co\/guZG70PaML",
  "id" : 804275915245187072,
  "created_at" : "2016-12-01 10:48:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 58, 70 ],
      "id_str" : "18393773",
      "id" : 18393773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthzh",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/SCochH1wMo",
      "expanded_url" : "https:\/\/twitter.com\/EffyVayena\/status\/804258925033951232",
      "display_url" : "twitter.com\/EffyVayena\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37156736502921, 8.550011460257258 ]
  },
  "id_str" : "804259828503904256",
  "text" : "I didn\u2019t expect to hear about the million troll march and @neilhimself at #dighealthzh, but there you go! \uD83D\uDC96 https:\/\/t.co\/SCochH1wMo",
  "id" : 804259828503904256,
  "created_at" : "2016-12-01 09:44:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/RQMVoxvnco",
      "expanded_url" : "https:\/\/twitter.com\/podehaye\/status\/804256492010504192",
      "display_url" : "twitter.com\/podehaye\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37185169445367, 8.549849577006604 ]
  },
  "id_str" : "804256766997516288",
  "text" : "Hadn\u2019t seen that one, that\u2019s cool! https:\/\/t.co\/RQMVoxvnco",
  "id" : 804256766997516288,
  "created_at" : "2016-12-01 09:32:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 8, 22 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthzh",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/7sQxewp3bR",
      "expanded_url" : "https:\/\/lh3.googleusercontent.com\/-VEWTs44N0JQ\/VVJSFtmx0zI\/AAAAAAAACc0\/mtgkZsfpvUQ\/w506-h281\/Screen%2BShot%2B2015-05-12%2Bat%2B12.12.17%2BPM.png",
      "display_url" : "lh3.googleusercontent.com\/-VEWTs44N0JQ\/V\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37156701864598, 8.55001148173218 ]
  },
  "id_str" : "804254434947715072",
  "text" : "Hearing @marcelsalathe speak about deep learning and image classification I always only think this. https:\/\/t.co\/7sQxewp3bR #dighealthzh",
  "id" : 804254434947715072,
  "created_at" : "2016-12-01 09:22:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthzh",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37193525061075, 8.549839151938391 ]
  },
  "id_str" : "804250304476811264",
  "text" : "The Shiva trial: personalized treatments didn\u2019t outperform conventional ones. Shows that RCTs are still needed and valuable. #dighealthzh",
  "id" : 804250304476811264,
  "created_at" : "2016-12-01 09:06:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804244983926714368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37160029715893, 8.550056299082724 ]
  },
  "id_str" : "804249038904324096",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye yeah, I don\u2019t want to spam a more general tag though :)",
  "id" : 804249038904324096,
  "in_reply_to_status_id" : 804244983926714368,
  "created_at" : "2016-12-01 09:01:27 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 10, 21 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804243517983850496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37205729194797, 8.550125050434001 ]
  },
  "id_str" : "804243707889418240",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @EffyVayena the slide gives 3 hashtags. So I decided to stick to the one that seems event specific.",
  "id" : 804243707889418240,
  "in_reply_to_status_id" : 804243517983850496,
  "created_at" : "2016-12-01 08:40:16 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 29, 40 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dighealthzh",
      "indices" : [ 5, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/cRRMSIpgvw",
      "expanded_url" : "http:\/\/www.digitalethics.ch\/",
      "display_url" : "digitalethics.ch"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37206343098192, 8.550137652515307 ]
  },
  "id_str" : "804243048121139200",
  "text" : "Now: #dighealthzh, thanks to @EffyVayena https:\/\/t.co\/cRRMSIpgvw",
  "id" : 804243048121139200,
  "created_at" : "2016-12-01 08:37:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/8blKOYwJ1R",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=lfcDBjK5Zzs",
      "display_url" : "m.youtube.com\/watch?v=lfcDBj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804121360914071552",
  "text" : "Lost my way in the Swiss hinterland and then Spotify randomly starts playing No Shortcuts. Well played!  https:\/\/t.co\/8blKOYwJ1R",
  "id" : 804121360914071552,
  "created_at" : "2016-12-01 00:34:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]
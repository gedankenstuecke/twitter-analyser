Grailbird.data.tweets_2017_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/826557426317029380\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/Uz9ngS1R0W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C3iFmAvWMAMgNBa.jpg",
      "id_str" : "826557419702595587",
      "id" : 826557419702595587,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C3iFmAvWMAMgNBa.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      } ],
      "display_url" : "pic.twitter.com\/Uz9ngS1R0W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06094925575895, 8.818573923789726 ]
  },
  "id_str" : "826557426317029380",
  "text" : "That\u2019s at least one way to finish this month\u2026 https:\/\/t.co\/Uz9ngS1R0W",
  "id" : 826557426317029380,
  "created_at" : "2017-01-31 22:27:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Bashton",
      "screen_name" : "MattBashton",
      "indices" : [ 3, 15 ],
      "id_str" : "390368948",
      "id" : 390368948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "826530446641082368",
  "text" : "RT @MattBashton: Since all things Trainspotting are in vogue it\u2019s fun to have another look at this classic an unnamed colleague produce a f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MattBashton\/status\/826396439941099520\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/JlMA0TNSzW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C3fzHBiWEAICNZN.jpg",
        "id_str" : "826396358642896898",
        "id" : 826396358642896898,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C3fzHBiWEAICNZN.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1447
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3508,
          "resize" : "fit",
          "w" : 2479
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 848
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 481
        } ],
        "display_url" : "pic.twitter.com\/JlMA0TNSzW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "826396439941099520",
    "text" : "Since all things Trainspotting are in vogue it\u2019s fun to have another look at this classic an unnamed colleague produce a few years back https:\/\/t.co\/JlMA0TNSzW",
    "id" : 826396439941099520,
    "created_at" : "2017-01-31 11:47:19 +0000",
    "user" : {
      "name" : "Matthew Bashton",
      "screen_name" : "MattBashton",
      "protected" : false,
      "id_str" : "390368948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/831898909463236608\/Ys332gXU_normal.jpg",
      "id" : 390368948,
      "verified" : false
    }
  },
  "id" : 826530446641082368,
  "created_at" : "2017-01-31 20:39:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/WFuGa0ctrf",
      "expanded_url" : "http:\/\/www.kurgoblog.com\/wp-content\/uploads\/2013\/11\/cute-dog-gifs-hugging-a-cat.gif",
      "display_url" : "kurgoblog.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "826524185308508160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404651877713, 8.75342587460495 ]
  },
  "id_str" : "826524989247586305",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski take this instead: https:\/\/t.co\/WFuGa0ctrf",
  "id" : 826524989247586305,
  "in_reply_to_status_id" : 826524185308508160,
  "created_at" : "2017-01-31 20:18:08 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    }, {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 18, 23 ],
      "id_str" : "12819112",
      "id" : 12819112
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 24, 32 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "826524374350123008",
  "text" : "RT @jonfwilkins: .@PLOS @nytimes Also, right now, \"Don't politicize science\" reads like police beating someone while saying \"Stop resisting\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PLOS",
        "screen_name" : "PLOS",
        "indices" : [ 1, 6 ],
        "id_str" : "12819112",
        "id" : 12819112
      }, {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 7, 15 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "826522234965655552",
    "geo" : { },
    "id_str" : "826522615384768512",
    "in_reply_to_user_id" : 214099847,
    "text" : ".@PLOS @nytimes Also, right now, \"Don't politicize science\" reads like police beating someone while saying \"Stop resisting arrest\"",
    "id" : 826522615384768512,
    "in_reply_to_status_id" : 826522234965655552,
    "created_at" : "2017-01-31 20:08:42 +0000",
    "in_reply_to_screen_name" : "jonfwilkins",
    "in_reply_to_user_id_str" : "214099847",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 826524374350123008,
  "created_at" : "2017-01-31 20:15:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826424551563202562",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240708165885, 8.627525311409443 ]
  },
  "id_str" : "826448831327899648",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics aye, that\u2019s great! My mom saw an instructor do \u00B1 what you described and decided she\u2019d teach me herself instead.",
  "id" : 826448831327899648,
  "in_reply_to_status_id" : 826424551563202562,
  "created_at" : "2017-01-31 15:15:30 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sciencemarch",
      "indices" : [ 16, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/RDe2gbGNlc",
      "expanded_url" : "https:\/\/twitter.com\/mem_somerville\/status\/826446314217037824",
      "display_url" : "twitter.com\/mem_somerville\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18659424865933, 8.615624134836775 ]
  },
  "id_str" : "826447291619872770",
  "text" : "If anything the #sciencemarch is a bad idea because it\u2019s run by people who want to remain apolitical and think science would be so too\u2026 https:\/\/t.co\/RDe2gbGNlc",
  "id" : 826447291619872770,
  "created_at" : "2017-01-31 15:09:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826389913570594817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237777330637, 8.627505376792346 ]
  },
  "id_str" : "826424176777035791",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics all the best! \uD83C\uDFCA",
  "id" : 826424176777035791,
  "in_reply_to_status_id" : 826389913570594817,
  "created_at" : "2017-01-31 13:37:32 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Neil Saunders",
      "screen_name" : "neilfws",
      "indices" : [ 9, 17 ],
      "id_str" : "14162706",
      "id" : 14162706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826384137716129793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239911552183, 8.627530061145114 ]
  },
  "id_str" : "826384692895158272",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @neilfws dunno, I think I\u2019d prefer a 3D bar chart over any pie chart. :D",
  "id" : 826384692895158272,
  "in_reply_to_status_id" : 826384137716129793,
  "created_at" : "2017-01-31 11:00:38 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/kASqyY8nn6",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/gpXf94aP8xMM8\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/gpXf94aP\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "826376718806048768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723879824952, 8.627537228197637 ]
  },
  "id_str" : "826384136390766593",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 happy Birthday! https:\/\/t.co\/kASqyY8nn6",
  "id" : 826384136390766593,
  "in_reply_to_status_id" : 826376718806048768,
  "created_at" : "2017-01-31 10:58:26 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Neil Saunders",
      "screen_name" : "neilfws",
      "indices" : [ 9, 17 ],
      "id_str" : "14162706",
      "id" : 14162706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826375963772600322",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723879824952, 8.627537228197637 ]
  },
  "id_str" : "826383859667365888",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @neilfws or, you know, a bar chart. \uD83D\uDE02",
  "id" : 826383859667365888,
  "in_reply_to_status_id" : 826375963772600322,
  "created_at" : "2017-01-31 10:57:20 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826377201599836161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236839056559, 8.62750592051069 ]
  },
  "id_str" : "826377518106214400",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski you\u2019re right :(",
  "id" : 826377518106214400,
  "in_reply_to_status_id" : 826377201599836161,
  "created_at" : "2017-01-31 10:32:08 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 20, 36 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "826377472786698240",
  "text" : "RT @EmilyGorcenski: @gedankenstuecke yes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "826377065112928256",
    "geo" : { },
    "id_str" : "826377201599836161",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke yes.",
    "id" : 826377201599836161,
    "in_reply_to_status_id" : 826377065112928256,
    "created_at" : "2017-01-31 10:30:52 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 826377472786698240,
  "created_at" : "2017-01-31 10:31:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237532032836, 8.627534621690902 ]
  },
  "id_str" : "826377065112928256",
  "text" : "People still submit sequences in Excel files as supplementary files. Unsure who\u2019s to blame, the journals or the authors\u2026",
  "id" : 826377065112928256,
  "created_at" : "2017-01-31 10:30:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/N0soIc4WxL",
      "expanded_url" : "https:\/\/twitter.com\/Tesseraconteur\/status\/826345584344723456",
      "display_url" : "twitter.com\/Tesseraconteur\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236584255108, 8.627514024476746 ]
  },
  "id_str" : "826369750238429184",
  "text" : "Next level: forms a religion around the dildo collection 2,000 years from now. https:\/\/t.co\/N0soIc4WxL",
  "id" : 826369750238429184,
  "created_at" : "2017-01-31 10:01:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 116, 122 ],
      "id_str" : "15164565",
      "id" : 15164565
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 126, 142 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Biohackers",
      "indices" : [ 16, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/WaZ3Km1yBQ",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/technology\/future_tense\/2017\/01\/are_biohackers_the_modern_day_victor_frankensteins.html?wpsrc=sh_all_dt_tw_top",
      "display_url" : "slate.com\/articles\/techn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826353328762257408",
  "text" : "RT @EffyVayena: #Biohackers questioning authority &amp; power of academic institutions: https:\/\/t.co\/WaZ3Km1yBQ via @slate cc @gedankenstuecke\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 100, 106 ],
        "id_str" : "15164565",
        "id" : 15164565
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 110, 126 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Amy Dockser Marcus",
        "screen_name" : "AmyDMarcus",
        "indices" : [ 127, 138 ],
        "id_str" : "551085238",
        "id" : 551085238
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Biohackers",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/WaZ3Km1yBQ",
        "expanded_url" : "http:\/\/www.slate.com\/articles\/technology\/future_tense\/2017\/01\/are_biohackers_the_modern_day_victor_frankensteins.html?wpsrc=sh_all_dt_tw_top",
        "display_url" : "slate.com\/articles\/techn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "826311663200657411",
    "text" : "#Biohackers questioning authority &amp; power of academic institutions: https:\/\/t.co\/WaZ3Km1yBQ via @slate cc @gedankenstuecke @AmyDMarcus",
    "id" : 826311663200657411,
    "created_at" : "2017-01-31 06:10:27 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 826353328762257408,
  "created_at" : "2017-01-31 08:56:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826311663200657411",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236813821493, 8.62751790737812 ]
  },
  "id_str" : "826353318209454080",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena thanks!",
  "id" : 826353318209454080,
  "in_reply_to_status_id" : 826311663200657411,
  "created_at" : "2017-01-31 08:55:58 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/mGSy53cEJt",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/826336680978296833",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404047795121, 8.753449324024714 ]
  },
  "id_str" : "826336846816931841",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch https:\/\/t.co\/mGSy53cEJt :)",
  "id" : 826336846816931841,
  "created_at" : "2017-01-31 07:50:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/LfKEb2EM2r",
      "expanded_url" : "http:\/\/www.win.tue.nl\/~aserebre\/SANER2017.pdf",
      "display_url" : "win.tue.nl\/~aserebre\/SANE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826336680978296833",
  "text" : "There's a study on \"Code of Conduct in Open Source Projects\" (found via google scholar notifications for openSNP). https:\/\/t.co\/LfKEb2EM2r",
  "id" : 826336680978296833,
  "created_at" : "2017-01-31 07:49:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "March for Science",
      "screen_name" : "ScienceMarchDC",
      "indices" : [ 10, 25 ],
      "id_str" : "823565852922576897",
      "id" : 823565852922576897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404641282196, 8.753426906206684 ]
  },
  "id_str" : "826226792063172608",
  "text" : "@kopshtik @ScienceMarchDC we\u2019re totally dedicated to diversity. We haven Steves, Stevens and even some Stephens!",
  "id" : 826226792063172608,
  "created_at" : "2017-01-31 00:33:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 15, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/0t8wwFNIy5",
      "expanded_url" : "https:\/\/twitter.com\/crippledscholar\/status\/826218680354750464",
      "display_url" : "twitter.com\/crippledschola\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399062272621, 8.753178706418298 ]
  },
  "id_str" : "826223089621037056",
  "text" : "And that\u2019s why #openscience can\u2019t stop at Open Data &amp; Open Access. https:\/\/t.co\/0t8wwFNIy5",
  "id" : 826223089621037056,
  "created_at" : "2017-01-31 00:18:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/bQ9Pm8UJAC",
      "expanded_url" : "https:\/\/twitter.com\/mbeisen\/status\/826129000053436416",
      "display_url" : "twitter.com\/mbeisen\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406496876028, 8.753417981567528 ]
  },
  "id_str" : "826220511181025280",
  "text" : "Not surprising, Pinker was the one saying Bioethics should \u201Cget out of the way\u201D. Now all other ethics should follow it seem\u2026 https:\/\/t.co\/bQ9Pm8UJAC",
  "id" : 826220511181025280,
  "created_at" : "2017-01-31 00:08:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 3, 11 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Steven Pinker",
      "screen_name" : "sapinker",
      "indices" : [ 19, 28 ],
      "id_str" : "107225267",
      "id" : 107225267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/wNFIgLek72",
      "expanded_url" : "https:\/\/twitter.com\/sapinker\/status\/825769152627482624",
      "display_url" : "twitter.com\/sapinker\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826219801567752192",
  "text" : "RT @mbeisen: What, @sapinker, is anti-science about a call for diversity and inclusiveness? https:\/\/t.co\/wNFIgLek72",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Pinker",
        "screen_name" : "sapinker",
        "indices" : [ 6, 15 ],
        "id_str" : "107225267",
        "id" : 107225267
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/wNFIgLek72",
        "expanded_url" : "https:\/\/twitter.com\/sapinker\/status\/825769152627482624",
        "display_url" : "twitter.com\/sapinker\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "826129000053436416",
    "text" : "What, @sapinker, is anti-science about a call for diversity and inclusiveness? https:\/\/t.co\/wNFIgLek72",
    "id" : 826129000053436416,
    "created_at" : "2017-01-30 18:04:37 +0000",
    "user" : {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "protected" : false,
      "id_str" : "19843630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893602583478239236\/Gkp75Fa5_normal.jpg",
      "id" : 19843630,
      "verified" : true
    }
  },
  "id" : 826219801567752192,
  "created_at" : "2017-01-31 00:05:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/cXPfUY2BM3",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BP6GJ0RjNde\/",
      "display_url" : "instagram.com\/p\/BP6GJ0RjNde\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1119266058, 8.75423348207 ]
  },
  "id_str" : "826217905524183044",
  "text" : "Cracked @ Offenbach Hafeninsel https:\/\/t.co\/cXPfUY2BM3",
  "id" : 826217905524183044,
  "created_at" : "2017-01-30 23:57:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826181388705550336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404605558892, 8.753425967439615 ]
  },
  "id_str" : "826182274794344453",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs and thereI always thought I\u2019d give people a short deadline. \uD83D\uDE02",
  "id" : 826182274794344453,
  "in_reply_to_status_id" : 826181388705550336,
  "created_at" : "2017-01-30 21:36:18 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 23, 38 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 72, 81 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404301270435, 8.753430211518308 ]
  },
  "id_str" : "826180557247750145",
  "text" : "Looking forward to the @MozOpenLeaders round even more now. Well played @abbycabs!",
  "id" : 826180557247750145,
  "created_at" : "2017-01-30 21:29:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826174188943577088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388372006582, 8.75309027096844 ]
  },
  "id_str" : "826179229591166976",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick remember when we shared links to blogposts?",
  "id" : 826179229591166976,
  "in_reply_to_status_id" : 826174188943577088,
  "created_at" : "2017-01-30 21:24:12 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 17, 25 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/CZHlcVXojU",
      "expanded_url" : "https:\/\/twitter.com\/GirlForScience\/status\/825807929995587584",
      "display_url" : "twitter.com\/GirlForScience\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403815044128, 8.753436655648738 ]
  },
  "id_str" : "826170983388160001",
  "text" : "Next time I meet @mbeisen that\u2019s how I\u2019ll wear my hair. Just to see his left-handed tears. \uD83D\uDE1B https:\/\/t.co\/CZHlcVXojU",
  "id" : 826170983388160001,
  "created_at" : "2017-01-30 20:51:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826170432252420097",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403815044128, 8.753436655648738 ]
  },
  "id_str" : "826170569943027712",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna machst du mir so einen n\u00E4chstes mal wenn wir uns sehen? :D",
  "id" : 826170569943027712,
  "in_reply_to_status_id" : 826170432252420097,
  "created_at" : "2017-01-30 20:49:48 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    }, {
      "name" : "ACLU",
      "screen_name" : "ACLU",
      "indices" : [ 97, 102 ],
      "id_str" : "13393052",
      "id" : 13393052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826151987494412288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404613079902, 8.753425064803562 ]
  },
  "id_str" : "826158090659696640",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue toddlers have been shooting more people in the US after all. Though I\u2019d bet $50 to @ACLU that most where white Christians\u2026",
  "id" : 826158090659696640,
  "in_reply_to_status_id" : 826151987494412288,
  "created_at" : "2017-01-30 20:00:12 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/SFmd6Irj6O",
      "expanded_url" : "https:\/\/secure.static.tumblr.com\/3bb2d44ff6d1a0e53f4025f6e63dd903\/4nevhv2\/8Gzo6zh0a\/tumblr_static_filename_640_v2.gif",
      "display_url" : "secure.static.tumblr.com\/3bb2d44ff6d1a0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "826145753877839872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404602521107, 8.753426401234144 ]
  },
  "id_str" : "826148155276275712",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 soon we might all desperately need a dog https:\/\/t.co\/SFmd6Irj6O",
  "id" : 826148155276275712,
  "in_reply_to_status_id" : 826145753877839872,
  "created_at" : "2017-01-30 19:20:43 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826099652537745408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11374401398945, 8.754087416463301 ]
  },
  "id_str" : "826145380513484800",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 who doesn\u2019t!?",
  "id" : 826145380513484800,
  "in_reply_to_status_id" : 826099652537745408,
  "created_at" : "2017-01-30 19:09:42 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Jewett",
      "screen_name" : "esjewett",
      "indices" : [ 10, 19 ],
      "id_str" : "6392382",
      "id" : 6392382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236554258371, 8.627516050858537 ]
  },
  "id_str" : "826111198240370690",
  "text" : "@kopshtik @esjewett I love you even more now! \u2764\uFE0F",
  "id" : 826111198240370690,
  "created_at" : "2017-01-30 16:53:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auriel Fournier",
      "screen_name" : "RallidaeRule",
      "indices" : [ 3, 16 ],
      "id_str" : "70784139",
      "id" : 70784139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "826110252894523392",
  "text" : "RT @RallidaeRule: I have this quote by my desk\n\nand I think about it often, esp when people tell me to stop working towards diversity https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RallidaeRule\/status\/826072365415149569\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ELEmSf0DLS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C3bMVsjUcAEzGPX.jpg",
        "id_str" : "826072254777683969",
        "id" : 826072254777683969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C3bMVsjUcAEzGPX.jpg",
        "sizes" : [ {
          "h" : 423,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 564
        } ],
        "display_url" : "pic.twitter.com\/ELEmSf0DLS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "826072365415149569",
    "text" : "I have this quote by my desk\n\nand I think about it often, esp when people tell me to stop working towards diversity https:\/\/t.co\/ELEmSf0DLS",
    "id" : 826072365415149569,
    "created_at" : "2017-01-30 14:19:34 +0000",
    "user" : {
      "name" : "Auriel Fournier",
      "screen_name" : "RallidaeRule",
      "protected" : false,
      "id_str" : "70784139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/904067460789190657\/CK0n_Rmn_normal.jpg",
      "id" : 70784139,
      "verified" : false
    }
  },
  "id" : 826110252894523392,
  "created_at" : "2017-01-30 16:50:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OfficialSMBE",
      "screen_name" : "OfficialSMBE",
      "indices" : [ 56, 69 ],
      "id_str" : "1120098811",
      "id" : 1120098811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe17",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/SzyZltfD2H",
      "expanded_url" : "https:\/\/www.change.org\/p\/claus-wilke-move-smbe-2017-out-of-the-us",
      "display_url" : "change.org\/p\/claus-wilke-\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pFJqBQl6KX",
      "expanded_url" : "https:\/\/twitter.com\/_devangm\/status\/826095295582838784",
      "display_url" : "twitter.com\/_devangm\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236737485107, 8.627490839374998 ]
  },
  "id_str" : "826096888202018816",
  "text" : "Oh, there\u2019s even already a petition to move this year\u2019s @OfficialSMBE out of the US: https:\/\/t.co\/SzyZltfD2H #smbe17 https:\/\/t.co\/pFJqBQl6KX",
  "id" : 826096888202018816,
  "created_at" : "2017-01-30 15:57:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Devang Mehta",
      "screen_name" : "_devangm",
      "indices" : [ 10, 19 ],
      "id_str" : "54294584",
      "id" : 54294584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826094011089899521",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236737485107, 8.627490839374998 ]
  },
  "id_str" : "826096193482670080",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @_devangm Thanks, will keep my eyes open!",
  "id" : 826096193482670080,
  "in_reply_to_status_id" : 826094011089899521,
  "created_at" : "2017-01-30 15:54:15 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 3, 12 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Devang Mehta",
      "screen_name" : "_devangm",
      "indices" : [ 110, 119 ],
      "id_str" : "54294584",
      "id" : 54294584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/iCTJEBzivJ",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheets\/d\/14HCme44yIa4oIWEvHRo1POwIcNCOuQAXTG1Dwacn8fs\/edit?usp=sharing",
      "display_url" : "docs.google.com\/spreadsheets\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826096103896576001",
  "text" : "RT @MsPhelps: And also a list for crowdsourcing US conferences to petition https:\/\/t.co\/iCTJEBzivJ started by @_devangm https:\/\/t.co\/QZ3ptG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Devang Mehta",
        "screen_name" : "_devangm",
        "indices" : [ 96, 105 ],
        "id_str" : "54294584",
        "id" : 54294584
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/iCTJEBzivJ",
        "expanded_url" : "https:\/\/docs.google.com\/spreadsheets\/d\/14HCme44yIa4oIWEvHRo1POwIcNCOuQAXTG1Dwacn8fs\/edit?usp=sharing",
        "display_url" : "docs.google.com\/spreadsheets\/d\u2026"
      }, {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/QZ3ptGRUDN",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/826075957899436032",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "826094011089899521",
    "text" : "And also a list for crowdsourcing US conferences to petition https:\/\/t.co\/iCTJEBzivJ started by @_devangm https:\/\/t.co\/QZ3ptGRUDN",
    "id" : 826094011089899521,
    "created_at" : "2017-01-30 15:45:34 +0000",
    "user" : {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "protected" : false,
      "id_str" : "22963112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665529153576390660\/ukieWtR4_normal.jpg",
      "id" : 22963112,
      "verified" : false
    }
  },
  "id" : 826096103896576001,
  "created_at" : "2017-01-30 15:53:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jennifer Glass",
      "screen_name" : "methanoJen",
      "indices" : [ 10, 21 ],
      "id_str" : "16340475",
      "id" : 16340475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826089577790205953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237105816766, 8.62751548282998 ]
  },
  "id_str" : "826089807868751878",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @methanoJen ah, fun overlap! :)",
  "id" : 826089807868751878,
  "in_reply_to_status_id" : 826089577790205953,
  "created_at" : "2017-01-30 15:28:52 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Glass",
      "screen_name" : "methanoJen",
      "indices" : [ 0, 11 ],
      "id_str" : "16340475",
      "id" : 16340475
    }, {
      "name" : "Pearson Lab",
      "screen_name" : "PearsonGroupEPS",
      "indices" : [ 12, 28 ],
      "id_str" : "761219192704073728",
      "id" : 761219192704073728
    }, {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 29, 43 ],
      "id_str" : "15154811",
      "id" : 15154811
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 64, 77 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scienceisglobal",
      "indices" : [ 83, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/2B3nwjPmxa",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scienceisglobal\/",
      "display_url" : "ruleofthirds.de\/scienceisgloba\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "826082569502474241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236293138215, 8.627524183250776 ]
  },
  "id_str" : "826089742546698240",
  "in_reply_to_user_id" : 16340475,
  "text" : "@methanoJen @PearsonGroupEPS @phylogenomics see the campaign of @royalsociety with #scienceisglobal. My work on it: https:\/\/t.co\/2B3nwjPmxa",
  "id" : 826089742546698240,
  "in_reply_to_status_id" : 826082569502474241,
  "created_at" : "2017-01-30 15:28:37 +0000",
  "in_reply_to_screen_name" : "methanoJen",
  "in_reply_to_user_id_str" : "16340475",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826087236366172161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237345520348, 8.6275225595405 ]
  },
  "id_str" : "826087616823099394",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad fair enough, though I\u2019d argue that BLAST has been misused far more often than been used for what it was designed for? :D",
  "id" : 826087616823099394,
  "in_reply_to_status_id" : 826087236366172161,
  "created_at" : "2017-01-30 15:20:10 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/5M4mmNXPZU",
      "expanded_url" : "https:\/\/twitter.com\/kopshtik\/status\/826084791292358656",
      "display_url" : "twitter.com\/kopshtik\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236153080068, 8.627527048611872 ]
  },
  "id_str" : "826084948054519809",
  "text" : "Damn, you figured out the whole genomics business. Who talked?! \uD83D\uDE02 https:\/\/t.co\/5M4mmNXPZU",
  "id" : 826084948054519809,
  "created_at" : "2017-01-30 15:09:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/xpZQPGjcja",
      "expanded_url" : "https:\/\/twitter.com\/evoblackrim\/status\/826064053864976384",
      "display_url" : "twitter.com\/evoblackrim\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236153080068, 8.627527048611872 ]
  },
  "id_str" : "826084533732831233",
  "text" : "News at 11: BLAST kinda crap, but still everyone will keep using it. https:\/\/t.co\/xpZQPGjcja",
  "id" : 826084533732831233,
  "created_at" : "2017-01-30 15:07:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/TVPFAwgGw2",
      "expanded_url" : "https:\/\/www.bedienungsanleitu.ng\/waschmaschinen\/ardo",
      "display_url" : "bedienungsanleitu.ng\/waschmaschinen\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "826076013209743361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237109502366, 8.627512715621824 ]
  },
  "id_str" : "826076820957233153",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski https:\/\/t.co\/TVPFAwgGw2 (might have the manual you need, usually multilingual)",
  "id" : 826076820957233153,
  "in_reply_to_status_id" : 826076013209743361,
  "created_at" : "2017-01-30 14:37:16 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826076013209743361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237109502366, 8.627512715621824 ]
  },
  "id_str" : "826076730754551810",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski no clue, only recognize the wool &amp; handwash symbol. Any type number for the machine?",
  "id" : 826076730754551810,
  "in_reply_to_status_id" : 826076013209743361,
  "created_at" : "2017-01-30 14:36:55 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/VkvEXKqd4A",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/e\/1FAIpQLSeNN_2HHREt1h-dm_CgWpFHw8NDPGLCkOwB4lLRFtKFJqI25w\/viewform?c=0&w=1",
      "display_url" : "docs.google.com\/forms\/d\/e\/1FAI\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "825475711712509952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237109502366, 8.627512715621824 ]
  },
  "id_str" : "826075957899436032",
  "in_reply_to_user_id" : 14286491,
  "text" : "If you feel like putting your Muslim Ban-related US conference boycott somewhere, here\u2019s a form for that: https:\/\/t.co\/VkvEXKqd4A",
  "id" : 826075957899436032,
  "in_reply_to_status_id" : 825475711712509952,
  "created_at" : "2017-01-30 14:33:50 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/zwjTJXhzjZ",
      "expanded_url" : "https:\/\/twitter.com\/esfand\/status\/825946011289866240",
      "display_url" : "twitter.com\/esfand\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236987918686, 8.627480543704156 ]
  },
  "id_str" : "826073667687821312",
  "text" : "My PhD will take a couple of years longer. Can\u2019t finish it before our office \uD83D\uDC36 can do this with me. https:\/\/t.co\/zwjTJXhzjZ",
  "id" : 826073667687821312,
  "created_at" : "2017-01-30 14:24:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 3, 12 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "826062255217328128",
  "text" : "RT @MsPhelps: @gedankenstuecke Yes, just declined invitation to speak, suggested relocation, too. Angry, sad. (not at conf. organizers)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "825475711712509952",
    "geo" : { },
    "id_str" : "826051714834894849",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Yes, just declined invitation to speak, suggested relocation, too. Angry, sad. (not at conf. organizers)",
    "id" : 826051714834894849,
    "in_reply_to_status_id" : 825475711712509952,
    "created_at" : "2017-01-30 12:57:30 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "protected" : false,
      "id_str" : "22963112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665529153576390660\/ukieWtR4_normal.jpg",
      "id" : 22963112,
      "verified" : false
    }
  },
  "id" : 826062255217328128,
  "created_at" : "2017-01-30 13:39:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jojo Scoble \uD83D\uDD2C",
      "screen_name" : "Paraphyso",
      "indices" : [ 0, 10 ],
      "id_str" : "290019499",
      "id" : 290019499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825976685703081984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232866665297, 8.627510320694705 ]
  },
  "id_str" : "826020041380478976",
  "in_reply_to_user_id" : 290019499,
  "text" : "@Paraphyso off by an order of magnitude. 1M and counting :D",
  "id" : 826020041380478976,
  "in_reply_to_status_id" : 825976685703081984,
  "created_at" : "2017-01-30 10:51:39 +0000",
  "in_reply_to_screen_name" : "Paraphyso",
  "in_reply_to_user_id_str" : "290019499",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 15, 25 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/hIWw1wdsuW",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Opel_Corsa#\/media\/File:Corsa_B2.jpg",
      "display_url" : "en.wikipedia.org\/wiki\/Opel_Cors\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "826012006784368640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233627917889, 8.627522860696004 ]
  },
  "id_str" : "826012555583901696",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @Julie_B92 @kopshtik maxed out 11\u201C MacBook Air. No clue for the car tbh. Old old &amp; new old were https:\/\/t.co\/hIWw1wdsuW",
  "id" : 826012555583901696,
  "in_reply_to_status_id" : 826012006784368640,
  "created_at" : "2017-01-30 10:21:54 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/pID1pCYPVC",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=G3ja6Hn8ps4",
      "display_url" : "youtube.com\/watch?v=G3ja6H\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "826010151169716230",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237657390804, 8.627618145323282 ]
  },
  "id_str" : "826010332363649024",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @kopshtik https:\/\/t.co\/pID1pCYPVC",
  "id" : 826010332363649024,
  "in_reply_to_status_id" : 826010151169716230,
  "created_at" : "2017-01-30 10:13:04 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 10, 20 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723413353044, 8.627534140565784 ]
  },
  "id_str" : "826009211331080192",
  "text" : "@kopshtik @Julie_B92 nice! Only criteria for my shopping: Does it have 1+ year of MOT test-equivalent left? :D",
  "id" : 826009211331080192,
  "created_at" : "2017-01-30 10:08:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826007449475887106",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239028398943, 8.627478261497599 ]
  },
  "id_str" : "826007738153058304",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @kopshtik well, my \u201Enew\u201C car cost half of what my notebook did. And it\u2019s not because the latter was so overpriced.",
  "id" : 826007738153058304,
  "in_reply_to_status_id" : 826007449475887106,
  "created_at" : "2017-01-30 10:02:45 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826003973131890690",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238007175256, 8.62745895534782 ]
  },
  "id_str" : "826006062394384384",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 actually refers to me ~2 weeks ago. Sounded expensive enough to get rid of the old and and replace w\/ another old one. :D",
  "id" : 826006062394384384,
  "in_reply_to_status_id" : 826003973131890690,
  "created_at" : "2017-01-30 09:56:06 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825992422727507969",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237196838606, 8.627499089294762 ]
  },
  "id_str" : "825993087881195520",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu \u00DCbersprungshandlung ;)",
  "id" : 825993087881195520,
  "in_reply_to_status_id" : 825992422727507969,
  "created_at" : "2017-01-30 09:04:33 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825992571239485440",
  "geo" : { },
  "id_str" : "825992657927274496",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 das klingt sehr nach mir \uD83D\uDE02",
  "id" : 825992657927274496,
  "in_reply_to_status_id" : 825992571239485440,
  "created_at" : "2017-01-30 09:02:50 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/825992068799545344\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Eav8EBVxfi",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C3aDWkWXUAEw6vB.jpg",
      "id_str" : "825992005406904321",
      "id" : 825992005406904321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C3aDWkWXUAEw6vB.jpg",
      "sizes" : [ {
        "h" : 306,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 450
      } ],
      "display_url" : "pic.twitter.com\/Eav8EBVxfi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "825992068799545344",
  "text" : "Me, trying to figure out where the weird noises in the car come from. https:\/\/t.co\/Eav8EBVxfi",
  "id" : 825992068799545344,
  "created_at" : "2017-01-30 09:00:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825721634338242560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404607238991, 8.753425771727285 ]
  },
  "id_str" : "825776936685338625",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks I\u2019m so sorry to hear that. All the hugs if wanted. \uD83D\uDE22",
  "id" : 825776936685338625,
  "in_reply_to_status_id" : 825721634338242560,
  "created_at" : "2017-01-29 18:45:38 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Klein",
      "screen_name" : "metasj",
      "indices" : [ 3, 10 ],
      "id_str" : "75123",
      "id" : 75123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/Dv2vDSzglB",
      "expanded_url" : "https:\/\/twitter.com\/rcallimachi\/status\/825394879958228993",
      "display_url" : "twitter.com\/rcallimachi\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825725511070515202",
  "text" : "RT @metasj: Thread. Worth reading until you know it by heart. https:\/\/t.co\/Dv2vDSzglB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/Dv2vDSzglB",
        "expanded_url" : "https:\/\/twitter.com\/rcallimachi\/status\/825394879958228993",
        "display_url" : "twitter.com\/rcallimachi\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "825724498099974145",
    "text" : "Thread. Worth reading until you know it by heart. https:\/\/t.co\/Dv2vDSzglB",
    "id" : 825724498099974145,
    "created_at" : "2017-01-29 15:17:16 +0000",
    "user" : {
      "name" : "Samuel Klein",
      "screen_name" : "metasj",
      "protected" : false,
      "id_str" : "75123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752955075811762176\/B_9jMUnC_normal.jpg",
      "id" : 75123,
      "verified" : false
    }
  },
  "id" : 825725511070515202,
  "created_at" : "2017-01-29 15:21:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freedom of Science",
      "screen_name" : "FreeSciNet",
      "indices" : [ 3, 14 ],
      "id_str" : "824648530014900225",
      "id" : 824648530014900225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "825724532862414849",
  "text" : "RT @FreeSciNet: A big thank you to all of you! We have115 DM offers of beds &amp; lab space on 6 continents and &gt;100 more in tweets &amp; email. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 132, 155 ],
        "url" : "https:\/\/t.co\/t1whzNGBtU",
        "expanded_url" : "https:\/\/twitter.com\/FreeSciNet\/status\/825436526397886464",
        "display_url" : "twitter.com\/FreeSciNet\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "825724161448407041",
    "text" : "A big thank you to all of you! We have115 DM offers of beds &amp; lab space on 6 continents and &gt;100 more in tweets &amp; email. https:\/\/t.co\/t1whzNGBtU",
    "id" : 825724161448407041,
    "created_at" : "2017-01-29 15:15:55 +0000",
    "user" : {
      "name" : "Freedom of Science",
      "screen_name" : "FreeSciNet",
      "protected" : false,
      "id_str" : "824648530014900225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/825186835097718784\/kKmL5J5G_normal.jpg",
      "id" : 824648530014900225,
      "verified" : false
    }
  },
  "id" : 825724532862414849,
  "created_at" : "2017-01-29 15:17:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825687336075796481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397038680192, 8.753577375555988 ]
  },
  "id_str" : "825687576229081088",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski we\u2019re all Americans now. Except that 99% of us aren\u2019t allowed to enter the county any longer. \uD83D\uDE02\uD83D\uDE25\uD83D\uDE14",
  "id" : 825687576229081088,
  "in_reply_to_status_id" : 825687336075796481,
  "created_at" : "2017-01-29 12:50:33 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825686200744833024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11414282494235, 8.753662956886695 ]
  },
  "id_str" : "825687007028457472",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski did the US already annex all 7 billion people while I was sleeping? \uD83D\uDE31",
  "id" : 825687007028457472,
  "in_reply_to_status_id" : 825686200744833024,
  "created_at" : "2017-01-29 12:48:17 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeRemember",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/mb9MkJkalk",
      "expanded_url" : "https:\/\/twitter.com\/jmfrankfurt\/status\/825338802151497733",
      "display_url" : "twitter.com\/jmfrankfurt\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825686462771388416",
  "text" : "Spent this morning on the Jewish cemetery, learning about Offenbach's past with a great guide. #WeRemember https:\/\/t.co\/mb9MkJkalk",
  "id" : 825686462771388416,
  "created_at" : "2017-01-29 12:46:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 3, 11 ],
      "id_str" : "79192038",
      "id" : 79192038
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 30, 41 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "825636992490803200",
  "text" : "RT @rike_mw: @gedankenstuecke @lteytelman maybe we have to organize more local meetings - also experiments in the US are a thing not only c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Lenny Teytelman",
        "screen_name" : "lteytelman",
        "indices" : [ 17, 28 ],
        "id_str" : "1343132275",
        "id" : 1343132275
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "825626002164502529",
    "geo" : { },
    "id_str" : "825636159560757250",
    "in_reply_to_user_id" : 79192038,
    "text" : "@gedankenstuecke @lteytelman maybe we have to organize more local meetings - also experiments in the US are a thing not only conferences",
    "id" : 825636159560757250,
    "in_reply_to_status_id" : 825626002164502529,
    "created_at" : "2017-01-29 09:26:14 +0000",
    "in_reply_to_screen_name" : "rike_mw",
    "in_reply_to_user_id_str" : "79192038",
    "user" : {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "protected" : false,
      "id_str" : "79192038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820579602129158145\/vyuG6OQ5_normal.jpg",
      "id" : 79192038,
      "verified" : false
    }
  },
  "id" : 825636992490803200,
  "created_at" : "2017-01-29 09:29:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 0, 8 ],
      "id_str" : "79192038",
      "id" : 79192038
    }, {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 9, 20 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825636159560757250",
  "geo" : { },
  "id_str" : "825636974887317505",
  "in_reply_to_user_id" : 79192038,
  "text" : "@rike_mw @lteytelman right, that's something I tend to forget as I basically just work computationally.",
  "id" : 825636974887317505,
  "in_reply_to_status_id" : 825636159560757250,
  "created_at" : "2017-01-29 09:29:29 +0000",
  "in_reply_to_screen_name" : "rike_mw",
  "in_reply_to_user_id_str" : "79192038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Strudwick",
      "screen_name" : "PatrickStrud",
      "indices" : [ 3, 16 ],
      "id_str" : "20703607",
      "id" : 20703607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/1mKXcQSb9E",
      "expanded_url" : "https:\/\/twitter.com\/buzzfeeduk\/status\/825403069428953088",
      "display_url" : "twitter.com\/buzzfeeduk\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825634278046388225",
  "text" : "RT @PatrickStrud: Yesterday I said goodbye to the man that saved me. This is who he was... https:\/\/t.co\/1mKXcQSb9E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/1mKXcQSb9E",
        "expanded_url" : "https:\/\/twitter.com\/buzzfeeduk\/status\/825403069428953088",
        "display_url" : "twitter.com\/buzzfeeduk\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "825631026412142593",
    "text" : "Yesterday I said goodbye to the man that saved me. This is who he was... https:\/\/t.co\/1mKXcQSb9E",
    "id" : 825631026412142593,
    "created_at" : "2017-01-29 09:05:50 +0000",
    "user" : {
      "name" : "Patrick Strudwick",
      "screen_name" : "PatrickStrud",
      "protected" : false,
      "id_str" : "20703607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754588287709409280\/pXNMxm1d_normal.jpg",
      "id" : 20703607,
      "verified" : true
    }
  },
  "id" : 825634278046388225,
  "created_at" : "2017-01-29 09:18:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 0, 8 ],
      "id_str" : "79192038",
      "id" : 79192038
    }, {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 9, 20 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    }, {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 21, 34 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825626002164502529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406294174623, 8.753418632660106 ]
  },
  "id_str" : "825633843088596992",
  "in_reply_to_user_id" : 79192038,
  "text" : "@rike_mw @lteytelman @schwessinger think that\u2019s my stance too right now: have two things where I promised my contribution, then prob not.",
  "id" : 825633843088596992,
  "in_reply_to_status_id" : 825626002164502529,
  "created_at" : "2017-01-29 09:17:02 +0000",
  "in_reply_to_screen_name" : "rike_mw",
  "in_reply_to_user_id_str" : "79192038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 3, 16 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "825633488967700480",
  "text" : "RT @schwessinger: @gedankenstuecke going for a conference in March I feel it will be my last visit to the US for a while A bit sad having l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "825475711712509952",
    "geo" : { },
    "id_str" : "825633122976878592",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke going for a conference in March I feel it will be my last visit to the US for a while A bit sad having lived in CA 4+ years",
    "id" : 825633122976878592,
    "in_reply_to_status_id" : 825475711712509952,
    "created_at" : "2017-01-29 09:14:10 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "protected" : false,
      "id_str" : "1337118332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/847183615989383168\/S1EWgVfx_normal.jpg",
      "id" : 1337118332,
      "verified" : false
    }
  },
  "id" : 825633488967700480,
  "created_at" : "2017-01-29 09:15:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Sauder",
      "screen_name" : "crippledscholar",
      "indices" : [ 3, 19 ],
      "id_str" : "89115813",
      "id" : 89115813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScienceMarch",
      "indices" : [ 47, 60 ]
    }, {
      "text" : "disability",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "intersectionality",
      "indices" : [ 97, 115 ]
    }, {
      "text" : "CripTheVote",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/8rW8xg3m7n",
      "expanded_url" : "https:\/\/crippledscholar.com\/2017\/01\/28\/i-have-concerns-about-the-march-for-science\/",
      "display_url" : "crippledscholar.com\/2017\/01\/28\/i-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825627191161520129",
  "text" : "RT @crippledscholar: I have Concerns about the #ScienceMarch https:\/\/t.co\/8rW8xg3m7n #disability #intersectionality #CripTheVote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ScienceMarch",
        "indices" : [ 26, 39 ]
      }, {
        "text" : "disability",
        "indices" : [ 64, 75 ]
      }, {
        "text" : "intersectionality",
        "indices" : [ 76, 94 ]
      }, {
        "text" : "CripTheVote",
        "indices" : [ 95, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/8rW8xg3m7n",
        "expanded_url" : "https:\/\/crippledscholar.com\/2017\/01\/28\/i-have-concerns-about-the-march-for-science\/",
        "display_url" : "crippledscholar.com\/2017\/01\/28\/i-h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "825506283583307777",
    "text" : "I have Concerns about the #ScienceMarch https:\/\/t.co\/8rW8xg3m7n #disability #intersectionality #CripTheVote",
    "id" : 825506283583307777,
    "created_at" : "2017-01-29 00:50:09 +0000",
    "user" : {
      "name" : "Kim Sauder",
      "screen_name" : "crippledscholar",
      "protected" : false,
      "id_str" : "89115813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707799215871815681\/oXIx2kIP_normal.jpg",
      "id" : 89115813,
      "verified" : true
    }
  },
  "id" : 825627191161520129,
  "created_at" : "2017-01-29 08:50:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 3, 11 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "825626267399630849",
  "text" : "RT @kaiblin: @gedankenstuecke nope, I'm still not going there any time soon.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/carbonandroid.com\" rel=\"nofollow\"\u003ECarbon v2\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "825475711712509952",
    "geo" : { },
    "id_str" : "825619209933701120",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke nope, I'm still not going there any time soon.",
    "id" : 825619209933701120,
    "in_reply_to_status_id" : 825475711712509952,
    "created_at" : "2017-01-29 08:18:53 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "protected" : false,
      "id_str" : "124202458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1629590097\/kai_portrait_normal.jpg",
      "id" : 124202458,
      "verified" : false
    }
  },
  "id" : 825626267399630849,
  "created_at" : "2017-01-29 08:46:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 3, 11 ],
      "id_str" : "79192038",
      "id" : 79192038
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 30, 41 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bps17",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "825626256574148608",
  "text" : "RT @rike_mw: @gedankenstuecke @lteytelman difficult decision\/ travel plans where made already, will attend #bps17 in New Orleans in 2w, aft\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Lenny Teytelman",
        "screen_name" : "lteytelman",
        "indices" : [ 17, 28 ],
        "id_str" : "1343132275",
        "id" : 1343132275
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bps17",
        "indices" : [ 94, 100 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "825475711712509952",
    "geo" : { },
    "id_str" : "825626002164502529",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke @lteytelman difficult decision\/ travel plans where made already, will attend #bps17 in New Orleans in 2w, after maybe no",
    "id" : 825626002164502529,
    "in_reply_to_status_id" : 825475711712509952,
    "created_at" : "2017-01-29 08:45:52 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "protected" : false,
      "id_str" : "79192038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820579602129158145\/vyuG6OQ5_normal.jpg",
      "id" : 79192038,
      "verified" : false
    }
  },
  "id" : 825626256574148608,
  "created_at" : "2017-01-29 08:46:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 3, 13 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 15, 31 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 32, 43 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "825482300175556611",
  "text" : "RT @Julie_B92: @gedankenstuecke @lteytelman yes it has. I will not be attending any confs stateside",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Lenny Teytelman",
        "screen_name" : "lteytelman",
        "indices" : [ 17, 28 ],
        "id_str" : "1343132275",
        "id" : 1343132275
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "825475711712509952",
    "geo" : { },
    "id_str" : "825482115823329280",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke @lteytelman yes it has. I will not be attending any confs stateside",
    "id" : 825482115823329280,
    "in_reply_to_status_id" : 825475711712509952,
    "created_at" : "2017-01-28 23:14:07 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "protected" : false,
      "id_str" : "1385861262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813827716151644160\/JvmX-W-T_normal.jpg",
      "id" : 1385861262,
      "verified" : false
    }
  },
  "id" : 825482300175556611,
  "created_at" : "2017-01-28 23:14:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javeria Ali Hashmi",
      "screen_name" : "netphys1",
      "indices" : [ 0, 9 ],
      "id_str" : "728595932305076224",
      "id" : 728595932305076224
    }, {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 10, 20 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825481550372409344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404617438845, 8.753424927327586 ]
  },
  "id_str" : "825482284358852609",
  "in_reply_to_user_id" : 728595932305076224,
  "text" : "@netphys1 @kirstie_j I know \uD83D\uDE22",
  "id" : 825482284358852609,
  "in_reply_to_status_id" : 825481550372409344,
  "created_at" : "2017-01-28 23:14:47 +0000",
  "in_reply_to_screen_name" : "netphys1",
  "in_reply_to_user_id_str" : "728595932305076224",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javeria Ali Hashmi",
      "screen_name" : "netphys1",
      "indices" : [ 3, 12 ],
      "id_str" : "728595932305076224",
      "id" : 728595932305076224
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 31, 41 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Javeria Ali Hashmi",
      "screen_name" : "netphys1",
      "indices" : [ 42, 51 ],
      "id_str" : "728595932305076224",
      "id" : 728595932305076224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "825482213017972736",
  "text" : "RT @netphys1: @gedankenstuecke @kirstie_j @netphys1 yes, but for many, it is no longer a choice or option.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Kirstie Whitaker",
        "screen_name" : "kirstie_j",
        "indices" : [ 17, 27 ],
        "id_str" : "37989702",
        "id" : 37989702
      }, {
        "name" : "Javeria Ali Hashmi",
        "screen_name" : "netphys1",
        "indices" : [ 28, 37 ],
        "id_str" : "728595932305076224",
        "id" : 728595932305076224
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "825475711712509952",
    "geo" : { },
    "id_str" : "825481550372409344",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke @kirstie_j @netphys1 yes, but for many, it is no longer a choice or option.",
    "id" : 825481550372409344,
    "in_reply_to_status_id" : 825475711712509952,
    "created_at" : "2017-01-28 23:11:52 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Javeria Ali Hashmi",
      "screen_name" : "netphys1",
      "protected" : false,
      "id_str" : "728595932305076224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801839975838916608\/kULuueh__normal.jpg",
      "id" : 728595932305076224,
      "verified" : false
    }
  },
  "id" : 825482213017972736,
  "created_at" : "2017-01-28 23:14:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404627680845, 8.753424115524096 ]
  },
  "id_str" : "825479602147622913",
  "text" : "Coming from an ecology\/evolution background reading \u00AB\u2026call against EO\u2026\u00BB makes me wonder what Wilson did now. Well, group selection \u00B1fits\u2026",
  "id" : 825479602147622913,
  "created_at" : "2017-01-28 23:04:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScienceMarch",
      "indices" : [ 84, 97 ]
    }, {
      "text" : "MuslimBan",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/wMAjZ6q1gc",
      "expanded_url" : "https:\/\/twitter.com\/lteytelman\/status\/822831803916423168",
      "display_url" : "twitter.com\/lteytelman\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404620804213, 8.753425663594946 ]
  },
  "id_str" : "825475711712509952",
  "text" : "So folks, has your opinion on boycotting US conferences changed in the last 7 days? #ScienceMarch #MuslimBan https:\/\/t.co\/wMAjZ6q1gc",
  "id" : 825475711712509952,
  "created_at" : "2017-01-28 22:48:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825440953725046785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404618467267, 8.753425927538592 ]
  },
  "id_str" : "825470033522487297",
  "in_reply_to_user_id" : 776916624,
  "text" : "@emma_gras &lt;3",
  "id" : 825470033522487297,
  "in_reply_to_status_id" : 825440953725046785,
  "created_at" : "2017-01-28 22:26:07 +0000",
  "in_reply_to_screen_name" : "emilyagras",
  "in_reply_to_user_id_str" : "776916624",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 3, 16 ],
      "id_str" : "228437800",
      "id" : 228437800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/wQ7wm4TVOM",
      "expanded_url" : "http:\/\/www.wsj.com\/articles\/trump-visa-ban-also-applies-to-citizens-with-dual-nationality-state-department-says-1485628654?mod=e2tw",
      "display_url" : "wsj.com\/articles\/trump\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "825424877851123712",
  "text" : "RT @atossaaraxia: Guess I won't see my family for a while :\/ https:\/\/t.co\/wQ7wm4TVOM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/wQ7wm4TVOM",
        "expanded_url" : "http:\/\/www.wsj.com\/articles\/trump-visa-ban-also-applies-to-citizens-with-dual-nationality-state-department-says-1485628654?mod=e2tw",
        "display_url" : "wsj.com\/articles\/trump\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "825422955127697408",
    "text" : "Guess I won't see my family for a while :\/ https:\/\/t.co\/wQ7wm4TVOM",
    "id" : 825422955127697408,
    "created_at" : "2017-01-28 19:19:02 +0000",
    "user" : {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "protected" : false,
      "id_str" : "228437800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707884522738728960\/VqnZwF27_normal.jpg",
      "id" : 228437800,
      "verified" : true
    }
  },
  "id" : 825424877851123712,
  "created_at" : "2017-01-28 19:26:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 0, 6 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/825417594891018241\/photo\/1",
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/kozxuZqeV9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C3R47LkWMAAzY0D.jpg",
      "id_str" : "825417589828497408",
      "id" : 825417589828497408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C3R47LkWMAAzY0D.jpg",
      "sizes" : [ {
        "h" : 326,
        "resize" : "fit",
        "w" : 744
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 744
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 744
      } ],
      "display_url" : "pic.twitter.com\/kozxuZqeV9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825403419376496641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140461690927, 8.753426096828912 ]
  },
  "id_str" : "825417594891018241",
  "in_reply_to_user_id" : 586,
  "text" : "@sacca \uD83D\uDC4D https:\/\/t.co\/kozxuZqeV9",
  "id" : 825417594891018241,
  "in_reply_to_status_id" : 825403419376496641,
  "created_at" : "2017-01-28 18:57:44 +0000",
  "in_reply_to_screen_name" : "sacca",
  "in_reply_to_user_id_str" : "586",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/1QTjCMxUK4",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/the-mystery-and-occasional-poetry-of-uh-filled-pauses",
      "display_url" : "atlasobscura.com\/articles\/the-m\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404618343823, 8.75342586537938 ]
  },
  "id_str" : "825394869707350017",
  "text" : "The Mystery and Occasional Poetry of, Uh, Filled Pauses https:\/\/t.co\/1QTjCMxUK4",
  "id" : 825394869707350017,
  "created_at" : "2017-01-28 17:27:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Durags & Dialectics",
      "screen_name" : "Hood_Biologist",
      "indices" : [ 3, 18 ],
      "id_str" : "255545898",
      "id" : 255545898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "825375016208437248",
  "text" : "RT @Hood_Biologist: As a Black scientist I need to know if yall are gonna disappear after they promise to give y'all some $ while they kill\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Hood_Biologist\/status\/824342883847307264\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/3H0DScQwFT",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C3Cnd88XUAUbkyZ.jpg",
        "id_str" : "824342864826159109",
        "id" : 824342864826159109,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C3Cnd88XUAUbkyZ.jpg",
        "sizes" : [ {
          "h" : 120,
          "resize" : "fit",
          "w" : 220
        }, {
          "h" : 120,
          "resize" : "fit",
          "w" : 220
        }, {
          "h" : 120,
          "resize" : "fit",
          "w" : 220
        }, {
          "h" : 120,
          "resize" : "fit",
          "w" : 220
        }, {
          "h" : 120,
          "resize" : "crop",
          "w" : 120
        } ],
        "display_url" : "pic.twitter.com\/3H0DScQwFT"
      } ],
      "hashtags" : [ {
        "text" : "ScienceMarch",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "824305293349814274",
    "geo" : { },
    "id_str" : "824342883847307264",
    "in_reply_to_user_id" : 255545898,
    "text" : "As a Black scientist I need to know if yall are gonna disappear after they promise to give y'all some $ while they kill us? #ScienceMarch https:\/\/t.co\/3H0DScQwFT",
    "id" : 824342883847307264,
    "in_reply_to_status_id" : 824305293349814274,
    "created_at" : "2017-01-25 19:47:13 +0000",
    "in_reply_to_screen_name" : "Hood_Biologist",
    "in_reply_to_user_id_str" : "255545898",
    "user" : {
      "name" : "Durags & Dialectics",
      "screen_name" : "Hood_Biologist",
      "protected" : false,
      "id_str" : "255545898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929821052414431232\/0XxiWp06_normal.jpg",
      "id" : 255545898,
      "verified" : false
    }
  },
  "id" : 825375016208437248,
  "created_at" : "2017-01-28 16:08:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825303566512295937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406410177105, 8.753417020096048 ]
  },
  "id_str" : "825359453033750529",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer both maternal grandparents went through this decline. All the best :(",
  "id" : 825359453033750529,
  "in_reply_to_status_id" : 825303566512295937,
  "created_at" : "2017-01-28 15:06:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 9, 24 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 25, 38 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 39, 49 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825344359918923777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406472547881, 8.7534178415744 ]
  },
  "id_str" : "825354219913936897",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @MozillaScience @RaoOfPhysics @auremoser not really sure what you\u2019re looking for. :)",
  "id" : 825354219913936897,
  "in_reply_to_status_id" : 825344359918923777,
  "created_at" : "2017-01-28 14:45:55 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greens in the EP",
      "screen_name" : "GreensEP",
      "indices" : [ 7, 16 ],
      "id_str" : "183622298",
      "id" : 183622298
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 55, 71 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScienceMarch",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/hWKviEHxoc",
      "expanded_url" : "https:\/\/twitter.com\/andreaskyriacou\/status\/825324436496719877",
      "display_url" : "twitter.com\/andreaskyriaco\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11277082808841, 8.676722337217457 ]
  },
  "id_str" : "825328013491445760",
  "text" : "So the @GreensEP have the same anti-science friends as @realDonaldTrump? Well done! #ScienceMarch https:\/\/t.co\/hWKviEHxoc",
  "id" : 825328013491445760,
  "created_at" : "2017-01-28 13:01:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2716\uFE0F\u3030\u2716\uFE0F",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 24, 31 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "825035107857731584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11370644559572, 8.754061327157956 ]
  },
  "id_str" : "825035326284496896",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos haha, ja. @lsanoj",
  "id" : 825035326284496896,
  "in_reply_to_status_id" : 825035107857731584,
  "created_at" : "2017-01-27 17:38:44 +0000",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 14, 23 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11374332157031, 8.753856511347987 ]
  },
  "id_str" : "825035262598201344",
  "text" : "@kopshtik see @MsPhelps, so lucky! :D",
  "id" : 825035262598201344,
  "created_at" : "2017-01-27 17:38:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/nASdEX9vk5",
      "expanded_url" : "https:\/\/twitter.com\/jimwaterson\/status\/825017459530936320",
      "display_url" : "twitter.com\/jimwaterson\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412787213639, 8.753364566316655 ]
  },
  "id_str" : "825032158104449024",
  "text" : "Being born on 10th of January this is something I always stress about when filling forms in the US. \uD83D\uDE02 https:\/\/t.co\/nASdEX9vk5",
  "id" : 825032158104449024,
  "created_at" : "2017-01-27 17:26:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 64, 73 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406437607803, 8.753417581763802 ]
  },
  "id_str" : "825012814741905408",
  "text" : "Happy New Year to everyone on the lunar calendar in &gt;=UTC+8! @chocho_z",
  "id" : 825012814741905408,
  "created_at" : "2017-01-27 16:09:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/0FyTTkJjV8",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BPxgptQDx2k\/",
      "display_url" : "instagram.com\/p\/BPxgptQDx2k\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1119266058, 8.75423348207 ]
  },
  "id_str" : "825009296693981184",
  "text" : "Home @ Offenbach Hafeninsel https:\/\/t.co\/0FyTTkJjV8",
  "id" : 825009296693981184,
  "created_at" : "2017-01-27 15:55:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Gourneau",
      "screen_name" : "gourneau",
      "indices" : [ 0, 9 ],
      "id_str" : "9552572",
      "id" : 9552572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824757870994477057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406276188698, 8.75341563975526 ]
  },
  "id_str" : "824760836912713730",
  "in_reply_to_user_id" : 9552572,
  "text" : "@gourneau works even for gifs, that\u2019s the best part.",
  "id" : 824760836912713730,
  "in_reply_to_status_id" : 824757870994477057,
  "created_at" : "2017-01-26 23:28:01 +0000",
  "in_reply_to_screen_name" : "gourneau",
  "in_reply_to_user_id_str" : "9552572",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScienceMarch",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824748088472518656",
  "text" : "RT @gedankenstuecke: The idea of \u00ABScience is apolitical\u00BB must be the meme that bugs me most about #ScienceMarch. Isn\u2019t true now and has nev\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ScienceMarch",
        "indices" : [ 77, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11404577119564, 8.753418370387587 ]
    },
    "id_str" : "824365650713919488",
    "text" : "The idea of \u00ABScience is apolitical\u00BB must be the meme that bugs me most about #ScienceMarch. Isn\u2019t true now and has never been true.",
    "id" : 824365650713919488,
    "created_at" : "2017-01-25 21:17:41 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 824748088472518656,
  "created_at" : "2017-01-26 22:37:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/huNbUHlrxR",
      "expanded_url" : "https:\/\/twitter.com\/EmilyGorcenski\/status\/824746841803616256",
      "display_url" : "twitter.com\/EmilyGorcenski\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404575103788, 8.753425933531476 ]
  },
  "id_str" : "824747331748786177",
  "text" : "That\u2019s the upgrade to Quantum Alternative Facts https:\/\/t.co\/huNbUHlrxR",
  "id" : 824747331748786177,
  "created_at" : "2017-01-26 22:34:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    }, {
      "name" : "Cal State Northridge",
      "screen_name" : "csunorthridge",
      "indices" : [ 100, 114 ],
      "id_str" : "11306582",
      "id" : 11306582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824746824011489287",
  "text" : "RT @JBYoder: Mentioned this yesterday, but here\u2019s an official announcement. Come science with me at @csunorthridge this fall! https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cal State Northridge",
        "screen_name" : "csunorthridge",
        "indices" : [ 87, 101 ],
        "id_str" : "11306582",
        "id" : 11306582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/WMqe6pI2SX",
        "expanded_url" : "https:\/\/twitter.com\/YoderLab\/status\/824746365297127424",
        "display_url" : "twitter.com\/YoderLab\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "824746610592604160",
    "text" : "Mentioned this yesterday, but here\u2019s an official announcement. Come science with me at @csunorthridge this fall! https:\/\/t.co\/WMqe6pI2SX",
    "id" : 824746610592604160,
    "created_at" : "2017-01-26 22:31:29 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 824746824011489287,
  "created_at" : "2017-01-26 22:32:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824742787564318722",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404575782205, 8.753425831816497 ]
  },
  "id_str" : "824743019119247360",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim no set plans so far, let\u2019s discuss when you made it to the calendar :)",
  "id" : 824743019119247360,
  "in_reply_to_status_id" : 824742787564318722,
  "created_at" : "2017-01-26 22:17:13 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824738980251959296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404576854848, 8.753425670986802 ]
  },
  "id_str" : "824739215762194443",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim I just fell in love with you for that rule! And will probably head straight back.",
  "id" : 824739215762194443,
  "in_reply_to_status_id" : 824738980251959296,
  "created_at" : "2017-01-26 22:02:06 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404578030952, 8.753425517268592 ]
  },
  "id_str" : "824733416163856384",
  "text" : "@kopshtik fwiw: i think iOS allows you to open\/show tickets\/boarding passes etc. right from lock screen w\/o unlocking device.",
  "id" : 824733416163856384,
  "created_at" : "2017-01-26 21:39:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824731751918493696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404585281495, 8.753425122062371 ]
  },
  "id_str" : "824731900099133440",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim nice, even if we won\u2019t share flights :D Fun open science things in the US as well? :-)",
  "id" : 824731900099133440,
  "in_reply_to_status_id" : 824731751918493696,
  "created_at" : "2017-01-26 21:33:02 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Jason Williams",
      "screen_name" : "JasonWilliamsNY",
      "indices" : [ 11, 27 ],
      "id_str" : "1692248610",
      "id" : 1692248610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824687650116431872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10873989206749, 8.762010075160081 ]
  },
  "id_str" : "824690883878608897",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @JasonWilliamsNY thanks! \uD83D\uDC96\uD83D\uDC4D",
  "id" : 824690883878608897,
  "in_reply_to_status_id" : 824687650116431872,
  "created_at" : "2017-01-26 18:50:03 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/jRJbYbLKLw",
      "expanded_url" : "https:\/\/twitter.com\/JasonWilliamsNY\/status\/824683099791486977",
      "display_url" : "twitter.com\/JasonWilliamsN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824690801238216705",
  "text" : "RT @biocrusoe: This retweet is an endorsement https:\/\/t.co\/jRJbYbLKLw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/jRJbYbLKLw",
        "expanded_url" : "https:\/\/twitter.com\/JasonWilliamsNY\/status\/824683099791486977",
        "display_url" : "twitter.com\/JasonWilliamsN\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "824687650116431872",
    "text" : "This retweet is an endorsement https:\/\/t.co\/jRJbYbLKLw",
    "id" : 824687650116431872,
    "created_at" : "2017-01-26 18:37:12 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 824690801238216705,
  "created_at" : "2017-01-26 18:49:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/Ljlkj2KCKI",
      "expanded_url" : "http:\/\/www.thefader.com\/2017\/01\/26\/neo-nazi-richard-spencer-got-punched-for-the-second-time-and-twitter-is-losing-it",
      "display_url" : "thefader.com\/2017\/01\/26\/neo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "824286373935022082",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10915081487047, 8.761910414331371 ]
  },
  "id_str" : "824689950406963201",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch seems there are free resources for now \uD83D\uDE02 https:\/\/t.co\/Ljlkj2KCKI",
  "id" : 824689950406963201,
  "in_reply_to_status_id" : 824286373935022082,
  "created_at" : "2017-01-26 18:46:20 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824660229325459460",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406305293326, 8.753417358127559 ]
  },
  "id_str" : "824686527926169603",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim \uD83C\uDDE8\uD83C\uDDE6? :)",
  "id" : 824686527926169603,
  "in_reply_to_status_id" : 824660229325459460,
  "created_at" : "2017-01-26 18:32:44 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asura Enkhbayar",
      "screen_name" : "AsuraEnkhbayar",
      "indices" : [ 0, 15 ],
      "id_str" : "1639877449",
      "id" : 1639877449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/mG9C0PrOAO",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Killing_Time_(book)",
      "display_url" : "en.m.wikipedia.org\/wiki\/Killing_T\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "824682668579287040",
  "geo" : { },
  "id_str" : "824683282499526656",
  "in_reply_to_user_id" : 1639877449,
  "text" : "@AsuraEnkhbayar totally, Against Method is pretty much the same when it comes to that. A fun &amp; enlightning read too: https:\/\/t.co\/mG9C0PrOAO",
  "id" : 824683282499526656,
  "in_reply_to_status_id" : 824682668579287040,
  "created_at" : "2017-01-26 18:19:51 +0000",
  "in_reply_to_screen_name" : "AsuraEnkhbayar",
  "in_reply_to_user_id_str" : "1639877449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asura Enkhbayar",
      "screen_name" : "AsuraEnkhbayar",
      "indices" : [ 0, 15 ],
      "id_str" : "1639877449",
      "id" : 1639877449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824680035743363073",
  "geo" : { },
  "id_str" : "824680415936086017",
  "in_reply_to_user_id" : 1639877449,
  "text" : "@AsuraEnkhbayar sounds like a good choice even if I only read Against Method so far.",
  "id" : 824680415936086017,
  "in_reply_to_status_id" : 824680035743363073,
  "created_at" : "2017-01-26 18:08:27 +0000",
  "in_reply_to_screen_name" : "AsuraEnkhbayar",
  "in_reply_to_user_id_str" : "1639877449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asura Enkhbayar",
      "screen_name" : "AsuraEnkhbayar",
      "indices" : [ 3, 18 ],
      "id_str" : "1639877449",
      "id" : 1639877449
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 20, 36 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824680150273064963",
  "text" : "RT @AsuraEnkhbayar: @gedankenstuecke Mostly known for \"anything goes\", but very relevant for this topic, imo: Paul Feyerabend - Science in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "824365650713919488",
    "geo" : { },
    "id_str" : "824680035743363073",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Mostly known for \"anything goes\", but very relevant for this topic, imo: Paul Feyerabend - Science in a Free Society",
    "id" : 824680035743363073,
    "in_reply_to_status_id" : 824365650713919488,
    "created_at" : "2017-01-26 18:06:56 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Asura Enkhbayar",
      "screen_name" : "AsuraEnkhbayar",
      "protected" : false,
      "id_str" : "1639877449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843166617022484482\/N0kZNor5_normal.jpg",
      "id" : 1639877449,
      "verified" : false
    }
  },
  "id" : 824680150273064963,
  "created_at" : "2017-01-26 18:07:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Ritchie",
      "screen_name" : "StuartJRitchie",
      "indices" : [ 3, 18 ],
      "id_str" : "180858875",
      "id" : 180858875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824679372045049857",
  "text" : "RT @StuartJRitchie: Remember that alarming blog where the guy seemed to admit to p-hacking? Now, LOADS of errors found in his papers: https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/QvUe9YTXom",
        "expanded_url" : "https:\/\/peerj.com\/preprints\/2748.pdf",
        "display_url" : "peerj.com\/preprints\/2748\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "824540519007223809",
    "text" : "Remember that alarming blog where the guy seemed to admit to p-hacking? Now, LOADS of errors found in his papers: https:\/\/t.co\/QvUe9YTXom",
    "id" : 824540519007223809,
    "created_at" : "2017-01-26 08:52:33 +0000",
    "user" : {
      "name" : "Stuart Ritchie",
      "screen_name" : "StuartJRitchie",
      "protected" : false,
      "id_str" : "180858875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512906786202873856\/O_gVcoqI_normal.jpeg",
      "id" : 180858875,
      "verified" : false
    }
  },
  "id" : 824679372045049857,
  "created_at" : "2017-01-26 18:04:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824599571674361856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235877627531, 8.627507666889384 ]
  },
  "id_str" : "824600433570316289",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB me too!",
  "id" : 824600433570316289,
  "in_reply_to_status_id" : 824599571674361856,
  "created_at" : "2017-01-26 12:50:38 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824598065801732096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238435824584, 8.62746239531255 ]
  },
  "id_str" : "824598396979781632",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB ha, totally missed you as I didn\u2019t catch the last name! \uD83D\uDE02",
  "id" : 824598396979781632,
  "in_reply_to_status_id" : 824598065801732096,
  "created_at" : "2017-01-26 12:42:32 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Wiechers",
      "screen_name" : "jwiechers",
      "indices" : [ 0, 10 ],
      "id_str" : "15110495",
      "id" : 15110495
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 11, 20 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824590249317765121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236509904173, 8.627491922969561 ]
  },
  "id_str" : "824594346699845632",
  "in_reply_to_user_id" : 15110495,
  "text" : "@jwiechers @JP_Stich meiner Erfahrung nach sind die meisten Science Slammer aber selbst auch nicht die h\u00E4rtesten Wissenschaftler ;-)",
  "id" : 824594346699845632,
  "in_reply_to_status_id" : 824590249317765121,
  "created_at" : "2017-01-26 12:26:27 +0000",
  "in_reply_to_screen_name" : "jwiechers",
  "in_reply_to_user_id_str" : "15110495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Reinboth",
      "screen_name" : "reinboth",
      "indices" : [ 0, 9 ],
      "id_str" : "17187345",
      "id" : 17187345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/1Qo7amuW0D",
      "expanded_url" : "https:\/\/youtu.be\/fqkaBEWPH18?t=1m35s",
      "display_url" : "youtu.be\/fqkaBEWPH18?t=\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "824548206138777600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237688385919, 8.627539617095898 ]
  },
  "id_str" : "824563945918918656",
  "in_reply_to_user_id" : 17187345,
  "text" : "@reinboth https:\/\/t.co\/1Qo7amuW0D \uD83D\uDE22",
  "id" : 824563945918918656,
  "in_reply_to_status_id" : 824548206138777600,
  "created_at" : "2017-01-26 10:25:39 +0000",
  "in_reply_to_screen_name" : "reinboth",
  "in_reply_to_user_id_str" : "17187345",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824389057908133889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404631449216, 8.753412284553267 ]
  },
  "id_str" : "824392066176286721",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy mh, seems not to work right now. Will look into it tomorrow with fresh eyes :)",
  "id" : 824392066176286721,
  "in_reply_to_status_id" : 824389057908133889,
  "created_at" : "2017-01-25 23:02:39 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824389057908133889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404554921429, 8.753420856951792 ]
  },
  "id_str" : "824389124962611201",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy I already started googling where to put it! :D",
  "id" : 824389124962611201,
  "in_reply_to_status_id" : 824389057908133889,
  "created_at" : "2017-01-25 22:50:58 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824388305517056000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404554921429, 8.753420856951792 ]
  },
  "id_str" : "824388522165633025",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy thanks! \uD83D\uDE0D\uD83D\uDC4D",
  "id" : 824388522165633025,
  "in_reply_to_status_id" : 824388305517056000,
  "created_at" : "2017-01-25 22:48:34 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824357693972312064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404574212566, 8.753418696020207 ]
  },
  "id_str" : "824387863462735872",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy where\u2019s that custom JS, could totally need that!",
  "id" : 824387863462735872,
  "in_reply_to_status_id" : 824357693972312064,
  "created_at" : "2017-01-25 22:45:57 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/uSrU8N1R8F",
      "expanded_url" : "https:\/\/twitter.com\/PunchedToMusic\/status\/823441252918042629",
      "display_url" : "twitter.com\/PunchedToMusic\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "824373056395157504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404572663133, 8.753418869582731 ]
  },
  "id_str" : "824375555315367937",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski I guess all I\u2019m saying is: https:\/\/t.co\/uSrU8N1R8F",
  "id" : 824375555315367937,
  "in_reply_to_status_id" : 824373056395157504,
  "created_at" : "2017-01-25 21:57:03 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824373056395157504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404575452833, 8.75341855708949 ]
  },
  "id_str" : "824374956456902657",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski and then remember that all that education didn\u2019t help in stopping that trend over here.",
  "id" : 824374956456902657,
  "in_reply_to_status_id" : 824373056395157504,
  "created_at" : "2017-01-25 21:54:40 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andrea thomer",
      "screen_name" : "an_dre_a_",
      "indices" : [ 0, 10 ],
      "id_str" : "15465094",
      "id" : 15465094
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESIPfed",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824373765903618048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404575452833, 8.75341855708949 ]
  },
  "id_str" : "824374779146895361",
  "in_reply_to_user_id" : 15465094,
  "text" : "@an_dre_a_ absolutely, there are many exceptions, and I\u2019ve heard good things about #ESIPfed with regard to that! \uD83D\uDE0A",
  "id" : 824374779146895361,
  "in_reply_to_status_id" : 824373765903618048,
  "created_at" : "2017-01-25 21:53:58 +0000",
  "in_reply_to_screen_name" : "an_dre_a_",
  "in_reply_to_user_id_str" : "15465094",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824372977227558912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404576813194, 8.753418404706268 ]
  },
  "id_str" : "824373815312531460",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes (but then we only have courses in BSc &amp; MSc programmes, nothing at PhD level).",
  "id" : 824373815312531460,
  "in_reply_to_status_id" : 824372977227558912,
  "created_at" : "2017-01-25 21:50:08 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824372977227558912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404576813194, 8.753418404706268 ]
  },
  "id_str" : "824373656939859968",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes only thing I ever had to take in that direction was a single, mandatory class on bioethics. Nothing else was offered.",
  "id" : 824373656939859968,
  "in_reply_to_status_id" : 824372977227558912,
  "created_at" : "2017-01-25 21:49:30 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andrea thomer",
      "screen_name" : "an_dre_a_",
      "indices" : [ 0, 10 ],
      "id_str" : "15465094",
      "id" : 15465094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/FSwm0wgqOY",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/824343901444173824",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "824372306705268744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404576813194, 8.753418404706268 ]
  },
  "id_str" : "824373302076522497",
  "in_reply_to_user_id" : 15465094,
  "text" : "@an_dre_a_ absolutely, unfortunately at least many scientists don\u2019t see that as an opportunity, c.f. https:\/\/t.co\/FSwm0wgqOY",
  "id" : 824373302076522497,
  "in_reply_to_status_id" : 824372306705268744,
  "created_at" : "2017-01-25 21:48:05 +0000",
  "in_reply_to_screen_name" : "an_dre_a_",
  "in_reply_to_user_id_str" : "15465094",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 67, 81 ],
      "id_str" : "12984852",
      "id" : 12984852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/KzH9FEduXq",
      "expanded_url" : "https:\/\/twitter.com\/CameronNeylon\/status\/816953941216862208",
      "display_url" : "twitter.com\/CameronNeylon\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "824369094715641856",
  "geo" : { },
  "id_str" : "824370673556537352",
  "in_reply_to_user_id" : 14286491,
  "text" : "If you want to read a bit in that direction this book selection by @CameronNeylon doesn't look to bad: https:\/\/t.co\/KzH9FEduXq",
  "id" : 824370673556537352,
  "in_reply_to_status_id" : 824369094715641856,
  "created_at" : "2017-01-25 21:37:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824367240581627910",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404577119582, 8.753418370385571 ]
  },
  "id_str" : "824369408005042180",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb I can only give that back! \uD83D\uDE0D\u270A",
  "id" : 824369408005042180,
  "in_reply_to_status_id" : 824367240581627910,
  "created_at" : "2017-01-25 21:32:37 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824367786852028416",
  "geo" : { },
  "id_str" : "824369094715641856",
  "in_reply_to_user_id" : 14286491,
  "text" : "Unfortunately our science education is completely failing at addressing this, as there are virtually no courses on the history of science\u2026",
  "id" : 824369094715641856,
  "in_reply_to_status_id" : 824367786852028416,
  "created_at" : "2017-01-25 21:31:22 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/3tHNaho9zj",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/The_Mismeasure_of_Man",
      "display_url" : "en.wikipedia.org\/wiki\/The_Misme\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "824366978022383617",
  "geo" : { },
  "id_str" : "824367786852028416",
  "in_reply_to_user_id" : 14286491,
  "text" : "And there's tons of scientific works on how science is biased by political thoughts. The Mismeasure of Man, anyone? https:\/\/t.co\/3tHNaho9zj",
  "id" : 824367786852028416,
  "in_reply_to_status_id" : 824366978022383617,
  "created_at" : "2017-01-25 21:26:11 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824366323165696000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404576261405, 8.753418466515836 ]
  },
  "id_str" : "824367243425353731",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess aye! \uD83D\uDE4F",
  "id" : 824367243425353731,
  "in_reply_to_status_id" : 824366323165696000,
  "created_at" : "2017-01-25 21:24:01 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824365650713919488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404576261511, 8.753418466504012 ]
  },
  "id_str" : "824366978022383617",
  "in_reply_to_user_id" : 14286491,
  "text" : "The worst is: it\u2019s not like there isn\u2019t a whole scientific field of inquiry that studies how science as a social enterprise is political.",
  "id" : 824366978022383617,
  "in_reply_to_status_id" : 824365650713919488,
  "created_at" : "2017-01-25 21:22:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScienceMarch",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404577119564, 8.753418370387587 ]
  },
  "id_str" : "824365650713919488",
  "text" : "The idea of \u00ABScience is apolitical\u00BB must be the meme that bugs me most about #ScienceMarch. Isn\u2019t true now and has never been true.",
  "id" : 824365650713919488,
  "created_at" : "2017-01-25 21:17:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824347104986484737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404577120324, 8.753418370308154 ]
  },
  "id_str" : "824347383874068481",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb word! \uD83D\uDE4F",
  "id" : 824347383874068481,
  "in_reply_to_status_id" : 824347104986484737,
  "created_at" : "2017-01-25 20:05:06 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824345888575328256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404578993993, 8.753418160369641 ]
  },
  "id_str" : "824346682540380165",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich just wing it. Ich kann dir garantieren das niemand es merken wird :D",
  "id" : 824346682540380165,
  "in_reply_to_status_id" : 824345888575328256,
  "created_at" : "2017-01-25 20:02:19 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScienceMarch",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824343901444173824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404578035458, 8.753418268340479 ]
  },
  "id_str" : "824346341090480143",
  "in_reply_to_user_id" : 14286491,
  "text" : "If it\u2019s anything like academia, it will take 4 years to form the organizing committees &amp; pass peer review for the #ScienceMarch route.",
  "id" : 824346341090480143,
  "in_reply_to_status_id" : 824343901444173824,
  "created_at" : "2017-01-25 20:00:57 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824344828217610252",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404604501602, 8.753417906440633 ]
  },
  "id_str" : "824345162784657418",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich daf\u00FCr w\u00FCrde sogar ich noch mal zu nem Science Slam gehen!",
  "id" : 824345162784657418,
  "in_reply_to_status_id" : 824344828217610252,
  "created_at" : "2017-01-25 19:56:17 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaena Montanari",
      "screen_name" : "DrShaena",
      "indices" : [ 0, 9 ],
      "id_str" : "999293378",
      "id" : 999293378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824344114217054208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404604501602, 8.753417906440633 ]
  },
  "id_str" : "824345081410965506",
  "in_reply_to_user_id" : 999293378,
  "text" : "@DrShaena so no need to show your PhD in an approved field before joining the protest? ;)",
  "id" : 824345081410965506,
  "in_reply_to_status_id" : 824344114217054208,
  "created_at" : "2017-01-25 19:55:57 +0000",
  "in_reply_to_screen_name" : "DrShaena",
  "in_reply_to_user_id_str" : "999293378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/BMvfzEBC2e",
      "expanded_url" : "https:\/\/twitter.com\/DrShaena\/status\/824193818614501376",
      "display_url" : "twitter.com\/DrShaena\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404574523272, 8.75341864596626 ]
  },
  "id_str" : "824343901444173824",
  "text" : "The elitist BS I feared: \u201EI\u2019d rather lose all data than march with a social scientist\u201C\u2026 https:\/\/t.co\/BMvfzEBC2e",
  "id" : 824343901444173824,
  "created_at" : "2017-01-25 19:51:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DTCtesting",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Qs5iBA8lH5",
      "expanded_url" : "https:\/\/www.theatlantic.com\/science\/archive\/2017\/01\/the-dna-test-as-horoscope\/514172\/?utm_source=twb",
      "display_url" : "theatlantic.com\/science\/archiv\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402764796591, 8.753456465036939 ]
  },
  "id_str" : "824339046621122560",
  "text" : "Sounds \u00B1 right: The DNA Test as Horoscope https:\/\/t.co\/Qs5iBA8lH5 #DTCtesting",
  "id" : 824339046621122560,
  "created_at" : "2017-01-25 19:31:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824307580596027392",
  "text" : "RT @gedankenstuecke: Imagine how people in Europe feel, literally googling \u201EAre there still the USA?\u201C first thing in the morning. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/mziUaNKAaS",
        "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/824097579927535617",
        "display_url" : "twitter.com\/wilbanks\/statu\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.17237276849178, 8.627510658616561 ]
    },
    "id_str" : "824168601766793216",
    "text" : "Imagine how people in Europe feel, literally googling \u201EAre there still the USA?\u201C first thing in the morning. https:\/\/t.co\/mziUaNKAaS",
    "id" : 824168601766793216,
    "created_at" : "2017-01-25 08:14:41 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 824307580596027392,
  "created_at" : "2017-01-25 17:26:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824260114890817537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723707011193, 8.62751702564994 ]
  },
  "id_str" : "824290202709590016",
  "in_reply_to_user_id" : 2968079445,
  "text" : "@AnneAdamPluen \uD83D\uDE0D",
  "id" : 824290202709590016,
  "in_reply_to_status_id" : 824260114890817537,
  "created_at" : "2017-01-25 16:17:53 +0000",
  "in_reply_to_screen_name" : "AnneHTTP404",
  "in_reply_to_user_id_str" : "2968079445",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/P2r74gf3Jg",
      "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/824257649399177216",
      "display_url" : "twitter.com\/abbycabs\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236237927229, 8.627521783606348 ]
  },
  "id_str" : "824289650286149632",
  "text" : "Awesome, can\u2019t wait for it to start! \uD83D\uDEEB\uD83D\uDC96\uD83C\uDF89 https:\/\/t.co\/P2r74gf3Jg",
  "id" : 824289650286149632,
  "created_at" : "2017-01-25 16:15:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Charlesworth",
      "screen_name" : "janepipistrelle",
      "indices" : [ 0, 16 ],
      "id_str" : "328098087",
      "id" : 328098087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824280608113328128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238021181297, 8.627460798193013 ]
  },
  "id_str" : "824282009652625408",
  "in_reply_to_user_id" : 328098087,
  "text" : "@janepipistrelle absolutely, ppl ask you something &amp; it\u2019s \u201Euh, I just know, that\u2019s why?\u201C. On positive side: we have lots of knowledge :P",
  "id" : 824282009652625408,
  "in_reply_to_status_id" : 824280608113328128,
  "created_at" : "2017-01-25 15:45:20 +0000",
  "in_reply_to_screen_name" : "janepipistrelle",
  "in_reply_to_user_id_str" : "328098087",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 3, 13 ],
      "id_str" : "93434375",
      "id" : 93434375
    }, {
      "name" : "OSCAL'18",
      "screen_name" : "OSCALconf",
      "indices" : [ 94, 104 ],
      "id_str" : "776738133518016512",
      "id" : 776738133518016512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenSource",
      "indices" : [ 24, 35 ]
    }, {
      "text" : "OSCAL2017",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824272616081018881",
  "text" : "RT @elioqoshi: Have any #OpenSource topic you want to talk about? Submit a talk at #OSCAL2017 @OSCALconf and meet me in Tirana!\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OSCAL'18",
        "screen_name" : "OSCALconf",
        "indices" : [ 79, 89 ],
        "id_str" : "776738133518016512",
        "id" : 776738133518016512
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenSource",
        "indices" : [ 9, 20 ]
      }, {
        "text" : "OSCAL2017",
        "indices" : [ 68, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/LSadL4qVTh",
        "expanded_url" : "http:\/\/oscal.openlabs.cc\/oscal-2017-call-for-proposals\/",
        "display_url" : "oscal.openlabs.cc\/oscal-2017-cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "824256265077616641",
    "text" : "Have any #OpenSource topic you want to talk about? Submit a talk at #OSCAL2017 @OSCALconf and meet me in Tirana!\nhttps:\/\/t.co\/LSadL4qVTh",
    "id" : 824256265077616641,
    "created_at" : "2017-01-25 14:03:02 +0000",
    "user" : {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "protected" : false,
      "id_str" : "93434375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/901739947002081280\/GxTmOE6l_normal.jpg",
      "id" : 93434375,
      "verified" : false
    }
  },
  "id" : 824272616081018881,
  "created_at" : "2017-01-25 15:08:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Charlesworth",
      "screen_name" : "janepipistrelle",
      "indices" : [ 0, 16 ],
      "id_str" : "328098087",
      "id" : 328098087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824255759076757506",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237153741451, 8.62754303404821 ]
  },
  "id_str" : "824272428163592194",
  "in_reply_to_user_id" : 328098087,
  "text" : "@janepipistrelle totally know that feeling, regardless of language taught. There\u2019s so much implicit knowledge one takes for granted!",
  "id" : 824272428163592194,
  "in_reply_to_status_id" : 824255759076757506,
  "created_at" : "2017-01-25 15:07:15 +0000",
  "in_reply_to_screen_name" : "janepipistrelle",
  "in_reply_to_user_id_str" : "328098087",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823899882138308609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233711450341, 8.627478371293474 ]
  },
  "id_str" : "824234411726139392",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick the html of the email isn\u2019t valid &amp; looks like a 5 y\/o just discovered MS paint.",
  "id" : 824234411726139392,
  "in_reply_to_status_id" : 823899882138308609,
  "created_at" : "2017-01-25 12:36:11 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824211574692937728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724010088049, 8.62745928431017 ]
  },
  "id_str" : "824232253391826945",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch nah, faster punching is the way to go.",
  "id" : 824232253391826945,
  "in_reply_to_status_id" : 824211574692937728,
  "created_at" : "2017-01-25 12:27:37 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Scanlan",
      "screen_name" : "JackLScanlan",
      "indices" : [ 0, 13 ],
      "id_str" : "10342612",
      "id" : 10342612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824208459071561728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17272472821412, 8.627573759703704 ]
  },
  "id_str" : "824212362177744896",
  "in_reply_to_user_id" : 10342612,
  "text" : "@JackLScanlan thanks!",
  "id" : 824212362177744896,
  "in_reply_to_status_id" : 824208459071561728,
  "created_at" : "2017-01-25 11:08:34 +0000",
  "in_reply_to_screen_name" : "JackLScanlan",
  "in_reply_to_user_id_str" : "10342612",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Scanlan",
      "screen_name" : "JackLScanlan",
      "indices" : [ 0, 13 ],
      "id_str" : "10342612",
      "id" : 10342612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824208089431691264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237428038176, 8.627508749875433 ]
  },
  "id_str" : "824208231639687168",
  "in_reply_to_user_id" : 10342612,
  "text" : "@JackLScanlan still have to get it to successfully run though \uD83D\uDE02",
  "id" : 824208231639687168,
  "in_reply_to_status_id" : 824208089431691264,
  "created_at" : "2017-01-25 10:52:10 +0000",
  "in_reply_to_screen_name" : "JackLScanlan",
  "in_reply_to_user_id_str" : "10342612",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Ed18OUM57q",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2017\/01\/05\/098566",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235635736697, 8.62746701143177 ]
  },
  "id_str" : "824207345194594304",
  "text" : "OrthoFiller: utilising data from multiple species to improve the completeness of genome annotations. https:\/\/t.co\/Ed18OUM57q",
  "id" : 824207345194594304,
  "created_at" : "2017-01-25 10:48:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 11, 20 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/824180029156458497\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/bJS5N4unC3",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C3ATXRZXcAEwXuW.jpg",
      "id_str" : "824180022336516097",
      "id" : 824180022336516097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C3ATXRZXcAEwXuW.jpg",
      "sizes" : [ {
        "h" : 250,
        "resize" : "fit",
        "w" : 220
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 220
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 220
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 220
      } ],
      "display_url" : "pic.twitter.com\/bJS5N4unC3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824178875991265280",
  "geo" : { },
  "id_str" : "824180029156458497",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @wilbanks exactly that, before the first coffee. \u2615\uFE0F https:\/\/t.co\/bJS5N4unC3",
  "id" : 824180029156458497,
  "in_reply_to_status_id" : 824178875991265280,
  "created_at" : "2017-01-25 09:00:06 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824171785105141760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233827426354, 8.62749476556141 ]
  },
  "id_str" : "824172107982655492",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski lowercase l and uppercase I are totally discernible with that font :p",
  "id" : 824172107982655492,
  "in_reply_to_status_id" : 824171785105141760,
  "created_at" : "2017-01-25 08:28:37 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824171238176198657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238637434837, 8.627480157702648 ]
  },
  "id_str" : "824171756025942016",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField \u00ABOn a scale from 0 to \u201Eugly little mustache\u201C, how facist are the USA by today?\u00BB",
  "id" : 824171756025942016,
  "in_reply_to_status_id" : 824171238176198657,
  "created_at" : "2017-01-25 08:27:13 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/mziUaNKAaS",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/824097579927535617",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237276849178, 8.627510658616561 ]
  },
  "id_str" : "824168601766793216",
  "text" : "Imagine how people in Europe feel, literally googling \u201EAre there still the USA?\u201C first thing in the morning. https:\/\/t.co\/mziUaNKAaS",
  "id" : 824168601766793216,
  "created_at" : "2017-01-25 08:14:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexey Sergushichev",
      "screen_name" : "assaron",
      "indices" : [ 0, 8 ],
      "id_str" : "159783398",
      "id" : 159783398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824163324409614336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239024802456, 8.627519916924694 ]
  },
  "id_str" : "824163967849431040",
  "in_reply_to_user_id" : 159783398,
  "text" : "@assaron thanks. Will advertise it today in my journal club, let\u2019s see that we can get more people join!",
  "id" : 824163967849431040,
  "in_reply_to_status_id" : 824163324409614336,
  "created_at" : "2017-01-25 07:56:16 +0000",
  "in_reply_to_screen_name" : "assaron",
  "in_reply_to_user_id_str" : "159783398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/q8bZJWYu8K",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/places\/attrap-reves",
      "display_url" : "atlasobscura.com\/places\/attrap-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404578253801, 8.753417540140546 ]
  },
  "id_str" : "824035941509636096",
  "text" : "that\u2019s some posh camping https:\/\/t.co\/q8bZJWYu8K",
  "id" : 824035941509636096,
  "created_at" : "2017-01-24 23:27:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824020571419770882",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401136830255, 8.75345926460338 ]
  },
  "id_str" : "824021091777658882",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor Danke!",
  "id" : 824021091777658882,
  "in_reply_to_status_id" : 824020571419770882,
  "created_at" : "2017-01-24 22:28:32 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    }, {
      "name" : "Dave Arnold \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "DaveArnold91",
      "indices" : [ 13, 26 ],
      "id_str" : "536465090",
      "id" : 536465090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824013903055257600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403494525592, 8.75337036130433 ]
  },
  "id_str" : "824014193292640258",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay @DaveArnold91  I\u2019ll take you up on that!",
  "id" : 824014193292640258,
  "in_reply_to_status_id" : 824013903055257600,
  "created_at" : "2017-01-24 22:01:07 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    }, {
      "name" : "Dave Arnold \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "DaveArnold91",
      "indices" : [ 13, 26 ],
      "id_str" : "536465090",
      "id" : 536465090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824013466226847746",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404245078393, 8.753419103313012 ]
  },
  "id_str" : "824013600662626304",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay @DaveArnold91 now I feel like I missed out on a hell of a party in Sheffield. Gotta come to London soon!",
  "id" : 824013600662626304,
  "in_reply_to_status_id" : 824013466226847746,
  "created_at" : "2017-01-24 21:58:46 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824010095361163266",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404533496952, 8.753419640707225 ]
  },
  "id_str" : "824010371417669632",
  "in_reply_to_user_id" : 14286491,
  "text" : "My best bet: In the finals everyone will have to write their own short read aligner.",
  "id" : 824010371417669632,
  "in_reply_to_status_id" : 824010095361163266,
  "created_at" : "2017-01-24 21:45:56 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/limkevWrD5",
      "expanded_url" : "http:\/\/contest.bioinf.me\/",
      "display_url" : "contest.bioinf.me"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/AfpJSRM51q",
      "expanded_url" : "https:\/\/twitter.com\/assaron\/status\/823962630016602112",
      "display_url" : "twitter.com\/assaron\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404533496952, 8.753419640707225 ]
  },
  "id_str" : "824010095361163266",
  "text" : "Phew, just solved another question at https:\/\/t.co\/limkevWrD5 Got my 600+ points to qualify for the final round. \uD83E\uDD13\uD83C\uDF89\uD83C\uDF88 https:\/\/t.co\/AfpJSRM51q",
  "id" : 824010095361163266,
  "created_at" : "2017-01-24 21:44:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    }, {
      "name" : "Dave Arnold \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "DaveArnold91",
      "indices" : [ 13, 26 ],
      "id_str" : "536465090",
      "id" : 536465090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824002802309537792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140457493777, 8.753418637291462 ]
  },
  "id_str" : "824003339390218242",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay @DaveArnold91 do you have the variant that makes you a noisy neighbor?",
  "id" : 824003339390218242,
  "in_reply_to_status_id" : 824002802309537792,
  "created_at" : "2017-01-24 21:18:00 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joint Genome Inst.",
      "screen_name" : "doe_jgi",
      "indices" : [ 96, 104 ],
      "id_str" : "20750406",
      "id" : 20750406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403646405559, 8.75343763782537 ]
  },
  "id_str" : "824002725058932736",
  "text" : "Wondering: Is there any need to rush &amp; create an off-\uD83C\uDDFA\uD83C\uDDF8 backup of all the genomes hosted by @doe_jgi? Asking for a friend.",
  "id" : 824002725058932736,
  "created_at" : "2017-01-24 21:15:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexey Sergushichev",
      "screen_name" : "assaron",
      "indices" : [ 0, 8 ],
      "id_str" : "159783398",
      "id" : 159783398
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823962630016602112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399276952864, 8.753529689876615 ]
  },
  "id_str" : "823968562780008451",
  "in_reply_to_user_id" : 159783398,
  "text" : "@assaron @PhilippBayer First I need to get my 600 points to even make it there! :D",
  "id" : 823968562780008451,
  "in_reply_to_status_id" : 823962630016602112,
  "created_at" : "2017-01-24 18:59:48 +0000",
  "in_reply_to_screen_name" : "assaron",
  "in_reply_to_user_id_str" : "159783398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823841857746726913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247199343969, 8.627570413720928 ]
  },
  "id_str" : "823842384949682176",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin misread that as pre-WWII first and was very confused.",
  "id" : 823842384949682176,
  "in_reply_to_status_id" : 823841857746726913,
  "created_at" : "2017-01-24 10:38:25 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823817638770077696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233792482066, 8.627502505905467 ]
  },
  "id_str" : "823817946661318658",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin I know, was just reminded of the post now \uD83D\uDE0A",
  "id" : 823817946661318658,
  "in_reply_to_status_id" : 823817638770077696,
  "created_at" : "2017-01-24 09:01:18 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/SktNgyXmuX",
      "expanded_url" : "http:\/\/www.theallium.com\/biology\/genome-study-finds-gene-believing-genome-studies\/",
      "display_url" : "theallium.com\/biology\/genome\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "823814490743521283",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239289784112, 8.62744244385718 ]
  },
  "id_str" : "823817126289035264",
  "in_reply_to_user_id" : 14286491,
  "text" : "Related: Genome Study Finds Gene For Believing Genome Studies https:\/\/t.co\/SktNgyXmuX",
  "id" : 823817126289035264,
  "in_reply_to_status_id" : 823814490743521283,
  "created_at" : "2017-01-24 08:58:03 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/dJGM2s3hfC",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0168895",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242175729621, 8.62752164682401 ]
  },
  "id_str" : "823814490743521283",
  "text" : "\u00ABPersonalized Media: A Genetically Informative Investigation of Individual Differences in Online Media Use\u00BB o_O https:\/\/t.co\/dJGM2s3hfC",
  "id" : 823814490743521283,
  "created_at" : "2017-01-24 08:47:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823703043308822529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404575453432, 8.753418557016161 ]
  },
  "id_str" : "823703094215213056",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer dunno, I did",
  "id" : 823703094215213056,
  "in_reply_to_status_id" : 823703043308822529,
  "created_at" : "2017-01-24 01:24:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823688461953613824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140457899545, 8.75341816031942 ]
  },
  "id_str" : "823702343657078784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer also: looked at the problems and they are really challenging! \uD83D\uDE31",
  "id" : 823702343657078784,
  "in_reply_to_status_id" : 823688461953613824,
  "created_at" : "2017-01-24 01:21:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alt-Right Getting",
      "screen_name" : "PunchedToMusic",
      "indices" : [ 17, 32 ],
      "id_str" : "823070847032143872",
      "id" : 823070847032143872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404372203673, 8.7534230993719 ]
  },
  "id_str" : "823698288851484672",
  "text" : "Haven\u2019t seen any @PunchedToMusic with the Safety Dance yet. \uD83E\uDD14",
  "id" : 823698288851484672,
  "created_at" : "2017-01-24 01:05:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/dp4UpBu80A",
      "expanded_url" : "https:\/\/twitter.com\/Helena_LB\/status\/823526533008650240",
      "display_url" : "twitter.com\/Helena_LB\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241216880343, 8.627368547154925 ]
  },
  "id_str" : "823530297551716356",
  "text" : "Coming back to a project after you took a long break. https:\/\/t.co\/dp4UpBu80A",
  "id" : 823530297551716356,
  "created_at" : "2017-01-23 13:58:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. C. Sinclair",
      "screen_name" : "MSUSocialPsy",
      "indices" : [ 12, 25 ],
      "id_str" : "1061649098",
      "id" : 1061649098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/taNbHycj8t",
      "expanded_url" : "http:\/\/daniellakens.blogspot.de\/2014\/06\/data-peeking-without-p-hacking.html",
      "display_url" : "daniellakens.blogspot.de\/2014\/06\/data-p\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235749781949, 8.627483755247997 ]
  },
  "id_str" : "823529265937387520",
  "text" : "@JohnHamre3 @MSUSocialPsy the issue is with collecting data until you hit p&lt;.5 and then stopping, c.f. https:\/\/t.co\/taNbHycj8t",
  "id" : 823529265937387520,
  "created_at" : "2017-01-23 13:54:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 32, 42 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/823487670177452032\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/IYVKiANHks",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C22dq4kXEAAZurB.jpg",
      "id_str" : "823487666943627264",
      "id" : 823487666943627264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C22dq4kXEAAZurB.jpg",
      "sizes" : [ {
        "h" : 214,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/IYVKiANHks"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235011310361, 8.627507778143768 ]
  },
  "id_str" : "823487670177452032",
  "text" : "It\u2019s important to be organised. @Julie_B92 https:\/\/t.co\/IYVKiANHks",
  "id" : 823487670177452032,
  "created_at" : "2017-01-23 11:08:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Charlesworth",
      "screen_name" : "janepipistrelle",
      "indices" : [ 0, 16 ],
      "id_str" : "328098087",
      "id" : 328098087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823487006990802945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723680599431, 8.627502726541994 ]
  },
  "id_str" : "823487298146856964",
  "in_reply_to_user_id" : 328098087,
  "text" : "@janepipistrelle that\u2019s so sweet! \uD83D\uDC96",
  "id" : 823487298146856964,
  "in_reply_to_status_id" : 823487006990802945,
  "created_at" : "2017-01-23 11:07:26 +0000",
  "in_reply_to_screen_name" : "janepipistrelle",
  "in_reply_to_user_id_str" : "328098087",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 15, 31 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/3j047hQnF8",
      "expanded_url" : "https:\/\/i.makeagif.com\/media\/1-06-2014\/oZuNwt.gif",
      "display_url" : "i.makeagif.com\/media\/1-06-201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "823485896666320896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235769234019, 8.627513912491564 ]
  },
  "id_str" : "823487148598890496",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson @pathogenomenick What having things under control means in science: https:\/\/t.co\/3j047hQnF8",
  "id" : 823487148598890496,
  "in_reply_to_status_id" : 823485896666320896,
  "created_at" : "2017-01-23 11:06:50 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/5McuXEjxTH",
      "expanded_url" : "https:\/\/twitter.com\/KarlreMarks\/status\/823447482298466304",
      "display_url" : "twitter.com\/KarlreMarks\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236631395849, 8.627513601999496 ]
  },
  "id_str" : "823477814771019776",
  "text" : "\u00ABWhat\u2019s the origin of the schism between the neo-conservatives and paleoconservatives?\u00BB \uD83D\uDE02 https:\/\/t.co\/5McuXEjxTH",
  "id" : 823477814771019776,
  "created_at" : "2017-01-23 10:29:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Sharro",
      "screen_name" : "KarlreMarks",
      "indices" : [ 3, 15 ],
      "id_str" : "25058787",
      "id" : 25058787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/LNKB0S3ylN",
      "expanded_url" : "http:\/\/politi.co\/2khoRSB",
      "display_url" : "politi.co\/2khoRSB"
    } ]
  },
  "geo" : { },
  "id_str" : "823476913876385793",
  "text" : "RT @KarlreMarks: America, You Look Like an Arab Country Right Now https:\/\/t.co\/LNKB0S3ylN Me, trolling America.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/LNKB0S3ylN",
        "expanded_url" : "http:\/\/politi.co\/2khoRSB",
        "display_url" : "politi.co\/2khoRSB"
      } ]
    },
    "geo" : { },
    "id_str" : "823447482298466304",
    "text" : "America, You Look Like an Arab Country Right Now https:\/\/t.co\/LNKB0S3ylN Me, trolling America.",
    "id" : 823447482298466304,
    "created_at" : "2017-01-23 08:29:13 +0000",
    "user" : {
      "name" : "Karl Sharro",
      "screen_name" : "KarlreMarks",
      "protected" : false,
      "id_str" : "25058787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895948211063574530\/JUb_McAK_normal.jpg",
      "id" : 25058787,
      "verified" : true
    }
  },
  "id" : 823476913876385793,
  "created_at" : "2017-01-23 10:26:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/823472117832368128\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/c06ds8VcRj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C22PhVDXAAAo5Q0.jpg",
      "id_str" : "823472109628358656",
      "id" : 823472109628358656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C22PhVDXAAAo5Q0.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/c06ds8VcRj"
    } ],
    "hashtags" : [ {
      "text" : "DoesItFart",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236356050405, 8.62751902860562 ]
  },
  "id_str" : "823472117832368128",
  "text" : "Following the success of #DoesItFart: The power of poo. \uD83D\uDCA9 https:\/\/t.co\/c06ds8VcRj",
  "id" : 823472117832368128,
  "created_at" : "2017-01-23 10:07:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823466937510494208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723658487756, 8.627515870785903 ]
  },
  "id_str" : "823468802755227648",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 you\u2019re really lucky!",
  "id" : 823468802755227648,
  "in_reply_to_status_id" : 823466937510494208,
  "created_at" : "2017-01-23 09:53:56 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823465789185544192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236531834384, 8.627502397408538 ]
  },
  "id_str" : "823466786565869568",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 lots of crying, don\u2019t forget the crying.",
  "id" : 823466786565869568,
  "in_reply_to_status_id" : 823465789185544192,
  "created_at" : "2017-01-23 09:45:55 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 10, 25 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823315707798622209",
  "text" : "@kopshtik @EmilyGorcenski I feel you, can't stand being there at all :(",
  "id" : 823315707798622209,
  "created_at" : "2017-01-22 23:45:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823183358666637312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090657593321, 8.818741251064484 ]
  },
  "id_str" : "823221958565187584",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna \uD83D\uDE0D\uD83D\uDC96",
  "id" : 823221958565187584,
  "in_reply_to_status_id" : 823183358666637312,
  "created_at" : "2017-01-22 17:33:04 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/Qu0m5AwOoo",
      "expanded_url" : "https:\/\/twitter.com\/sujaik\/status\/823123126821257217",
      "display_url" : "twitter.com\/sujaik\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404485831869, 8.753419812065063 ]
  },
  "id_str" : "823124347829239808",
  "text" : "I\u2019m dying. \uD83D\uDE02 https:\/\/t.co\/Qu0m5AwOoo",
  "id" : 823124347829239808,
  "created_at" : "2017-01-22 11:05:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Rob Syme",
      "screen_name" : "robsyme",
      "indices" : [ 14, 22 ],
      "id_str" : "15027761",
      "id" : 15027761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822979519535419393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404482455956, 8.753421992695495 ]
  },
  "id_str" : "823120146671734785",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @robsyme nice! Would love that. That\u2019s a thing that makes me wake up at 5am, in cold sweat.",
  "id" : 823120146671734785,
  "in_reply_to_status_id" : 822979519535419393,
  "created_at" : "2017-01-22 10:48:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/823118947637690368\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/iR50hI8OIV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C2xOUT_XUAIoodT.jpg",
      "id_str" : "823118942772350978",
      "id" : 823118942772350978,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2xOUT_XUAIoodT.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/iR50hI8OIV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404379741056, 8.753422212124066 ]
  },
  "id_str" : "823118947637690368",
  "text" : "\u00ABThis was the largest audience to ever witness an inauguration, period.\u00BB \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/iR50hI8OIV",
  "id" : 823118947637690368,
  "created_at" : "2017-01-22 10:43:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Raphael Levy)))",
      "screen_name" : "raphavisses",
      "indices" : [ 0, 12 ],
      "id_str" : "140966030",
      "id" : 140966030
    }, {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 13, 24 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822868380013264897",
  "geo" : { },
  "id_str" : "822872627052236800",
  "in_reply_to_user_id" : 140966030,
  "text" : "@raphavisses @lteytelman dunno, feel if US scientists want to interact w\/ world they now can come and visit instead of vice versa.",
  "id" : 822872627052236800,
  "in_reply_to_status_id" : 822868380013264897,
  "created_at" : "2017-01-21 18:24:57 +0000",
  "in_reply_to_screen_name" : "raphavisses",
  "in_reply_to_user_id_str" : "140966030",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Raphael Levy)))",
      "screen_name" : "raphavisses",
      "indices" : [ 0, 12 ],
      "id_str" : "140966030",
      "id" : 140966030
    }, {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 13, 24 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822854787947491335",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404553007245, 8.753420507037049 ]
  },
  "id_str" : "822855219746836485",
  "in_reply_to_user_id" : 140966030,
  "text" : "@raphavisses @lteytelman an even more relevant one though. US conferences just became even more exclusionary than they\u2019ve been before.",
  "id" : 822855219746836485,
  "in_reply_to_status_id" : 822854787947491335,
  "created_at" : "2017-01-21 17:15:46 +0000",
  "in_reply_to_screen_name" : "raphavisses",
  "in_reply_to_user_id_str" : "140966030",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 0, 11 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822831803916423168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404406872974, 8.75341947594318 ]
  },
  "id_str" : "822850528937910273",
  "in_reply_to_user_id" : 1343132275,
  "text" : "@lteytelman it\u2019s less about boycotting but about whether it\u2019s still safe for me to travel to the USA. Still unsure about that one\u2026",
  "id" : 822850528937910273,
  "in_reply_to_status_id" : 822831803916423168,
  "created_at" : "2017-01-21 16:57:08 +0000",
  "in_reply_to_screen_name" : "lteytelman",
  "in_reply_to_user_id_str" : "1343132275",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822753771893751809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404424769945, 8.75342163287499 ]
  },
  "id_str" : "822776574575517696",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk the new one is a Corsa as well. And I\u2019ll put a sticker there as well \uD83D\uDE02",
  "id" : 822776574575517696,
  "in_reply_to_status_id" : 822753771893751809,
  "created_at" : "2017-01-21 12:03:16 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/0WxEN7tI0j",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/822753199345922048",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1037850595927, 8.766553414213652 ]
  },
  "id_str" : "822753378048610304",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk https:\/\/t.co\/0WxEN7tI0j :(",
  "id" : 822753378048610304,
  "created_at" : "2017-01-21 10:31:06 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/qeU8kt983j",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BPhes33hGwz\/",
      "display_url" : "instagram.com\/p\/BPhes33hGwz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "822753199345922048",
  "text" : "And there goes the poor old car into the junkyard. https:\/\/t.co\/qeU8kt983j",
  "id" : 822753199345922048,
  "created_at" : "2017-01-21 10:30:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140433429246, 8.753419675594026 ]
  },
  "id_str" : "822516175552860160",
  "text" : "\u05D2\u05DD \u05D6\u05D4 \u05D9\u05E2\u05D1\u05D5\u05E8\u2026",
  "id" : 822516175552860160,
  "created_at" : "2017-01-20 18:48:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822450809501843457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236356301878, 8.627516202952974 ]
  },
  "id_str" : "822451951338213376",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski enjoy it!",
  "id" : 822451951338213376,
  "in_reply_to_status_id" : 822450809501843457,
  "created_at" : "2017-01-20 14:33:20 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Carly Strasser",
      "screen_name" : "carlystrasser",
      "indices" : [ 10, 24 ],
      "id_str" : "190246525",
      "id" : 190246525
    }, {
      "name" : "David Lang",
      "screen_name" : "davidtlang",
      "indices" : [ 25, 36 ],
      "id_str" : "14965981",
      "id" : 14965981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822442654646603776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239266534101, 8.627428614531475 ]
  },
  "id_str" : "822443094100635652",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @carlystrasser @davidtlang word!",
  "id" : 822443094100635652,
  "in_reply_to_status_id" : 822442654646603776,
  "created_at" : "2017-01-20 13:58:08 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lgbtsteminar17",
      "indices" : [ 74, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/kZmEgbiTb5",
      "expanded_url" : "https:\/\/psiloveyou.xyz\/help-me-im-on-tinder-i-don-t-want-to-see-your-code-711de4986ab8?source=twitterShare-aaeb714c1b80-1484919531",
      "display_url" : "psiloveyou.xyz\/help-me-im-on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "822438596011499524",
  "text" : "Ok folks, maybe don't over-do it with preaching (open) science on Tinder. #lgbtsteminar17  https:\/\/t.co\/kZmEgbiTb5",
  "id" : 822438596011499524,
  "created_at" : "2017-01-20 13:40:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Servan Gr\u00FCninger",
      "screen_name" : "SGruninger",
      "indices" : [ 0, 11 ],
      "id_str" : "1361723136",
      "id" : 1361723136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/i7nPT6RffG",
      "expanded_url" : "http:\/\/grindr-remembers.blogspot.de\/",
      "display_url" : "grindr-remembers.blogspot.de"
    } ]
  },
  "in_reply_to_status_id_str" : "822402081176846337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241212573769, 8.627368602781893 ]
  },
  "id_str" : "822419698402885633",
  "in_reply_to_user_id" : 1361723136,
  "text" : "@SGruninger c.f. https:\/\/t.co\/i7nPT6RffG",
  "id" : 822419698402885633,
  "in_reply_to_status_id" : 822402081176846337,
  "created_at" : "2017-01-20 12:25:10 +0000",
  "in_reply_to_screen_name" : "SGruninger",
  "in_reply_to_user_id_str" : "1361723136",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/P00RmOrqs5",
      "expanded_url" : "https:\/\/twitter.com\/goetheuni\/status\/822396105723785217",
      "display_url" : "twitter.com\/goetheuni\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237261420824, 8.627513395573397 ]
  },
  "id_str" : "822414541220880384",
  "text" : "Someone\u2019s feeling megalomaniac: \u2018Will Frankfurt be the new London?\u2019 Again an easy spoiler: Nope. https:\/\/t.co\/P00RmOrqs5",
  "id" : 822414541220880384,
  "created_at" : "2017-01-20 12:04:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 7, 20 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 21, 28 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822397402963320832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239081281176, 8.62746865256722 ]
  },
  "id_str" : "822397840475291648",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Mcarthur_Joe @Koalha plus Craig Venter is misspelled\u2026",
  "id" : 822397840475291648,
  "in_reply_to_status_id" : 822397402963320832,
  "created_at" : "2017-01-20 10:58:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 7, 20 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 21, 28 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/dVsiqj5X8t",
      "expanded_url" : "http:\/\/www.thednastore.com\/dnastuff\/tie6.html",
      "display_url" : "thednastore.com\/dnastuff\/tie6.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "822397402963320832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239081281176, 8.62746865256722 ]
  },
  "id_str" : "822397768161337344",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Mcarthur_Joe @Koalha https:\/\/t.co\/dVsiqj5X8t LOL, who (except for Jim Watson) wants to wear Jim Watson\u2019s name on a tie?!",
  "id" : 822397768161337344,
  "in_reply_to_status_id" : 822397402963320832,
  "created_at" : "2017-01-20 10:58:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/3K3F6ovJ12",
      "expanded_url" : "http:\/\/m.imgur.com\/wc2fPoJ?r",
      "display_url" : "m.imgur.com\/wc2fPoJ?r"
    }, {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/HROk7zP3qc",
      "expanded_url" : "https:\/\/twitter.com\/bella_velo\/status\/822272191748313089",
      "display_url" : "twitter.com\/bella_velo\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238964816585, 8.627533580460796 ]
  },
  "id_str" : "822371174994755584",
  "text" : "Can\u2019t argue with that. https:\/\/t.co\/3K3F6ovJ12 https:\/\/t.co\/HROk7zP3qc",
  "id" : 822371174994755584,
  "created_at" : "2017-01-20 09:12:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822216810619686912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06096415141676, 8.81851637051525 ]
  },
  "id_str" : "822222716719788032",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps Mine was only 5 years old, but so heavily used that the looks of it gave me trouble while trying to enter countries. ;-)",
  "id" : 822222716719788032,
  "in_reply_to_status_id" : 822216810619686912,
  "created_at" : "2017-01-19 23:22:26 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 0, 13 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 14, 21 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822212271904530432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084667921936, 8.818751717489967 ]
  },
  "id_str" : "822216406561341441",
  "in_reply_to_user_id" : 478181304,
  "text" : "@Mcarthur_Joe @Koalha do you have your own YT channel for that? :D",
  "id" : 822216406561341441,
  "in_reply_to_status_id" : 822212271904530432,
  "created_at" : "2017-01-19 22:57:22 +0000",
  "in_reply_to_screen_name" : "Mcarthur_Joe",
  "in_reply_to_user_id_str" : "478181304",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822194644616413184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06094778788259, 8.81866310342852 ]
  },
  "id_str" : "822194760819601409",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 i found that one too and was so tempted to use it! \uD83D\uDE0D\uD83D\uDC36",
  "id" : 822194760819601409,
  "in_reply_to_status_id" : 822194644616413184,
  "created_at" : "2017-01-19 21:31:21 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/822194369151303680\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/nwDqNifayH",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C2kFaf-XEAQQ0PQ.jpg",
      "id_str" : "822194359789621252",
      "id" : 822194359789621252,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C2kFaf-XEAQQ0PQ.jpg",
      "sizes" : [ {
        "h" : 206,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/nwDqNifayH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822193885963227137",
  "geo" : { },
  "id_str" : "822194369151303680",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 yep, fully agree! https:\/\/t.co\/nwDqNifayH",
  "id" : 822194369151303680,
  "in_reply_to_status_id" : 822193885963227137,
  "created_at" : "2017-01-19 21:29:47 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 77, 90 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 91, 98 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/pf8PcxoXDQ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/822191943681802241",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "822191943681802241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099927607299, 8.818848520644908 ]
  },
  "id_str" : "822193889666801665",
  "in_reply_to_user_id" : 14286491,
  "text" : "I should watch out, otherwise I\u2019ll soon wear a tie or something (don\u2019t worry @Mcarthur_Joe @Koalha, probably won\u2019t happen). https:\/\/t.co\/pf8PcxoXDQ",
  "id" : 822193889666801665,
  "in_reply_to_status_id" : 822191943681802241,
  "created_at" : "2017-01-19 21:27:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06097479558424, 8.818666152443486 ]
  },
  "id_str" : "822191943681802241",
  "text" : "Heavy adulting today: picked up my new passport, got ESTA approval for it, and got my new car registered.",
  "id" : 822191943681802241,
  "created_at" : "2017-01-19 21:20:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/OTdd9rjM0X",
      "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/822073421664227328",
      "display_url" : "twitter.com\/o_guest\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236487506391, 8.62746287429491 ]
  },
  "id_str" : "822079530890366978",
  "text" : "Weekend plan: hide under my blanket and watch this for 18 hours\/day. https:\/\/t.co\/OTdd9rjM0X",
  "id" : 822079530890366978,
  "created_at" : "2017-01-19 13:53:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Kelly",
      "screen_name" : "TyLKelly",
      "indices" : [ 0, 9 ],
      "id_str" : "38707602",
      "id" : 38707602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822033407538565125",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723321081115, 8.62758765940688 ]
  },
  "id_str" : "822033620483375105",
  "in_reply_to_user_id" : 38707602,
  "text" : "@TyLKelly \uD83C\uDF46\uD83D\uDEBF\uD83D\uDE02",
  "id" : 822033620483375105,
  "in_reply_to_status_id" : 822033407538565125,
  "created_at" : "2017-01-19 10:51:02 +0000",
  "in_reply_to_screen_name" : "TyLKelly",
  "in_reply_to_user_id_str" : "38707602",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Kelly",
      "screen_name" : "TyLKelly",
      "indices" : [ 0, 9 ],
      "id_str" : "38707602",
      "id" : 38707602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822030235323527168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723641055235, 8.627515806491243 ]
  },
  "id_str" : "822032802183049216",
  "in_reply_to_user_id" : 38707602,
  "text" : "@TyLKelly p-ness, seriously? How shall I pretend to be an adult if the jokes start writing themselves?",
  "id" : 822032802183049216,
  "in_reply_to_status_id" : 822030235323527168,
  "created_at" : "2017-01-19 10:47:47 +0000",
  "in_reply_to_screen_name" : "TyLKelly",
  "in_reply_to_user_id_str" : "38707602",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822030199181246464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238191957266, 8.62746814217193 ]
  },
  "id_str" : "822030422599200768",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad that seems to be a waste of time, doing all of this just to be a one-trick pony in the end. \uD83D\uDE02",
  "id" : 822030422599200768,
  "in_reply_to_status_id" : 822030199181246464,
  "created_at" : "2017-01-19 10:38:19 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237220838378, 8.627512228053229 ]
  },
  "id_str" : "822023576354258944",
  "text" : "Is there some way to earn a living as \u201Cp-value misconception consultant\u201D?",
  "id" : 822023576354258944,
  "created_at" : "2017-01-19 10:11:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kittybiome",
      "screen_name" : "kittybiome",
      "indices" : [ 0, 11 ],
      "id_str" : "3164853619",
      "id" : 3164853619
    }, {
      "name" : "Holly Ganz",
      "screen_name" : "hollyhganz",
      "indices" : [ 12, 23 ],
      "id_str" : "23547345",
      "id" : 23547345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821849243254067201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092821718199, 8.818448949613439 ]
  },
  "id_str" : "821849953706315776",
  "in_reply_to_user_id" : 3164853619,
  "text" : "@kittybiome @hollyhganz congrats! \uD83C\uDF89\uD83C\uDF88\uD83C\uDF8A\uD83C\uDF7E",
  "id" : 821849953706315776,
  "in_reply_to_status_id" : 821849243254067201,
  "created_at" : "2017-01-18 22:41:12 +0000",
  "in_reply_to_screen_name" : "kittybiome",
  "in_reply_to_user_id_str" : "3164853619",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 25, 39 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821779868803334149",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0489187216527, 8.800253222702853 ]
  },
  "id_str" : "821796006056566784",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a awesome, say hi to @marcelsalathe!",
  "id" : 821796006056566784,
  "in_reply_to_status_id" : 821779868803334149,
  "created_at" : "2017-01-18 19:06:50 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Incidentally Bentley",
      "screen_name" : "Incidentallyb",
      "indices" : [ 0, 14 ],
      "id_str" : "415147067",
      "id" : 415147067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821738094508601345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238059975038, 8.627491042463328 ]
  },
  "id_str" : "821738874451988481",
  "in_reply_to_user_id" : 415147067,
  "text" : "@Incidentallyb enjoy! \uD83D\uDE02",
  "id" : 821738874451988481,
  "in_reply_to_status_id" : 821738094508601345,
  "created_at" : "2017-01-18 15:19:49 +0000",
  "in_reply_to_screen_name" : "Incidentallyb",
  "in_reply_to_user_id_str" : "415147067",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Incidentally Bentley",
      "screen_name" : "Incidentallyb",
      "indices" : [ 0, 14 ],
      "id_str" : "415147067",
      "id" : 415147067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/VtiKbGH0lG",
      "expanded_url" : "https:\/\/github.com\/erikr\/lessobviouschecklist",
      "display_url" : "github.com\/erikr\/lessobvi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "821734905549901824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237314580178, 8.627512375841834 ]
  },
  "id_str" : "821735672792879104",
  "in_reply_to_user_id" : 415147067,
  "text" : "@Incidentallyb If you\u2019re not only interested in CoCs, but accessibility\/inclusivity in general: https:\/\/t.co\/VtiKbGH0lG is awesome!",
  "id" : 821735672792879104,
  "in_reply_to_status_id" : 821734905549901824,
  "created_at" : "2017-01-18 15:07:06 +0000",
  "in_reply_to_screen_name" : "Incidentallyb",
  "in_reply_to_user_id_str" : "415147067",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Incidentally Bentley",
      "screen_name" : "Incidentallyb",
      "indices" : [ 0, 14 ],
      "id_str" : "415147067",
      "id" : 415147067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/vCVgx2fCTK",
      "expanded_url" : "https:\/\/events.ccc.de\/camp\/2015\/wiki\/Village:Queer_Feminist_Geeks",
      "display_url" : "events.ccc.de\/camp\/2015\/wiki\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "821734905549901824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237314580178, 8.627512375841834 ]
  },
  "id_str" : "821735341992316928",
  "in_reply_to_user_id" : 415147067,
  "text" : "@Incidentallyb ah, got it! Here\u2019s the wiki page of our village at this camp: https:\/\/t.co\/vCVgx2fCTK",
  "id" : 821735341992316928,
  "in_reply_to_status_id" : 821734905549901824,
  "created_at" : "2017-01-18 15:05:47 +0000",
  "in_reply_to_screen_name" : "Incidentallyb",
  "in_reply_to_user_id_str" : "415147067",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/1wGAxEmH3q",
      "expanded_url" : "https:\/\/twitter.com\/Impactstory\/status\/821483158637920256",
      "display_url" : "twitter.com\/Impactstory\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06100144372638, 8.818750559137177 ]
  },
  "id_str" : "821484187559559169",
  "text" : "One of the best feelings you can get in #opensource: find bug, fix bug &amp; get the fix merged in a single day! \uD83C\uDF89 https:\/\/t.co\/1wGAxEmH3q",
  "id" : 821484187559559169,
  "created_at" : "2017-01-17 22:27:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821480601895243776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06110074772242, 8.818786054375625 ]
  },
  "id_str" : "821480740084969476",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante thanks! \uD83D\uDC4D",
  "id" : 821480740084969476,
  "in_reply_to_status_id" : 821480601895243776,
  "created_at" : "2017-01-17 22:14:05 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821479905280008196",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06110074772242, 8.818786054375625 ]
  },
  "id_str" : "821480248718004225",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante the last word should be \u201EBiphobia\u201C",
  "id" : 821480248718004225,
  "in_reply_to_status_id" : 821479905280008196,
  "created_at" : "2017-01-17 22:12:08 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821376984357937152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10190967710059, 8.747368735647372 ]
  },
  "id_str" : "821413223475904513",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek oh, all the best. Hope you can curl up with a blanket and tea!",
  "id" : 821413223475904513,
  "in_reply_to_status_id" : 821376984357937152,
  "created_at" : "2017-01-17 17:45:48 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDF41Cal-LEAF Monster\uD83C\uDF42",
      "screen_name" : "piranhaplant",
      "indices" : [ 3, 16 ],
      "id_str" : "81969615",
      "id" : 81969615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/piranhaplant\/status\/821178176252411904\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/pZSgtSV5kW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C2VpMeVVEAA8dcD.jpg",
      "id_str" : "821178170086854656",
      "id" : 821178170086854656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2VpMeVVEAA8dcD.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 349
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 492
      } ],
      "display_url" : "pic.twitter.com\/pZSgtSV5kW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821410032105431041",
  "text" : "RT @piranhaplant: It would seem obvious, and now I kinda feel like an ass for not putting two and two together. https:\/\/t.co\/pZSgtSV5kW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/piranhaplant\/status\/821178176252411904\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/pZSgtSV5kW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C2VpMeVVEAA8dcD.jpg",
        "id_str" : "821178170086854656",
        "id" : 821178170086854656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2VpMeVVEAA8dcD.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 349
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 492
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 492
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 492
        } ],
        "display_url" : "pic.twitter.com\/pZSgtSV5kW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "821178176252411904",
    "text" : "It would seem obvious, and now I kinda feel like an ass for not putting two and two together. https:\/\/t.co\/pZSgtSV5kW",
    "id" : 821178176252411904,
    "created_at" : "2017-01-17 02:11:48 +0000",
    "user" : {
      "name" : "\uD83C\uDF41Cal-LEAF Monster\uD83C\uDF42",
      "screen_name" : "piranhaplant",
      "protected" : false,
      "id_str" : "81969615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920851082565238784\/YoYj6H_n_normal.jpg",
      "id" : 81969615,
      "verified" : false
    }
  },
  "id" : 821410032105431041,
  "created_at" : "2017-01-17 17:33:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ju5oD6kDrN",
      "expanded_url" : "https:\/\/twitter.com\/marcelsalathe\/status\/821354839422681088",
      "display_url" : "twitter.com\/marcelsalathe\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235173235294, 8.627559707232766 ]
  },
  "id_str" : "821356011055443968",
  "text" : "Wish I could make it for that, but if you\u2019re free on that dates: give it a chance! https:\/\/t.co\/ju5oD6kDrN",
  "id" : 821356011055443968,
  "created_at" : "2017-01-17 13:58:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821310377380184064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235895276402, 8.627537005972842 ]
  },
  "id_str" : "821341503486394369",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H looks like it is exactly as community driven as one had feared? o_O",
  "id" : 821341503486394369,
  "in_reply_to_status_id" : 821310377380184064,
  "created_at" : "2017-01-17 13:00:48 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Impactstory",
      "screen_name" : "Impactstory",
      "indices" : [ 35, 47 ],
      "id_str" : "375668090",
      "id" : 375668090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/5NcSAJb2c2",
      "expanded_url" : "https:\/\/github.com\/Impactstory\/impactstory-tng\/pull\/13",
      "display_url" : "github.com\/Impactstory\/im\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238418444781, 8.627486290889127 ]
  },
  "id_str" : "821339409056485376",
  "text" : "Yay for Open Source: Doing a PR to @Impactstory \uD83C\uDF89 https:\/\/t.co\/5NcSAJb2c2",
  "id" : 821339409056485376,
  "created_at" : "2017-01-17 12:52:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821335104899387393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239039552704, 8.627479902279275 ]
  },
  "id_str" : "821335298739240960",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute let me check flights? :D",
  "id" : 821335298739240960,
  "in_reply_to_status_id" : 821335104899387393,
  "created_at" : "2017-01-17 12:36:09 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821313581727813632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237265419813, 8.627541795295953 ]
  },
  "id_str" : "821334526676832257",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute omg, that\u2019s awesome!",
  "id" : 821334526676832257,
  "in_reply_to_status_id" : 821313581727813632,
  "created_at" : "2017-01-17 12:33:05 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821109232854384640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091057075351, 8.818643626321636 ]
  },
  "id_str" : "821124815734132737",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson is this the American politics version of genome assembly? Do a sad one!",
  "id" : 821124815734132737,
  "in_reply_to_status_id" : 821109232854384640,
  "created_at" : "2017-01-16 22:39:46 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freeze Frame Bot",
      "screen_name" : "freezeframebot",
      "indices" : [ 7, 22 ],
      "id_str" : "797697560404250629",
      "id" : 797697560404250629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/haMIuFTXet",
      "expanded_url" : "https:\/\/twitter.com\/CuteBabyAnimals\/status\/821078699923554304",
      "display_url" : "twitter.com\/CuteBabyAnimal\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092809145344, 8.818628573798405 ]
  },
  "id_str" : "821108845128904710",
  "text" : "Please @freezeframebot, you know what to do. https:\/\/t.co\/haMIuFTXet",
  "id" : 821108845128904710,
  "created_at" : "2017-01-16 21:36:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karolina Heyduk",
      "screen_name" : "kheyduk",
      "indices" : [ 3, 11 ],
      "id_str" : "934980678",
      "id" : 934980678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821068445710254082",
  "text" : "RT @kheyduk: Gender balance update: comparative genomics, 5:1 m:f. Not pointing this out to be obnoxious, pointing it out because it matter\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PAGXXV",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "820680660088037377",
    "text" : "Gender balance update: comparative genomics, 5:1 m:f. Not pointing this out to be obnoxious, pointing it out because it matters. #PAGXXV",
    "id" : 820680660088037377,
    "created_at" : "2017-01-15 17:14:51 +0000",
    "user" : {
      "name" : "Karolina Heyduk",
      "screen_name" : "kheyduk",
      "protected" : false,
      "id_str" : "934980678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/804510351798767616\/hwJdSZVl_normal.jpg",
      "id" : 934980678,
      "verified" : false
    }
  },
  "id" : 821068445710254082,
  "created_at" : "2017-01-16 18:55:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Kelly",
      "screen_name" : "TyLKelly",
      "indices" : [ 0, 9 ],
      "id_str" : "38707602",
      "id" : 38707602
    }, {
      "name" : "Grant Denkinson",
      "screen_name" : "GrantDenkinson",
      "indices" : [ 10, 25 ],
      "id_str" : "632724520",
      "id" : 632724520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821024619608109056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10192936827234, 8.689063975257776 ]
  },
  "id_str" : "821028055980408833",
  "in_reply_to_user_id" : 38707602,
  "text" : "@TyLKelly @GrantDenkinson could be the first spectator sport to captivate me.",
  "id" : 821028055980408833,
  "in_reply_to_status_id" : 821024619608109056,
  "created_at" : "2017-01-16 16:15:17 +0000",
  "in_reply_to_screen_name" : "TyLKelly",
  "in_reply_to_user_id_str" : "38707602",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 3, 12 ],
      "id_str" : "575961466",
      "id" : 575961466
    }, {
      "name" : "Tom MacWright",
      "screen_name" : "tmcw",
      "indices" : [ 31, 36 ],
      "id_str" : "1458271",
      "id" : 1458271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/NtImNoH6GM",
      "expanded_url" : "http:\/\/www.macwright.org\/2016\/09\/26\/the-180th-meridian.html",
      "display_url" : "macwright.org\/2016\/09\/26\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821003186160943105",
  "text" : "RT @leejoeyk: An A+ article by @tmcw on geojson and crossing the 180th meridian https:\/\/t.co\/NtImNoH6GM + extra points for skateboard refer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom MacWright",
        "screen_name" : "tmcw",
        "indices" : [ 17, 22 ],
        "id_str" : "1458271",
        "id" : 1458271
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/leejoeyk\/status\/821001977169645568\/photo\/1",
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/DsbOyY3Ctj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C2TI3LZXcAA_uik.jpg",
        "id_str" : "821001882365816832",
        "id" : 821001882365816832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2TI3LZXcAA_uik.jpg",
        "sizes" : [ {
          "h" : 575,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1184,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1015,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1184,
          "resize" : "fit",
          "w" : 1400
        } ],
        "display_url" : "pic.twitter.com\/DsbOyY3Ctj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/NtImNoH6GM",
        "expanded_url" : "http:\/\/www.macwright.org\/2016\/09\/26\/the-180th-meridian.html",
        "display_url" : "macwright.org\/2016\/09\/26\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "821001977169645568",
    "text" : "An A+ article by @tmcw on geojson and crossing the 180th meridian https:\/\/t.co\/NtImNoH6GM + extra points for skateboard reference https:\/\/t.co\/DsbOyY3Ctj",
    "id" : 821001977169645568,
    "created_at" : "2017-01-16 14:31:39 +0000",
    "user" : {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "protected" : false,
      "id_str" : "575961466",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785586576336314368\/YnALwDUc_normal.jpg",
      "id" : 575961466,
      "verified" : false
    }
  },
  "id" : 821003186160943105,
  "created_at" : "2017-01-16 14:36:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 49, 63 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badomics",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/tNBApoaac2",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.2001402",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238343870254, 8.627454614439637 ]
  },
  "id_str" : "820994179429965824",
  "text" : "The \u00ABphysiome\u00BB must be a measure for how quickly @phylogenomics wants to run away from that #badomics term\u2026 https:\/\/t.co\/tNBApoaac2",
  "id" : 820994179429965824,
  "created_at" : "2017-01-16 14:00:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820991029914509313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238343870254, 8.627454614439637 ]
  },
  "id_str" : "820993653833400320",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB damn, all I regularly carry around is a spork, so I can eat ice cream wherever I go.",
  "id" : 820993653833400320,
  "in_reply_to_status_id" : 820991029914509313,
  "created_at" : "2017-01-16 13:58:35 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820990256006787072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240363581949, 8.627419126809535 ]
  },
  "id_str" : "820990507702767617",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB otoh this will just lead to an epic battle between us over the total loot.",
  "id" : 820990507702767617,
  "in_reply_to_status_id" : 820990256006787072,
  "created_at" : "2017-01-16 13:46:04 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820989803512598528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240363581949, 8.627419126809535 ]
  },
  "id_str" : "820990196992933888",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB or gang up in find people willing to involuntarily share.",
  "id" : 820990196992933888,
  "in_reply_to_status_id" : 820989803512598528,
  "created_at" : "2017-01-16 13:44:50 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820989161444438016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723986357262, 8.627432421301108 ]
  },
  "id_str" : "820989516085338113",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB I don\u2019t even share other ppl\u2019s dessert. Usually ends in fist fights when meeting relatable people.",
  "id" : 820989516085338113,
  "in_reply_to_status_id" : 820989161444438016,
  "created_at" : "2017-01-16 13:42:08 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lotterleben",
      "screen_name" : "Lotterleben",
      "indices" : [ 0, 12 ],
      "id_str" : "42195587",
      "id" : 42195587
    }, {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 13, 21 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820988529744416768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723986357262, 8.627432421301108 ]
  },
  "id_str" : "820989241085804544",
  "in_reply_to_user_id" : 42195587,
  "text" : "@Lotterleben @pulegon gerne. \uD83D\uDE0A",
  "id" : 820989241085804544,
  "in_reply_to_status_id" : 820988529744416768,
  "created_at" : "2017-01-16 13:41:02 +0000",
  "in_reply_to_screen_name" : "Lotterleben",
  "in_reply_to_user_id_str" : "42195587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lotterleben",
      "screen_name" : "Lotterleben",
      "indices" : [ 0, 12 ],
      "id_str" : "42195587",
      "id" : 42195587
    }, {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 13, 21 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820983187501412352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227288655588, 8.62740362523751 ]
  },
  "id_str" : "820987614220156930",
  "in_reply_to_user_id" : 42195587,
  "text" : "@Lotterleben @pulegon leider nur: nicht LaTeX nutzen, f\u00FCr was anderes als WoT ist es nicht so super zu gebrauchen. Siehe: LaTeX Beamer.",
  "id" : 820987614220156930,
  "in_reply_to_status_id" : 820983187501412352,
  "created_at" : "2017-01-16 13:34:35 +0000",
  "in_reply_to_screen_name" : "Lotterleben",
  "in_reply_to_user_id_str" : "42195587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Kelly",
      "screen_name" : "TyLKelly",
      "indices" : [ 0, 9 ],
      "id_str" : "38707602",
      "id" : 38707602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820978077685678080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17263252650853, 8.627433221957443 ]
  },
  "id_str" : "820978798871085056",
  "in_reply_to_user_id" : 38707602,
  "text" : "@TyLKelly sounds like my attempts to make an omelette! \uD83E\uDD5E",
  "id" : 820978798871085056,
  "in_reply_to_status_id" : 820978077685678080,
  "created_at" : "2017-01-16 12:59:33 +0000",
  "in_reply_to_screen_name" : "TyLKelly",
  "in_reply_to_user_id_str" : "38707602",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Kelly",
      "screen_name" : "TyLKelly",
      "indices" : [ 0, 9 ],
      "id_str" : "38707602",
      "id" : 38707602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820618005054914560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16381064290915, 8.638464463091676 ]
  },
  "id_str" : "820974414577696768",
  "in_reply_to_user_id" : 38707602,
  "text" : "@TyLKelly did they end up highly dimensional? :D",
  "id" : 820974414577696768,
  "in_reply_to_status_id" : 820618005054914560,
  "created_at" : "2017-01-16 12:42:08 +0000",
  "in_reply_to_screen_name" : "TyLKelly",
  "in_reply_to_user_id_str" : "38707602",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.25853413962598, 8.49164435841498 ]
  },
  "id_str" : "820953874777468928",
  "text" : "SSH to the cluster is broken since the weekend? Guess that means I\u2019ll have to read another book on my train ride. \uD83E\uDD37\u200D\u2640\uFE0F",
  "id" : 820953874777468928,
  "created_at" : "2017-01-16 11:20:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/oiHwldWODI",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BPUcx3eB-aP\/",
      "display_url" : "instagram.com\/p\/BPUcx3eB-aP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "820919387460767744",
  "text" : "Officebound \uD83D\uDE8A\uD83C\uDF28 https:\/\/t.co\/oiHwldWODI",
  "id" : 820919387460767744,
  "created_at" : "2017-01-16 09:03:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/820687460510343168\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/TXvbzXPuG7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C2Oq5TiWIAIDqeM.jpg",
      "id_str" : "820687458585157634",
      "id" : 820687458585157634,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2Oq5TiWIAIDqeM.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TXvbzXPuG7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820687460510343168",
  "text" : "When you exit the tram at the 'City Hall' stop in Sheffield, this is what you see. \uD83C\uDDEA\uD83C\uDDFA\uD83E\uDD37\u200D\u2640\uFE0F https:\/\/t.co\/TXvbzXPuG7",
  "id" : 820687460510343168,
  "created_at" : "2017-01-15 17:41:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820674097021652993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.36235113161156, -2.272265638034914 ]
  },
  "id_str" : "820675985695707137",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField don\u2019t wanna make it too easy! \uD83D\uDE02",
  "id" : 820675985695707137,
  "in_reply_to_status_id" : 820674097021652993,
  "created_at" : "2017-01-15 16:56:17 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#\u042Febel",
      "screen_name" : "Jamelia",
      "indices" : [ 3, 11 ],
      "id_str" : "60059126",
      "id" : 60059126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820675067617099780",
  "text" : "RT @Jamelia: I've had so many questions asked &amp; I wanted to say this, and only this in regard to what happened to us on Thursday\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/YbkHX0UCSU",
        "expanded_url" : "https:\/\/www.jamelia.com\/new-blog\/2017\/1\/14\/first-class-racism",
        "display_url" : "jamelia.com\/new-blog\/2017\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "820267092528209921",
    "text" : "I've had so many questions asked &amp; I wanted to say this, and only this in regard to what happened to us on Thursday\nhttps:\/\/t.co\/YbkHX0UCSU",
    "id" : 820267092528209921,
    "created_at" : "2017-01-14 13:51:29 +0000",
    "user" : {
      "name" : "#\u042Febel",
      "screen_name" : "Jamelia",
      "protected" : false,
      "id_str" : "60059126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870935084010012672\/jrwuhsqo_normal.jpg",
      "id" : 60059126,
      "verified" : true
    }
  },
  "id" : 820675067617099780,
  "created_at" : "2017-01-15 16:52:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 37, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/2az39AI1A9",
      "expanded_url" : "https:\/\/twitter.com\/WilliamShatner\/status\/820661225776218112",
      "display_url" : "twitter.com\/WilliamShatner\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.36246767036923, -2.273018705633372 ]
  },
  "id_str" : "820673280256475136",
  "text" : "Getting Cpt. Kirk to tweet about the #LGBTSTEMinar17 \u2705 https:\/\/t.co\/2az39AI1A9",
  "id" : 820673280256475136,
  "created_at" : "2017-01-15 16:45:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Shatner",
      "screen_name" : "WilliamShatner",
      "indices" : [ 3, 18 ],
      "id_str" : "15227791",
      "id" : 15227791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/xH9Yr1dN1S",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/819904225316663296",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "820661743936475136",
  "text" : "RT @WilliamShatner: That's a pretty sad example of a Wh-question. They should have used Dr. Who! \uD83D\uDE0F\uD83D\uDE1D https:\/\/t.co\/xH9Yr1dN1S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/xH9Yr1dN1S",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/819904225316663296",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "820661225776218112",
    "text" : "That's a pretty sad example of a Wh-question. They should have used Dr. Who! \uD83D\uDE0F\uD83D\uDE1D https:\/\/t.co\/xH9Yr1dN1S",
    "id" : 820661225776218112,
    "created_at" : "2017-01-15 15:57:38 +0000",
    "user" : {
      "name" : "William Shatner",
      "screen_name" : "WilliamShatner",
      "protected" : false,
      "id_str" : "15227791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925609233126604800\/qAZK1Wrg_normal.jpg",
      "id" : 15227791,
      "verified" : true
    }
  },
  "id" : 820661743936475136,
  "created_at" : "2017-01-15 15:59:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/Obp67vFopK",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BPSlE0KBElN\/",
      "display_url" : "instagram.com\/p\/BPSlE0KBElN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.3894757388, -1.47211329927 ]
  },
  "id_str" : "820656161850392577",
  "text" : "River Don Engine @ Kelham Island Museum https:\/\/t.co\/Obp67vFopK",
  "id" : 820656161850392577,
  "created_at" : "2017-01-15 15:37:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 3, 17 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Gates Foundation",
      "screen_name" : "gatesfoundation",
      "indices" : [ 64, 80 ],
      "id_str" : "17899109",
      "id" : 17899109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/LRoSC9mNsT",
      "expanded_url" : "https:\/\/twitter.com\/BrianNosek\/status\/820097849379721218",
      "display_url" : "twitter.com\/BrianNosek\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "820568799296581633",
  "text" : "RT @CameronNeylon: Someone blinks. And on past form it won't be @gatesfoundation https:\/\/t.co\/LRoSC9mNsT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gates Foundation",
        "screen_name" : "gatesfoundation",
        "indices" : [ 45, 61 ],
        "id_str" : "17899109",
        "id" : 17899109
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/LRoSC9mNsT",
        "expanded_url" : "https:\/\/twitter.com\/BrianNosek\/status\/820097849379721218",
        "display_url" : "twitter.com\/BrianNosek\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "820497255140589568",
    "text" : "Someone blinks. And on past form it won't be @gatesfoundation https:\/\/t.co\/LRoSC9mNsT",
    "id" : 820497255140589568,
    "created_at" : "2017-01-15 05:06:04 +0000",
    "user" : {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "protected" : false,
      "id_str" : "12984852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1766127492\/image1326973990_normal.png",
      "id" : 12984852,
      "verified" : false
    }
  },
  "id" : 820568799296581633,
  "created_at" : "2017-01-15 09:50:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 25, 38 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820380145806622720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.4010216966822, -1.511461508952038 ]
  },
  "id_str" : "820410994094731266",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston please find @PhilippBayer there and go for drinks with him. You\u2019ll both be delighted!",
  "id" : 820410994094731266,
  "in_reply_to_status_id" : 820380145806622720,
  "created_at" : "2017-01-14 23:23:18 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/CX6SNem3pI",
      "expanded_url" : "https:\/\/twitter.com\/boissongazeuse\/status\/819376277425557505",
      "display_url" : "twitter.com\/boissongazeuse\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.40099250203266, -1.511490460761816 ]
  },
  "id_str" : "820393672898449414",
  "text" : "\uD83D\uDC36\u262D https:\/\/t.co\/CX6SNem3pI",
  "id" : 820393672898449414,
  "created_at" : "2017-01-14 22:14:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SocioViz",
      "screen_name" : "SocioVizNet",
      "indices" : [ 0, 12 ],
      "id_str" : "2232759379",
      "id" : 2232759379
    }, {
      "name" : "Simon Lancaster",
      "screen_name" : "S_J_Lancaster",
      "indices" : [ 13, 27 ],
      "id_str" : "240186025",
      "id" : 240186025
    }, {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 28, 43 ],
      "id_str" : "173968705",
      "id" : 173968705
    }, {
      "name" : "Gephi graph viz",
      "screen_name" : "Gephi",
      "indices" : [ 44, 50 ],
      "id_str" : "22749856",
      "id" : 22749856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820392112483160065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.40100354494013, -1.511322882754487 ]
  },
  "id_str" : "820392240048730112",
  "in_reply_to_user_id" : 2232759379,
  "text" : "@SocioVizNet @S_J_Lancaster @professor_dave @Gephi thanks, good idea!",
  "id" : 820392240048730112,
  "in_reply_to_status_id" : 820392112483160065,
  "created_at" : "2017-01-14 22:08:46 +0000",
  "in_reply_to_screen_name" : "SocioVizNet",
  "in_reply_to_user_id_str" : "2232759379",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 0, 15 ],
      "id_str" : "173968705",
      "id" : 173968705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820280525378252801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38169639302625, -1.471162452009371 ]
  },
  "id_str" : "820372835264765954",
  "in_reply_to_user_id" : 173968705,
  "text" : "@professor_dave unfortunately unreadable with that resolution? :(",
  "id" : 820372835264765954,
  "in_reply_to_status_id" : 820280525378252801,
  "created_at" : "2017-01-14 20:51:40 +0000",
  "in_reply_to_screen_name" : "professor_dave",
  "in_reply_to_user_id_str" : "173968705",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 5, 20 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 21, 36 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 51, 65 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/JerRpEURgV",
      "expanded_url" : "https:\/\/flic.kr\/p\/RaqS2A",
      "display_url" : "flic.kr\/p\/RaqS2A"
    } ]
  },
  "geo" : { },
  "id_str" : "820342795370172419",
  "text" : "Mini @MozillaScience\/@MozOpenLeaders reunion. With @annakrystalli in the Peak District. \uD83D\uDE0D\uD83D\uDC96\uD83C\uDFD4\uD83C\uDF04 https:\/\/t.co\/JerRpEURgV",
  "id" : 820342795370172419,
  "created_at" : "2017-01-14 18:52:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergramm",
      "indices" : [ 11, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/N59cW6qxNU",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BPQVlQ9hfbz\/",
      "display_url" : "instagram.com\/p\/BPQVlQ9hfbz\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.31911, -1.61734 ]
  },
  "id_str" : "820340612431892481",
  "text" : "Lunch view #latergramm @ Peak District National Park https:\/\/t.co\/N59cW6qxNU",
  "id" : 820340612431892481,
  "created_at" : "2017-01-14 18:43:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/Cb3RZYXRHF",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BPQQHMnhxbU\/",
      "display_url" : "instagram.com\/p\/BPQQHMnhxbU\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.31911, -1.61734 ]
  },
  "id_str" : "820328585013514241",
  "text" : "out for a hike @ Peak District National Park https:\/\/t.co\/Cb3RZYXRHF",
  "id" : 820328585013514241,
  "created_at" : "2017-01-14 17:55:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Incidentally Bentley",
      "screen_name" : "Incidentallyb",
      "indices" : [ 0, 14 ],
      "id_str" : "415147067",
      "id" : 415147067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820306653690101760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.32936703698088, -1.515063950793366 ]
  },
  "id_str" : "820315722773565440",
  "in_reply_to_user_id" : 415147067,
  "text" : "@Incidentallyb what exactly do you mean? :-)",
  "id" : 820315722773565440,
  "in_reply_to_status_id" : 820306653690101760,
  "created_at" : "2017-01-14 17:04:43 +0000",
  "in_reply_to_screen_name" : "Incidentallyb",
  "in_reply_to_user_id_str" : "415147067",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Charlesworth",
      "screen_name" : "janepipistrelle",
      "indices" : [ 0, 16 ],
      "id_str" : "328098087",
      "id" : 328098087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820229940914360320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.37811738546073, -1.463227489034522 ]
  },
  "id_str" : "820231028967084032",
  "in_reply_to_user_id" : 328098087,
  "text" : "@janepipistrelle thanks! Maybe in the Netherlands this year? And are you a SMBE person?",
  "id" : 820231028967084032,
  "in_reply_to_status_id" : 820229940914360320,
  "created_at" : "2017-01-14 11:28:11 +0000",
  "in_reply_to_screen_name" : "janepipistrelle",
  "in_reply_to_user_id_str" : "328098087",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    }, {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 16, 24 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820225336826851328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.40097325858977, -1.498253205792511 ]
  },
  "id_str" : "820225753581309952",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField @PhdGeek thanks for inviting me to share my story!",
  "id" : 820225753581309952,
  "in_reply_to_status_id" : 820225336826851328,
  "created_at" : "2017-01-14 11:07:13 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 67, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820225082454867968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.40165965264048, -1.50386237539491 ]
  },
  "id_str" : "820225408968904704",
  "in_reply_to_user_id" : 14286491,
  "text" : "My \u201Clist of best events I ever went to\u201D did grow by one yesterday. #LGBTSTEMinar17 \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83D\uDC96\uD83D\uDE0D",
  "id" : 820225408968904704,
  "in_reply_to_status_id" : 820225082454867968,
  "created_at" : "2017-01-14 11:05:51 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 7, 15 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 17, 32 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 59, 74 ]
    }, {
      "text" : "LGBTSTEMinar18",
      "indices" : [ 126, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.40103243482616, -1.506410138682934 ]
  },
  "id_str" : "820225082454867968",
  "text" : "Thanks @PhdGeek, @TheLabAndField &amp; all others who made #LGBTSTEMinar17 such a great event &amp; community. Can\u2019t wait for #LGBTSTEMinar18 \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
  "id" : 820225082454867968,
  "created_at" : "2017-01-14 11:04:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    }, {
      "name" : "Anna MacDonald",
      "screen_name" : "Dr_AnnaM",
      "indices" : [ 13, 22 ],
      "id_str" : "842669612",
      "id" : 842669612
    }, {
      "name" : "BES",
      "screen_name" : "BritishEcolSoc",
      "indices" : [ 23, 38 ],
      "id_str" : "273984889",
      "id" : 273984889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820214807274147840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.40058981655662, -1.508260204386222 ]
  },
  "id_str" : "820223157231616000",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay @Dr_AnnaM @BritishEcolSoc awesome! :)",
  "id" : 820223157231616000,
  "in_reply_to_status_id" : 820214807274147840,
  "created_at" : "2017-01-14 10:56:54 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 13, 28 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820046861578936321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.4010130859965, -1.51147032024458 ]
  },
  "id_str" : "820213368522964992",
  "in_reply_to_user_id" : 902495767,
  "text" : "@VerenaGortz @TheLabAndField if I knew where I\u2019d be located in 2018 I\u2019d do it right away.",
  "id" : 820213368522964992,
  "in_reply_to_status_id" : 820046861578936321,
  "created_at" : "2017-01-14 10:18:00 +0000",
  "in_reply_to_screen_name" : "DrV_So",
  "in_reply_to_user_id_str" : "902495767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna MacDonald",
      "screen_name" : "Dr_AnnaM",
      "indices" : [ 0, 9 ],
      "id_str" : "842669612",
      "id" : 842669612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820119153985978368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.40099754493976, -1.511492148372757 ]
  },
  "id_str" : "820213220044664832",
  "in_reply_to_user_id" : 842669612,
  "text" : "@Dr_AnnaM totally :D",
  "id" : 820213220044664832,
  "in_reply_to_status_id" : 820119153985978368,
  "created_at" : "2017-01-14 10:17:25 +0000",
  "in_reply_to_screen_name" : "Dr_AnnaM",
  "in_reply_to_user_id_str" : "842669612",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Charlon",
      "screen_name" : "ThChln",
      "indices" : [ 0, 7 ],
      "id_str" : "1099253149",
      "id" : 1099253149
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 21, 34 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 39, 51 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820068509661220870",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.40100320766285, -1.511488101923183 ]
  },
  "id_str" : "820213132018728960",
  "in_reply_to_user_id" : 1099253149,
  "text" : "@ThChln great, maybe @PhilippBayer and @helgerausch also want to have a look. Will be back at a computer on Monday. :)",
  "id" : 820213132018728960,
  "in_reply_to_status_id" : 820068509661220870,
  "created_at" : "2017-01-14 10:17:04 +0000",
  "in_reply_to_screen_name" : "ThChln",
  "in_reply_to_user_id_str" : "1099253149",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elena Long",
      "screen_name" : "Elena_Long",
      "indices" : [ 0, 11 ],
      "id_str" : "90678527",
      "id" : 90678527
    }, {
      "name" : "Dr Alfredo Carpineti",
      "screen_name" : "DrCarpineti",
      "indices" : [ 12, 24 ],
      "id_str" : "19183987",
      "id" : 19183987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819961655081758720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38197202933258, -1.485312915469214 ]
  },
  "id_str" : "819969109471461377",
  "in_reply_to_user_id" : 90678527,
  "text" : "@Elena_Long @DrCarpineti that\u2019s terrible. Thanks for sharing the numbers!",
  "id" : 819969109471461377,
  "in_reply_to_status_id" : 819961655081758720,
  "created_at" : "2017-01-13 18:07:24 +0000",
  "in_reply_to_screen_name" : "Elena_Long",
  "in_reply_to_user_id_str" : "90678527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elena Long",
      "screen_name" : "Elena_Long",
      "indices" : [ 3, 14 ],
      "id_str" : "90678527",
      "id" : 90678527
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 16, 32 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Dr Alfredo Carpineti",
      "screen_name" : "DrCarpineti",
      "indices" : [ 33, 45 ],
      "id_str" : "19183987",
      "id" : 19183987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819969032711524353",
  "text" : "RT @Elena_Long: @gedankenstuecke @DrCarpineti And yet, over 40% of LGBT physicists are expected to \"not act too gay\" :-( https:\/\/t.co\/LkbYH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Dr Alfredo Carpineti",
        "screen_name" : "DrCarpineti",
        "indices" : [ 17, 29 ],
        "id_str" : "19183987",
        "id" : 19183987
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elena_Long\/status\/819961655081758720\/photo\/1",
        "indices" : [ 129, 152 ],
        "url" : "https:\/\/t.co\/2rENRBvpeA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C2EWwkkXcAEs5mR.jpg",
        "id_str" : "819961630863880193",
        "id" : 819961630863880193,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2EWwkkXcAEs5mR.jpg",
        "sizes" : [ {
          "h" : 1440,
          "resize" : "fit",
          "w" : 2253
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1309,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/2rENRBvpeA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/LkbYHjwLNq",
        "expanded_url" : "http:\/\/www.aps.org\/programs\/lgbt\/",
        "display_url" : "aps.org\/programs\/lgbt\/"
      } ]
    },
    "in_reply_to_status_id_str" : "819940716843503617",
    "geo" : { },
    "id_str" : "819961655081758720",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke @DrCarpineti And yet, over 40% of LGBT physicists are expected to \"not act too gay\" :-( https:\/\/t.co\/LkbYHjwLNq https:\/\/t.co\/2rENRBvpeA",
    "id" : 819961655081758720,
    "in_reply_to_status_id" : 819940716843503617,
    "created_at" : "2017-01-13 17:37:47 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Elena Long",
      "screen_name" : "Elena_Long",
      "protected" : false,
      "id_str" : "90678527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803642168732684288\/A0VLPoT0_normal.jpg",
      "id" : 90678527,
      "verified" : false
    }
  },
  "id" : 819969032711524353,
  "created_at" : "2017-01-13 18:07:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 107, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38205527214245, -1.485425005894841 ]
  },
  "id_str" : "819942054520352768",
  "text" : "\u00ABWe\u2019re physicists, so we\u2019re more in the S&amp;M than in the T&amp;E.\u00BB flog me with some equations already. #LGBTSTEMinar17",
  "id" : 819942054520352768,
  "created_at" : "2017-01-13 16:19:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Alfredo Carpineti",
      "screen_name" : "DrCarpineti",
      "indices" : [ 97, 109 ],
      "id_str" : "19183987",
      "id" : 19183987
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38205053748609, -1.485455670593762 ]
  },
  "id_str" : "819940716843503617",
  "text" : "\u00ABPeople who are really really gay might also like galaxy collisions.\u00BB People contain multitudes. @DrCarpineti #LGBTSTEMinar17 \uD83C\uDF0C \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
  "id" : 819940716843503617,
  "created_at" : "2017-01-13 16:14:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jost",
      "screen_name" : "JostMigenda",
      "indices" : [ 74, 86 ],
      "id_str" : "3808730194",
      "id" : 3808730194
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/NVJSAa8Mha",
      "expanded_url" : "https:\/\/twitter.com\/Ashley_Nova_\/status\/819930366274338816",
      "display_url" : "twitter.com\/Ashley_Nova_\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38200807465115, -1.485465919276218 ]
  },
  "id_str" : "819931606064496641",
  "text" : "\u00ABThe easiest part about neutrino oscillations is the name of the matrix.\u00BB @JostMigenda at #LGBTSTEMinar17 https:\/\/t.co\/NVJSAa8Mha",
  "id" : 819931606064496641,
  "created_at" : "2017-01-13 15:38:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 40, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/FnPgAxwJx6",
      "expanded_url" : "https:\/\/twitter.com\/WelFreya\/status\/819914317491486720",
      "display_url" : "twitter.com\/WelFreya\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38205405918993, -1.485432966168329 ]
  },
  "id_str" : "819930851278548993",
  "text" : "That\u2019s what they meant by LGBT in STEM! #LGBTSTEMinar17 https:\/\/t.co\/FnPgAxwJx6",
  "id" : 819930851278548993,
  "created_at" : "2017-01-13 15:35:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Kelly",
      "screen_name" : "TyLKelly",
      "indices" : [ 98, 107 ],
      "id_str" : "38707602",
      "id" : 38707602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38206046056546, -1.485454520228158 ]
  },
  "id_str" : "819914041455943680",
  "text" : "\u00ABYou fold this over here and that over there and you\u2019re done. And now you do it in 6 dimensions.\u00BB @TyLKelly at #LGBTSTEMinar17",
  "id" : 819914041455943680,
  "created_at" : "2017-01-13 14:28:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "Dr Alfredo Carpineti",
      "screen_name" : "DrCarpineti",
      "indices" : [ 9, 21 ],
      "id_str" : "19183987",
      "id" : 19183987
    }, {
      "name" : "Dr Dominic Galliano",
      "screen_name" : "PhysicsDom",
      "indices" : [ 22, 33 ],
      "id_str" : "102300277",
      "id" : 102300277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819880062250061824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38206261754823, -1.485431310544737 ]
  },
  "id_str" : "819910524628586498",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek @DrCarpineti @PhysicsDom I totally want to see that!",
  "id" : 819910524628586498,
  "in_reply_to_status_id" : 819880062250061824,
  "created_at" : "2017-01-13 14:14:36 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robyn Orfitelli",
      "screen_name" : "rorfitelli",
      "indices" : [ 0, 11 ],
      "id_str" : "2249903454",
      "id" : 2249903454
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819885167506554881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38208052386192, -1.48542298649657 ]
  },
  "id_str" : "819907972654624769",
  "in_reply_to_user_id" : 2249903454,
  "text" : "@rorfitelli as we didn\u2019t have time for more Qs: what are the other two words like seem? \uD83D\uDE42 #LGBTSTEMinar17",
  "id" : 819907972654624769,
  "in_reply_to_status_id" : 819885167506554881,
  "created_at" : "2017-01-13 14:04:28 +0000",
  "in_reply_to_screen_name" : "rorfitelli",
  "in_reply_to_user_id_str" : "2249903454",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819903491133079556",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38204993094099, -1.485469029730334 ]
  },
  "id_str" : "819904362684289025",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb thanks. Still think about writing it up and publishing it.",
  "id" : 819904362684289025,
  "in_reply_to_status_id" : 819903491133079556,
  "created_at" : "2017-01-13 13:50:07 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Shatner",
      "screen_name" : "WilliamShatner",
      "indices" : [ 74, 89 ],
      "id_str" : "15227791",
      "id" : 15227791
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/819904225316663296\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/UPg8dgEOu1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C2DiifXXAAAyCa7.jpg",
      "id_str" : "819904214344335360",
      "id" : 819904214344335360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2DiifXXAAAyCa7.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UPg8dgEOu1"
    } ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38204066525924, -1.485456247810547 ]
  },
  "id_str" : "819904225316663296",
  "text" : "Let\u2019s explain linguistics using the original slash fiction: Mr. Spock and @WilliamShatner #LGBTSTEMinar17 https:\/\/t.co\/UPg8dgEOu1",
  "id" : 819904225316663296,
  "created_at" : "2017-01-13 13:49:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Denkinson",
      "screen_name" : "GrantDenkinson",
      "indices" : [ 0, 15 ],
      "id_str" : "632724520",
      "id" : 632724520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819887801227415554",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38206698885505, -1.485421667564263 ]
  },
  "id_str" : "819903158797340676",
  "in_reply_to_user_id" : 632724520,
  "text" : "@GrantDenkinson totally should stay in touch about it!",
  "id" : 819903158797340676,
  "in_reply_to_status_id" : 819887801227415554,
  "created_at" : "2017-01-13 13:45:20 +0000",
  "in_reply_to_screen_name" : "GrantDenkinson",
  "in_reply_to_user_id_str" : "632724520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819902500493033475",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38206052970598, -1.485437479040323 ]
  },
  "id_str" : "819902886188634112",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb all the best!",
  "id" : 819902886188634112,
  "in_reply_to_status_id" : 819902500493033475,
  "created_at" : "2017-01-13 13:44:15 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/819902800872296449\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/EhonOjnKvr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C2DhPf5XgAEn6t8.jpg",
      "id_str" : "819902788557832193",
      "id" : 819902788557832193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2DhPf5XgAEn6t8.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/EhonOjnKvr"
    } ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 37, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38205161075683, -1.48544452290339 ]
  },
  "id_str" : "819902800872296449",
  "text" : "Looking forward to some linguistics! #LGBTSTEMinar17 https:\/\/t.co\/EhonOjnKvr",
  "id" : 819902800872296449,
  "created_at" : "2017-01-13 13:43:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lgbtsteminar17",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38206176177974, -1.485437138816294 ]
  },
  "id_str" : "819884597072850946",
  "text" : "Having published about rabbit poo in the past, I really appreciate this talk on penguin guano. \uD83D\uDC30\uD83D\uDCA9\uD83D\uDC27 #lgbtsteminar17",
  "id" : 819884597072850946,
  "created_at" : "2017-01-13 12:31:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I N T E R L I N K E D",
      "screen_name" : "Ashley_Nova_",
      "indices" : [ 3, 16 ],
      "id_str" : "226934096",
      "id" : 226934096
    }, {
      "name" : "MaNGA Survey",
      "screen_name" : "MaNGASurvey",
      "indices" : [ 51, 63 ],
      "id_str" : "1067938466",
      "id" : 1067938466
    }, {
      "name" : "Sloan Digital Sky Surveys",
      "screen_name" : "sdssurveys",
      "indices" : [ 70, 81 ],
      "id_str" : "1149118862",
      "id" : 1149118862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819879858419486720",
  "text" : "RT @Ashley_Nova_: I forgot to mention however that @MaNGASurvey &amp; @sdssurveys data is publicly accessible! Open access science! #LGBTSTEMin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MaNGA Survey",
        "screen_name" : "MaNGASurvey",
        "indices" : [ 33, 45 ],
        "id_str" : "1067938466",
        "id" : 1067938466
      }, {
        "name" : "Sloan Digital Sky Surveys",
        "screen_name" : "sdssurveys",
        "indices" : [ 52, 63 ],
        "id_str" : "1149118862",
        "id" : 1149118862
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar17",
        "indices" : [ 114, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819879472291807233",
    "text" : "I forgot to mention however that @MaNGASurvey &amp; @sdssurveys data is publicly accessible! Open access science! #LGBTSTEMinar17",
    "id" : 819879472291807233,
    "created_at" : "2017-01-13 12:11:13 +0000",
    "user" : {
      "name" : "I N T E R L I N K E D",
      "screen_name" : "Ashley_Nova_",
      "protected" : false,
      "id_str" : "226934096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/909729880857874433\/zVKp6Kh4_normal.jpg",
      "id" : 226934096,
      "verified" : false
    }
  },
  "id" : 819879858419486720,
  "created_at" : "2017-01-13 12:12:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I N T E R L I N K E D",
      "screen_name" : "Ashley_Nova_",
      "indices" : [ 0, 13 ],
      "id_str" : "226934096",
      "id" : 226934096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819878714766983168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38202593040921, -1.485408880483627 ]
  },
  "id_str" : "819879748394450945",
  "in_reply_to_user_id" : 226934096,
  "text" : "@Ashley_Nova_ well done! \uD83D\uDE0D",
  "id" : 819879748394450945,
  "in_reply_to_status_id" : 819878714766983168,
  "created_at" : "2017-01-13 12:12:19 +0000",
  "in_reply_to_screen_name" : "Ashley_Nova_",
  "in_reply_to_user_id_str" : "226934096",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/819872211980918784\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/drLhT1zrSX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C2DFaWSWIAA5Nxf.jpg",
      "id_str" : "819872188631228416",
      "id" : 819872188631228416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2DFaWSWIAA5Nxf.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/drLhT1zrSX"
    } ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38204563945083, -1.485450618578258 ]
  },
  "id_str" : "819872211980918784",
  "text" : "Yep, totally love my library. #LGBTSTEMinar17 https:\/\/t.co\/drLhT1zrSX",
  "id" : 819872211980918784,
  "created_at" : "2017-01-13 11:42:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James \u300C\u30B8\u30E3\u30E0\u300D Gregory",
      "screen_name" : "jamgregory",
      "indices" : [ 3, 14 ],
      "id_str" : "60264283",
      "id" : 60264283
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 121, 137 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819861759276224513",
  "text" : "RT @jamgregory: A great quote!\n\"The opposite of 'open' isn't 'closed'. The opposite of open is 'broken'.\"\n\nGreat keynote @gedankenstuecke!\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 105, 121 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jamgregory\/status\/819853320282062848\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/tp1wgT2LTF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C2C0PY9W8AAVim8.jpg",
        "id_str" : "819853308672274432",
        "id" : 819853308672274432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2C0PY9W8AAVim8.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/tp1wgT2LTF"
      } ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar17",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819853320282062848",
    "text" : "A great quote!\n\"The opposite of 'open' isn't 'closed'. The opposite of open is 'broken'.\"\n\nGreat keynote @gedankenstuecke!\n#LGBTSTEMinar17 https:\/\/t.co\/tp1wgT2LTF",
    "id" : 819853320282062848,
    "created_at" : "2017-01-13 10:27:18 +0000",
    "user" : {
      "name" : "James \u300C\u30B8\u30E3\u30E0\u300D Gregory",
      "screen_name" : "jamgregory",
      "protected" : false,
      "id_str" : "60264283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748848169513955328\/52A9BN6C_normal.jpg",
      "id" : 60264283,
      "verified" : false
    }
  },
  "id" : 819861759276224513,
  "created_at" : "2017-01-13 11:00:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brynley Pearlstone",
      "screen_name" : "BPearlstone",
      "indices" : [ 3, 15 ],
      "id_str" : "2969564128",
      "id" : 2969564128
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 90, 106 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 107, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819861682113613824",
  "text" : "RT @BPearlstone: I quite like the idea of anti harassment fairies dressed up in sparkles! @gedankenstuecke #LGBTSTEMinar17 https:\/\/t.co\/mgO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 73, 89 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BPearlstone\/status\/819852236155219968\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/mgOX1rmedG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C2CzQMzWIAA8jHi.jpg",
        "id_str" : "819852223077294080",
        "id" : 819852223077294080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2CzQMzWIAA8jHi.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        } ],
        "display_url" : "pic.twitter.com\/mgOX1rmedG"
      } ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar17",
        "indices" : [ 90, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819852236155219968",
    "text" : "I quite like the idea of anti harassment fairies dressed up in sparkles! @gedankenstuecke #LGBTSTEMinar17 https:\/\/t.co\/mgOX1rmedG",
    "id" : 819852236155219968,
    "created_at" : "2017-01-13 10:22:59 +0000",
    "user" : {
      "name" : "Brynley Pearlstone",
      "screen_name" : "BPearlstone",
      "protected" : false,
      "id_str" : "2969564128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820764665336791041\/kqaf-OmI_normal.jpg",
      "id" : 2969564128,
      "verified" : false
    }
  },
  "id" : 819861682113613824,
  "created_at" : "2017-01-13 11:00:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "illucifer",
      "indices" : [ 3, 13 ],
      "id_str" : "342973975",
      "id" : 342973975
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/illucifer\/status\/819851416323948544\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/IkiAe2Dfv3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C2CygJjXEAA4TvS.jpg",
      "id_str" : "819851397571219456",
      "id" : 819851397571219456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2CygJjXEAA4TvS.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/IkiAe2Dfv3"
    } ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819861602564538368",
  "text" : "RT @illucifer: #LGBTSTEMinar17 \n\"Overcoming Insecurity\" https:\/\/t.co\/IkiAe2Dfv3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/illucifer\/status\/819851416323948544\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/IkiAe2Dfv3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C2CygJjXEAA4TvS.jpg",
        "id_str" : "819851397571219456",
        "id" : 819851397571219456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2CygJjXEAA4TvS.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/IkiAe2Dfv3"
      } ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar17",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819851416323948544",
    "text" : "#LGBTSTEMinar17 \n\"Overcoming Insecurity\" https:\/\/t.co\/IkiAe2Dfv3",
    "id" : 819851416323948544,
    "created_at" : "2017-01-13 10:19:44 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "illucifer",
      "protected" : false,
      "id_str" : "342973975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915151792006148096\/s4xOXdxO_normal.jpg",
      "id" : 342973975,
      "verified" : false
    }
  },
  "id" : 819861602564538368,
  "created_at" : "2017-01-13 11:00:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 3, 18 ],
      "id_str" : "173968705",
      "id" : 173968705
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 39, 55 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819861593181876225",
  "text" : "RT @professor_dave: Clear case made by @gedankenstuecke for link between diversity and science that breaks barrriers in new ways. #opendata\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 19, 35 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 110, 119 ]
      }, {
        "text" : "LGBTSTEMinar17",
        "indices" : [ 120, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819850572698423296",
    "text" : "Clear case made by @gedankenstuecke for link between diversity and science that breaks barrriers in new ways. #opendata #LGBTSTEMinar17",
    "id" : 819850572698423296,
    "created_at" : "2017-01-13 10:16:23 +0000",
    "user" : {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "protected" : false,
      "id_str" : "173968705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1817870616\/Dave_twitter_2_normal.JPG",
      "id" : 173968705,
      "verified" : false
    }
  },
  "id" : 819861593181876225,
  "created_at" : "2017-01-13 11:00:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brynley Pearlstone",
      "screen_name" : "BPearlstone",
      "indices" : [ 3, 15 ],
      "id_str" : "2969564128",
      "id" : 2969564128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819861563486208000",
  "text" : "RT @BPearlstone: Bastian Greshake talks about funding is pet project: openly sharing their own genome, and allowing other to share theirs #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BPearlstone\/status\/819849804826210304\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/dDd1QM0rX2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C2CxC66XcAIzLCo.jpg",
        "id_str" : "819849795913347074",
        "id" : 819849795913347074,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2CxC66XcAIzLCo.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1440,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 1440,
          "resize" : "fit",
          "w" : 1080
        } ],
        "display_url" : "pic.twitter.com\/dDd1QM0rX2"
      } ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar17",
        "indices" : [ 121, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819849804826210304",
    "text" : "Bastian Greshake talks about funding is pet project: openly sharing their own genome, and allowing other to share theirs #LGBTSTEMinar17 https:\/\/t.co\/dDd1QM0rX2",
    "id" : 819849804826210304,
    "created_at" : "2017-01-13 10:13:20 +0000",
    "user" : {
      "name" : "Brynley Pearlstone",
      "screen_name" : "BPearlstone",
      "protected" : false,
      "id_str" : "2969564128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820764665336791041\/kqaf-OmI_normal.jpg",
      "id" : 2969564128,
      "verified" : false
    }
  },
  "id" : 819861563486208000,
  "created_at" : "2017-01-13 11:00:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 3, 18 ],
      "id_str" : "173968705",
      "id" : 173968705
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 49, 65 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819861533043916802",
  "text" : "RT @professor_dave: PhD student plenary lecturer @gedankenstuecke explains he actually had to take two days off to attend #LGBTSTEMinar17.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 29, 45 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar17",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819849469244084224",
    "text" : "PhD student plenary lecturer @gedankenstuecke explains he actually had to take two days off to attend #LGBTSTEMinar17.",
    "id" : 819849469244084224,
    "created_at" : "2017-01-13 10:12:00 +0000",
    "user" : {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "protected" : false,
      "id_str" : "173968705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1817870616\/Dave_twitter_2_normal.JPG",
      "id" : 173968705,
      "verified" : false
    }
  },
  "id" : 819861533043916802,
  "created_at" : "2017-01-13 10:59:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brynley Pearlstone",
      "screen_name" : "BPearlstone",
      "indices" : [ 3, 15 ],
      "id_str" : "2969564128",
      "id" : 2969564128
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 120, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819861484385816576",
  "text" : "RT @BPearlstone: Our keynote speaker, Bastian Greshake, talks about science and politics and finding your own community #LGBTSTEMinar17 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BPearlstone\/status\/819846626827182080\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/vuhzqqvDAO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C2CuKB1XUAA9Gh3.jpg",
        "id_str" : "819846619495616512",
        "id" : 819846619495616512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2CuKB1XUAA9Gh3.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        } ],
        "display_url" : "pic.twitter.com\/vuhzqqvDAO"
      } ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar17",
        "indices" : [ 103, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819846626827182080",
    "text" : "Our keynote speaker, Bastian Greshake, talks about science and politics and finding your own community #LGBTSTEMinar17 https:\/\/t.co\/vuhzqqvDAO",
    "id" : 819846626827182080,
    "created_at" : "2017-01-13 10:00:42 +0000",
    "user" : {
      "name" : "Brynley Pearlstone",
      "screen_name" : "BPearlstone",
      "protected" : false,
      "id_str" : "2969564128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820764665336791041\/kqaf-OmI_normal.jpg",
      "id" : 2969564128,
      "verified" : false
    }
  },
  "id" : 819861484385816576,
  "created_at" : "2017-01-13 10:59:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 3, 18 ],
      "id_str" : "173968705",
      "id" : 173968705
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 35, 51 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819861414999425024",
  "text" : "RT @professor_dave: In his plenary @gedankenstuecke talks elegantly on openness - in sexuality, science, publishing, gender, activism and d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 15, 31 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar17",
        "indices" : [ 124, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819844948463910912",
    "text" : "In his plenary @gedankenstuecke talks elegantly on openness - in sexuality, science, publishing, gender, activism and data. #LGBTSTEMinar17",
    "id" : 819844948463910912,
    "created_at" : "2017-01-13 09:54:02 +0000",
    "user" : {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "protected" : false,
      "id_str" : "173968705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1817870616\/Dave_twitter_2_normal.JPG",
      "id" : 173968705,
      "verified" : false
    }
  },
  "id" : 819861414999425024,
  "created_at" : "2017-01-13 10:59:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/819859378299949058\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/hu9xZubwSU",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C2C5tybWQAA4h0r.jpg",
      "id_str" : "819859328463159296",
      "id" : 819859328463159296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C2C5tybWQAA4h0r.jpg",
      "sizes" : [ {
        "h" : 144,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 144,
        "resize" : "crop",
        "w" : 144
      } ],
      "display_url" : "pic.twitter.com\/hu9xZubwSU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/IQg5rZpoei",
      "expanded_url" : "https:\/\/twitter.com\/Ashley_Nova_\/status\/819842226205368320",
      "display_url" : "twitter.com\/Ashley_Nova_\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38204505287437, -1.485431886022933 ]
  },
  "id_str" : "819859378299949058",
  "text" : "Bioinformatics always be like this when working with digital presentations. https:\/\/t.co\/IQg5rZpoei https:\/\/t.co\/hu9xZubwSU",
  "id" : 819859378299949058,
  "created_at" : "2017-01-13 10:51:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frey",
      "screen_name" : "WelFreya",
      "indices" : [ 0, 9 ],
      "id_str" : "1363974692",
      "id" : 1363974692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819852392288108544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38205250264232, -1.485438901155328 ]
  },
  "id_str" : "819857158728777728",
  "in_reply_to_user_id" : 1363974692,
  "text" : "@WelFreya thank you!",
  "id" : 819857158728777728,
  "in_reply_to_status_id" : 819852392288108544,
  "created_at" : "2017-01-13 10:42:33 +0000",
  "in_reply_to_screen_name" : "WelFreya",
  "in_reply_to_user_id_str" : "1363974692",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 0, 15 ],
      "id_str" : "173968705",
      "id" : 173968705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819856013394399232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38202842998607, -1.485483168388232 ]
  },
  "id_str" : "819857056450613252",
  "in_reply_to_user_id" : 173968705,
  "text" : "@professor_dave thanks! \uD83D\uDE0A",
  "id" : 819857056450613252,
  "in_reply_to_status_id" : 819856013394399232,
  "created_at" : "2017-01-13 10:42:09 +0000",
  "in_reply_to_screen_name" : "professor_dave",
  "in_reply_to_user_id_str" : "173968705",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 15, 24 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lgbtsteminar17",
      "indices" : [ 43, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/nzhXTU5PTZ",
      "expanded_url" : "https:\/\/twitter.com\/professor_dave\/status\/819852847642771458",
      "display_url" : "twitter.com\/professor_dave\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.38205765511724, -1.485414578776074 ]
  },
  "id_str" : "819856992567259136",
  "text" : "My introducing @wilbanks at another crowd. #lgbtsteminar17 https:\/\/t.co\/nzhXTU5PTZ",
  "id" : 819856992567259136,
  "created_at" : "2017-01-13 10:41:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/819688729891762177\/photo\/1",
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/i2b4wtHP5R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C2AeixuWQAA-3wy.jpg",
      "id_str" : "819688714993549312",
      "id" : 819688714993549312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2AeixuWQAA-3wy.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/i2b4wtHP5R"
    } ],
    "hashtags" : [ {
      "text" : "lgbtsteminar",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.40094253891464, -1.511608427391864 ]
  },
  "id_str" : "819688729891762177",
  "text" : "End of day 0 of the #lgbtsteminar. I got a unicorn duck, that\u2019s allegedly the symbol of \u00ABLGBT in intellectual property\u00BB \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83D\uDE02\uD83E\uDD14 https:\/\/t.co\/i2b4wtHP5R",
  "id" : 819688729891762177,
  "created_at" : "2017-01-12 23:33:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.36506928017567, -2.272429446511194 ]
  },
  "id_str" : "819631415318953984",
  "text" : "\u00ABI love you so much, you even make being detained at the airport so much nicer!\u00BB My kind of testimonials.",
  "id" : 819631415318953984,
  "created_at" : "2017-01-12 19:45:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819610905860247552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.36214818238064, -2.274624625689229 ]
  },
  "id_str" : "819624740675579905",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin good point. :(",
  "id" : 819624740675579905,
  "in_reply_to_status_id" : 819610905860247552,
  "created_at" : "2017-01-12 19:19:00 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819577049979482113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45226709176548, 8.559335405014975 ]
  },
  "id_str" : "819580384094650368",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli awesome! \uD83D\uDC4F\uD83C\uDFFC",
  "id" : 819580384094650368,
  "in_reply_to_status_id" : 819577049979482113,
  "created_at" : "2017-01-12 16:22:45 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "witch@serenity",
      "screen_name" : "_MinaHarker_",
      "indices" : [ 0, 13 ],
      "id_str" : "1068997124",
      "id" : 1068997124
    }, {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 14, 22 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819574803342442496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45128542664016, 8.559533035103456 ]
  },
  "id_str" : "819575056070279170",
  "in_reply_to_user_id" : 1068997124,
  "text" : "@_MinaHarker_ @PhdGeek sure (and Mina says thanks, will keep an eye out)",
  "id" : 819575056070279170,
  "in_reply_to_status_id" : 819574803342442496,
  "created_at" : "2017-01-12 16:01:34 +0000",
  "in_reply_to_screen_name" : "_MinaHarker_",
  "in_reply_to_user_id_str" : "1068997124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "witch@serenity",
      "screen_name" : "_MinaHarker_",
      "indices" : [ 9, 22 ],
      "id_str" : "1068997124",
      "id" : 1068997124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819564814909472771",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45121828993587, 8.559067055923089 ]
  },
  "id_str" : "819568015616438272",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek @_MinaHarker_ ah, sorry. Whether there\u2019ll be a LGBT STEMinar in 2018. :)",
  "id" : 819568015616438272,
  "in_reply_to_status_id" : 819564814909472771,
  "created_at" : "2017-01-12 15:33:36 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "witch@serenity",
      "screen_name" : "_MinaHarker_",
      "indices" : [ 0, 13 ],
      "id_str" : "1068997124",
      "id" : 1068997124
    }, {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 32, 40 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819564186355298306",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45121223379392, 8.559218105532576 ]
  },
  "id_str" : "819564506166730752",
  "in_reply_to_user_id" : 1068997124,
  "text" : "@_MinaHarker_ I don\u2019t know. But @PhdGeek might be able to say :)",
  "id" : 819564506166730752,
  "in_reply_to_status_id" : 819564186355298306,
  "created_at" : "2017-01-12 15:19:39 +0000",
  "in_reply_to_screen_name" : "_MinaHarker_",
  "in_reply_to_user_id_str" : "1068997124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/4XPQyILUdz",
      "expanded_url" : "https:\/\/lgbtstem.wordpress.com\/lgbt-steminar-2017\/",
      "display_url" : "lgbtstem.wordpress.com\/lgbt-steminar-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45125688707816, 8.559146669400047 ]
  },
  "id_str" : "819563522677997568",
  "text" : "ZRH \u2708\uFE0F MAN. Heading to Sheffield, giving the keynote for the LGBT STEMinar there tomorrow. \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08 https:\/\/t.co\/4XPQyILUdz",
  "id" : 819563522677997568,
  "created_at" : "2017-01-12 15:15:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/7KZ9yesq8J",
      "expanded_url" : "https:\/\/twitter.com\/MP_Innovation\/status\/819504386229600256",
      "display_url" : "twitter.com\/MP_Innovation\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45127461545803, 8.558028087968676 ]
  },
  "id_str" : "819557191493578752",
  "text" : "Looks like a chromosome map \uD83D\uDE02 https:\/\/t.co\/7KZ9yesq8J",
  "id" : 819557191493578752,
  "created_at" : "2017-01-12 14:50:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/iNL0dFM1Z4",
      "expanded_url" : "https:\/\/twitter.com\/AllPlanets\/status\/819238826740740100",
      "display_url" : "twitter.com\/AllPlanets\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933046288815, 8.587768130732538 ]
  },
  "id_str" : "819469357310943232",
  "text" : "Yes, also having your friends located somewhere between UTC-10:00 and UTC+10:00 doesn\u2019t help too much. https:\/\/t.co\/iNL0dFM1Z4",
  "id" : 819469357310943232,
  "created_at" : "2017-01-12 09:01:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819273003494232064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35935774986583, 8.587710719734213 ]
  },
  "id_str" : "819307143736291328",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice right. Early doesn\u2019t ever happen basically.",
  "id" : 819307143736291328,
  "in_reply_to_status_id" : 819273003494232064,
  "created_at" : "2017-01-11 22:16:59 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Stroehlein",
      "screen_name" : "stroehli",
      "indices" : [ 0, 9 ],
      "id_str" : "831094674",
      "id" : 831094674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819283735405174786",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35935774986583, 8.587710719734213 ]
  },
  "id_str" : "819307045979586561",
  "in_reply_to_user_id" : 831094674,
  "text" : "@stroehli furiously happy :)",
  "id" : 819307045979586561,
  "in_reply_to_status_id" : 819283735405174786,
  "created_at" : "2017-01-11 22:16:36 +0000",
  "in_reply_to_screen_name" : "stroehli",
  "in_reply_to_user_id_str" : "831094674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819260946526990337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35923418306567, 8.587631745867018 ]
  },
  "id_str" : "819269510771462151",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice that\u2019s +\/- the German way.",
  "id" : 819269510771462151,
  "in_reply_to_status_id" : 819260946526990337,
  "created_at" : "2017-01-11 19:47:27 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819245733190791172",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.39758510204861, 8.497041119579814 ]
  },
  "id_str" : "819259020104101888",
  "in_reply_to_user_id" : 14286491,
  "text" : "The train conductor keeps apologizing for a 6 minute delay while i wish a single of my daily commuter trains would have that little a delay\u2026",
  "id" : 819259020104101888,
  "in_reply_to_status_id" : 819245733190791172,
  "created_at" : "2017-01-11 19:05:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/819245733190791172\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/CLoWttBBgZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C16LpEpW8AAyFoG.jpg",
      "id_str" : "819245719966117888",
      "id" : 819245719966117888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C16LpEpW8AAyFoG.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/CLoWttBBgZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.54096206400907, 7.633151472616326 ]
  },
  "id_str" : "819245733190791172",
  "text" : "Totally what I wanted to read while crossing into Switzerland. https:\/\/t.co\/CLoWttBBgZ",
  "id" : 819245733190791172,
  "created_at" : "2017-01-11 18:12:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819191070609338368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10381999928468, 8.659216414388888 ]
  },
  "id_str" : "819198066070790146",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna bislang in einigen St\u00E4dten weltweit verwendet. Hat bislang immer gut geklappt.",
  "id" : 819198066070790146,
  "in_reply_to_status_id" : 819191070609338368,
  "created_at" : "2017-01-11 15:03:33 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818998302859558912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10702474513101, 8.663222221665702 ]
  },
  "id_str" : "819192099291746304",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy thanks so much! :)",
  "id" : 819192099291746304,
  "in_reply_to_status_id" : 818998302859558912,
  "created_at" : "2017-01-11 14:39:50 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wellcome Collection",
      "screen_name" : "ExploreWellcome",
      "indices" : [ 3, 19 ],
      "id_str" : "48370227",
      "id" : 48370227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819189083368988673",
  "text" : "RT @ExploreWellcome: Wow. Historic FAKE NEWS leak: 'orange-faced devil grabs people with small hands, urinates'. A TOTAL WITCH HUNT! Shame.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ExploreWellcome\/status\/819184448247894017\/photo\/1",
        "indices" : [ 129, 152 ],
        "url" : "https:\/\/t.co\/hMJrABAfuq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C15Fw0aXcAM-WTm.jpg",
        "id_str" : "819168887233277955",
        "id" : 819168887233277955,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C15Fw0aXcAM-WTm.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 536
        }, {
          "h" : 952,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 952,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 952,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/hMJrABAfuq"
      } ],
      "hashtags" : [ {
        "text" : "fakenews",
        "indices" : [ 119, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819184448247894017",
    "text" : "Wow. Historic FAKE NEWS leak: 'orange-faced devil grabs people with small hands, urinates'. A TOTAL WITCH HUNT! Shame. #fakenews https:\/\/t.co\/hMJrABAfuq",
    "id" : 819184448247894017,
    "created_at" : "2017-01-11 14:09:26 +0000",
    "user" : {
      "name" : "Wellcome Collection",
      "screen_name" : "ExploreWellcome",
      "protected" : false,
      "id_str" : "48370227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/833424149410361346\/p5Yq5ani_normal.jpg",
      "id" : 48370227,
      "verified" : true
    }
  },
  "id" : 819189083368988673,
  "created_at" : "2017-01-11 14:27:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 3, 11 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818970738959020032",
  "text" : "RT @mbeisen: looking for people to talk to about feasibility of harvesting marine microbes from open ocean for food - any suggestions?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "818946930885545984",
    "text" : "looking for people to talk to about feasibility of harvesting marine microbes from open ocean for food - any suggestions?",
    "id" : 818946930885545984,
    "created_at" : "2017-01-10 22:25:38 +0000",
    "user" : {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "protected" : false,
      "id_str" : "19843630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893602583478239236\/Gkp75Fa5_normal.jpg",
      "id" : 19843630,
      "verified" : true
    }
  },
  "id" : 818970738959020032,
  "created_at" : "2017-01-11 00:00:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818954663600877569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083305353803, 8.818722969526718 ]
  },
  "id_str" : "818955537220063233",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson thanks! \uD83D\uDE0D",
  "id" : 818955537220063233,
  "in_reply_to_status_id" : 818954663600877569,
  "created_at" : "2017-01-10 22:59:50 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 77, 85 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/6imn1yXSZz",
      "expanded_url" : "https:\/\/www.theguardian.com\/artanddesign\/jonathanjonesblog\/2017\/jan\/10\/bosch-garden-of-earthly-delights-shows-a-world-waking-up-to-the-future?CMP=Share_iOSApp_Other",
      "display_url" : "theguardian.com\/artanddesign\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818938481422585858",
  "text" : "Bosch's Garden of Earthly Delights shows a world waking up to the future \/cc @iaravps  https:\/\/t.co\/6imn1yXSZz",
  "id" : 818938481422585858,
  "created_at" : "2017-01-10 21:52:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "indices" : [ 0, 7 ],
      "id_str" : "111716214",
      "id" : 111716214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818899763005366272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06096212198032, 8.818542994567023 ]
  },
  "id_str" : "818899803518156800",
  "in_reply_to_user_id" : 111716214,
  "text" : "@nplhse Danke!",
  "id" : 818899803518156800,
  "in_reply_to_status_id" : 818899763005366272,
  "created_at" : "2017-01-10 19:18:22 +0000",
  "in_reply_to_screen_name" : "nplhse",
  "in_reply_to_user_id_str" : "111716214",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/818899642142310400\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/xDd2zghR7K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C11Q4k8XcAEr3Qr.jpg",
      "id_str" : "818899640171065345",
      "id" : 818899640171065345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C11Q4k8XcAEr3Qr.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xDd2zghR7K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818899642142310400",
  "text" : "SJ Gould on why we all should learn stats. https:\/\/t.co\/xDd2zghR7K",
  "id" : 818899642142310400,
  "created_at" : "2017-01-10 19:17:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818898906063011844",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099072391191, 8.818673028066815 ]
  },
  "id_str" : "818899061981986817",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo \uD83E\uDD1E",
  "id" : 818899061981986817,
  "in_reply_to_status_id" : 818898906063011844,
  "created_at" : "2017-01-10 19:15:25 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818898607726280704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084636789752, 8.818572498866187 ]
  },
  "id_str" : "818898858067509249",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo thank you. \uD83D\uDE0D Maybe even in Toronto. Entered my name for the Summit!",
  "id" : 818898858067509249,
  "in_reply_to_status_id" : 818898607726280704,
  "created_at" : "2017-01-10 19:14:36 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2716\uFE0F\u3030\u2716\uFE0F",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818892871709454337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06111499729507, 8.818893791930149 ]
  },
  "id_str" : "818892989846196230",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos \uD83D\uDC4D",
  "id" : 818892989846196230,
  "in_reply_to_status_id" : 818892871709454337,
  "created_at" : "2017-01-10 18:51:17 +0000",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2716\uFE0F\u3030\u2716\uFE0F",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818892384473849856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06111352141635, 8.818698274952023 ]
  },
  "id_str" : "818892777798926337",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos ebenso, wir hatten ja noch gar nicht das Vergn\u00FCgen! \uD83D\uDE0A",
  "id" : 818892777798926337,
  "in_reply_to_status_id" : 818892384473849856,
  "created_at" : "2017-01-10 18:50:27 +0000",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 10, 18 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818892205351927809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06106813447338, 8.818705424052835 ]
  },
  "id_str" : "818892488748449792",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @iaravps perfect, then for next week!",
  "id" : 818892488748449792,
  "in_reply_to_status_id" : 818892205351927809,
  "created_at" : "2017-01-10 18:49:18 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06100274804673, 8.81853869914476 ]
  },
  "id_str" : "818892389502898177",
  "text" : "Taking public transport is great for the environment, my activity goals and all. But it feels like I lose 10 hours a day in packed trains \uD83D\uDE14",
  "id" : 818892389502898177,
  "created_at" : "2017-01-10 18:48:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 10, 18 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818884515015725056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06109274704872, 8.818587085884595 ]
  },
  "id_str" : "818892047629352962",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @iaravps thanks but I will pass. All the best for the call though!",
  "id" : 818892047629352962,
  "in_reply_to_status_id" : 818884515015725056,
  "created_at" : "2017-01-10 18:47:33 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 9, 16 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818887808999968768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06111547498682, 8.818883455220172 ]
  },
  "id_str" : "818891922999824385",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX @lsanoj Danke!",
  "id" : 818891922999824385,
  "in_reply_to_status_id" : 818887808999968768,
  "created_at" : "2017-01-10 18:47:03 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "\u2716\uFE0F\u3030\u2716\uFE0F",
      "screen_name" : "MamsellChaos",
      "indices" : [ 12, 25 ],
      "id_str" : "140774041",
      "id" : 140774041
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 26, 33 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818887218538356737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06111547498682, 8.818883455220172 ]
  },
  "id_str" : "818891900015022080",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @MamsellChaos @lsanoj Danke!",
  "id" : 818891900015022080,
  "in_reply_to_status_id" : 818887218538356737,
  "created_at" : "2017-01-10 18:46:57 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 26, 35 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818879713456390145",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06096060139169, 8.818603381868838 ]
  },
  "id_str" : "818883391944794113",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps yes! Though soon @MsPhelps will tell me to join this evenings SC call. \uD83D\uDE02",
  "id" : 818883391944794113,
  "in_reply_to_status_id" : 818879713456390145,
  "created_at" : "2017-01-10 18:13:09 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818878497590562816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0597109606766, 8.80250766396511 ]
  },
  "id_str" : "818879470891368449",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps \uD83D\uDC96thanks! It\u2019s too bad that there\u2019s no FORCE event to celebrate my birthday at \uD83D\uDE02",
  "id" : 818879470891368449,
  "in_reply_to_status_id" : 818878497590562816,
  "created_at" : "2017-01-10 17:57:34 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Herper",
      "screen_name" : "matthewherper",
      "indices" : [ 0, 14 ],
      "id_str" : "44438256",
      "id" : 44438256
    }, {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "indices" : [ 15, 26 ],
      "id_str" : "183548902",
      "id" : 183548902
    }, {
      "name" : "David States",
      "screen_name" : "statesdj",
      "indices" : [ 27, 36 ],
      "id_str" : "390731779",
      "id" : 390731779
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 37, 53 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Szymon T Calus",
      "screen_name" : "Szymonome",
      "indices" : [ 54, 64 ],
      "id_str" : "1638285584",
      "id" : 1638285584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818839110768918528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233733863877, 8.62763556925523 ]
  },
  "id_str" : "818852539366076416",
  "in_reply_to_user_id" : 44438256,
  "text" : "@matthewherper @ewanbirney @statesdj @pathogenomenick @Szymonome fixed now.",
  "id" : 818852539366076416,
  "in_reply_to_status_id" : 818839110768918528,
  "created_at" : "2017-01-10 16:10:33 +0000",
  "in_reply_to_screen_name" : "matthewherper",
  "in_reply_to_user_id_str" : "44438256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818846286661255174",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227644820809, 8.627510023832595 ]
  },
  "id_str" : "818846984861810688",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj awww, danke! \uD83D\uDC36",
  "id" : 818846984861810688,
  "in_reply_to_status_id" : 818846286661255174,
  "created_at" : "2017-01-10 15:48:29 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 14, 23 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818843418566819840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227622992826, 8.627509573778811 ]
  },
  "id_str" : "818846928251265024",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist @wilbanks thanks! \uD83D\uDE0D",
  "id" : 818846928251265024,
  "in_reply_to_status_id" : 818843418566819840,
  "created_at" : "2017-01-10 15:48:15 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frankfurt",
      "indices" : [ 114, 124 ]
    }, {
      "text" : "offenbach",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818821341537247232",
  "text" : "RT @Lobot: M\u00F6chte gerne einen Kanadier einlagern - 5m lang, 1m breit. Hat jemand Platz daf\u00FCr und w\u00FCrde vermieten? #frankfurt #offenbach",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "frankfurt",
        "indices" : [ 103, 113 ]
      }, {
        "text" : "offenbach",
        "indices" : [ 114, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "818820970911764482",
    "text" : "M\u00F6chte gerne einen Kanadier einlagern - 5m lang, 1m breit. Hat jemand Platz daf\u00FCr und w\u00FCrde vermieten? #frankfurt #offenbach",
    "id" : 818820970911764482,
    "created_at" : "2017-01-10 14:05:07 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 818821341537247232,
  "created_at" : "2017-01-10 14:06:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 17, 31 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818812054320644096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241207773455, 8.627789668206677 ]
  },
  "id_str" : "818817175129571328",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @BioMickWatson tell me it\u2019s FuqU, the soon popular follow-up to fastq.",
  "id" : 818817175129571328,
  "in_reply_to_status_id" : 818812054320644096,
  "created_at" : "2017-01-10 13:50:02 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/zpWJgmbm2X",
      "expanded_url" : "https:\/\/www.theguardian.com\/media\/2013\/feb\/14\/knight-foundation-regrets-jonah-lehrer-fee",
      "display_url" : "theguardian.com\/media\/2013\/feb\u2026"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/4C5LdN7Zwz",
      "expanded_url" : "https:\/\/twitter.com\/blprnt\/status\/818802891112726533",
      "display_url" : "twitter.com\/blprnt\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227648860156, 8.627510107116697 ]
  },
  "id_str" : "818816179003392001",
  "text" : "And I\u2019m kinda surprised that Jonah Lehrer isn\u2019t one of them.  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/zpWJgmbm2X https:\/\/t.co\/4C5LdN7Zwz",
  "id" : 818816179003392001,
  "created_at" : "2017-01-10 13:46:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818813743136018433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229555146998, 8.62754941142071 ]
  },
  "id_str" : "818813972304502784",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog thanks mate! \uD83D\uDC96",
  "id" : 818813972304502784,
  "in_reply_to_status_id" : 818813743136018433,
  "created_at" : "2017-01-10 13:37:18 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "indices" : [ 0, 11 ],
      "id_str" : "402180727",
      "id" : 402180727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818811754025259008",
  "geo" : { },
  "id_str" : "818811920161587204",
  "in_reply_to_user_id" : 402180727,
  "text" : "@PHerterich oh, thank you so much! And thanks for the wishes! \uD83D\uDC96\uD83C\uDF89",
  "id" : 818811920161587204,
  "in_reply_to_status_id" : 818811754025259008,
  "created_at" : "2017-01-10 13:29:09 +0000",
  "in_reply_to_screen_name" : "PHerterich",
  "in_reply_to_user_id_str" : "402180727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/OprjH129UP",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
      "display_url" : "patreon.com\/openSNP"
    }, {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/e4Cifc9rFj",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/818809321442131968",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233669812896, 8.627634248638751 ]
  },
  "id_str" : "818810502436556801",
  "text" : "Patreon for openSNP (https:\/\/t.co\/OprjH129UP), GIFs and\/or just donate for whatever worthy cause you can find\/prefer. \uD83C\uDF89\uD83C\uDF81 https:\/\/t.co\/e4Cifc9rFj",
  "id" : 818810502436556801,
  "created_at" : "2017-01-10 13:23:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818809866844258304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233960116813, 8.627640234334429 ]
  },
  "id_str" : "818810021911953408",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks but totally understandable that it didn\u2019t work out. Maybe in SEA this year?",
  "id" : 818810021911953408,
  "in_reply_to_status_id" : 818809866844258304,
  "created_at" : "2017-01-10 13:21:36 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818809321442131968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233695541515, 8.62763477386154 ]
  },
  "id_str" : "818809730026078208",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks thanks my friend. If our schedules shall ever align again we\u2019ll go for drinks. \uD83C\uDF89\uD83E\uDD43",
  "id" : 818809730026078208,
  "in_reply_to_status_id" : 818809321442131968,
  "created_at" : "2017-01-10 13:20:27 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818796414868357121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233887628588, 8.627634783221414 ]
  },
  "id_str" : "818797188969009153",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot terrific and terrifying read",
  "id" : 818797188969009153,
  "in_reply_to_status_id" : 818796414868357121,
  "created_at" : "2017-01-10 12:30:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/0ERjFUZRaT",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BPFWulKh5jX\/",
      "display_url" : "instagram.com\/p\/BPFWulKh5jX\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17292, 8.6321999 ]
  },
  "id_str" : "818795020048183296",
  "text" : "Team Horizontal Snow Transfer (aka: we're not slacking off\u2026) @ Goethe-Universit\u00E4t Frankfurt,\u2026 https:\/\/t.co\/0ERjFUZRaT",
  "id" : 818795020048183296,
  "created_at" : "2017-01-10 12:21:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/sh2sM3upTe",
      "expanded_url" : "http:\/\/www.haaretz.com\/israel-news\/.premium-1.764002",
      "display_url" : "haaretz.com\/israel-news\/.p\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233533325094, 8.62763143451418 ]
  },
  "id_str" : "818765359356538881",
  "text" : "\u00ABHolocaust Deniers at Yad Vashem: German Far-right Tour Israel\u00BB As if things aren\u2019t ridiculous enough these days\u2026 https:\/\/t.co\/sh2sM3upTe",
  "id" : 818765359356538881,
  "created_at" : "2017-01-10 10:24:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 0, 10 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818757443719200768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18697143999999, 8.615271249999996 ]
  },
  "id_str" : "818758087146348545",
  "in_reply_to_user_id" : 1435074373,
  "text" : "@AidanBudd also good point. That\u2019s a tad different for me. Ready wide when it comes to non-fiction.",
  "id" : 818758087146348545,
  "in_reply_to_status_id" : 818757443719200768,
  "created_at" : "2017-01-10 09:55:14 +0000",
  "in_reply_to_screen_name" : "AidanBudd",
  "in_reply_to_user_id_str" : "1435074373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818756111872430082",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233659810253, 8.627634042398281 ]
  },
  "id_str" : "818756735385141249",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina danke!",
  "id" : 818756735385141249,
  "in_reply_to_status_id" : 818756111872430082,
  "created_at" : "2017-01-10 09:49:52 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 0, 10 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818755589992050688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227645584489, 8.627510039562921 ]
  },
  "id_str" : "818756675419209728",
  "in_reply_to_user_id" : 1435074373,
  "text" : "@AidanBudd maybe seemingly casual references to ppl owning guns is something Europeans not associate w\/ non-fiction?",
  "id" : 818756675419209728,
  "in_reply_to_status_id" : 818755589992050688,
  "created_at" : "2017-01-10 09:49:37 +0000",
  "in_reply_to_screen_name" : "AidanBudd",
  "in_reply_to_user_id_str" : "1435074373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818751264985124864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18697143999999, 8.615271249999996 ]
  },
  "id_str" : "818754090155044866",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas thanks!",
  "id" : 818754090155044866,
  "in_reply_to_status_id" : 818751264985124864,
  "created_at" : "2017-01-10 09:39:21 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818742471035326464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236448575197, 8.627689467645634 ]
  },
  "id_str" : "818742557844836352",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente Danke! \uD83D\uDE0D",
  "id" : 818742557844836352,
  "in_reply_to_status_id" : 818742471035326464,
  "created_at" : "2017-01-10 08:53:31 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18697144000143, 8.615271249990462 ]
  },
  "id_str" : "818739172966023171",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj happy birthday, gro\u00DFer! \uD83D\uDE18",
  "id" : 818739172966023171,
  "created_at" : "2017-01-10 08:40:04 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 0, 10 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/PAANwFxAGJ",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/20702392",
      "display_url" : "goodreads.com\/book\/show\/2070\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "818666689399291909",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06098818969918, 8.818324981265532 ]
  },
  "id_str" : "818705667729084416",
  "in_reply_to_user_id" : 1435074373,
  "text" : "@AidanBudd it\u2019s https:\/\/t.co\/PAANwFxAGJ",
  "id" : 818705667729084416,
  "in_reply_to_status_id" : 818666689399291909,
  "created_at" : "2017-01-10 06:26:56 +0000",
  "in_reply_to_screen_name" : "AidanBudd",
  "in_reply_to_user_id_str" : "1435074373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/uDtQ1lu25v",
      "expanded_url" : "https:\/\/twitter.com\/TrevorABranch\/status\/818586152529600512",
      "display_url" : "twitter.com\/TrevorABranch\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06077892404145, 8.818790480045532 ]
  },
  "id_str" : "818603994872418304",
  "text" : "\u00ABHe owned a pick-up and a shotgun and I\u2019m relatively certain he didn\u2019t think of my gender much at all.\u00BB https:\/\/t.co\/uDtQ1lu25v",
  "id" : 818603994872418304,
  "created_at" : "2017-01-09 23:42:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PK Mital",
      "screen_name" : "pkmital",
      "indices" : [ 3, 11 ],
      "id_str" : "44698222",
      "id" : 44698222
    }, {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 112, 121 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818593337955516416",
  "text" : "RT @pkmital: Concerns every hacker\/scientist\/programmer should have\/be taught in \"Toward a New Hacker Ethic\" by @aparrish: https:\/\/t.co\/1F0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Allison Parrish",
        "screen_name" : "aparrish",
        "indices" : [ 99, 108 ],
        "id_str" : "6857962",
        "id" : 6857962
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pkmital\/status\/810551672917422080\/photo\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/fjXocGeppR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cz-oaQQUkAE8OpV.jpg",
        "id_str" : "810551626943467521",
        "id" : 810551626943467521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cz-oaQQUkAE8OpV.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/fjXocGeppR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/1F0xpvya3q",
        "expanded_url" : "http:\/\/opentranscripts.org\/transcript\/programming-forgetting-new-hacker-ethic\/",
        "display_url" : "opentranscripts.org\/transcript\/pro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "810551672917422080",
    "text" : "Concerns every hacker\/scientist\/programmer should have\/be taught in \"Toward a New Hacker Ethic\" by @aparrish: https:\/\/t.co\/1F0xpvya3q https:\/\/t.co\/fjXocGeppR",
    "id" : 810551672917422080,
    "created_at" : "2016-12-18 18:25:52 +0000",
    "user" : {
      "name" : "PK Mital",
      "screen_name" : "pkmital",
      "protected" : false,
      "id_str" : "44698222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636221351003422720\/klDHTq8I_normal.png",
      "id" : 44698222,
      "verified" : false
    }
  },
  "id" : 818593337955516416,
  "created_at" : "2017-01-09 23:00:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818591157521235968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081234439368, 8.818703458809063 ]
  },
  "id_str" : "818591418205749248",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice \uD83D\uDE0D",
  "id" : 818591418205749248,
  "in_reply_to_status_id" : 818591157521235968,
  "created_at" : "2017-01-09 22:52:57 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818584099250208768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088413162075, 8.818699365357725 ]
  },
  "id_str" : "818587647195181056",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice of course, poor PhD students need to keep an eye out for each other \uD83D\uDE0A",
  "id" : 818587647195181056,
  "in_reply_to_status_id" : 818584099250208768,
  "created_at" : "2017-01-09 22:37:58 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 14, 23 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818585663045922816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06098049391459, 8.818806845705275 ]
  },
  "id_str" : "818585950146138112",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes @SuicideC interesting! For me it\u2019s always upside-down.",
  "id" : 818585950146138112,
  "in_reply_to_status_id" : 818585663045922816,
  "created_at" : "2017-01-09 22:31:13 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shiri Eisner",
      "screen_name" : "ShiriEisner",
      "indices" : [ 3, 15 ],
      "id_str" : "1085971416",
      "id" : 1085971416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818585824635813892",
  "text" : "RT @ShiriEisner: I find it kind of heartbreaking when bi people perpetuate biphobia against other bis. This is how oppression... https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/38hw4J8Ro7",
        "expanded_url" : "http:\/\/fb.me\/8GCsqXED1",
        "display_url" : "fb.me\/8GCsqXED1"
      } ]
    },
    "geo" : { },
    "id_str" : "818163173522022400",
    "text" : "I find it kind of heartbreaking when bi people perpetuate biphobia against other bis. This is how oppression... https:\/\/t.co\/38hw4J8Ro7",
    "id" : 818163173522022400,
    "created_at" : "2017-01-08 18:31:15 +0000",
    "user" : {
      "name" : "Shiri Eisner",
      "screen_name" : "ShiriEisner",
      "protected" : false,
      "id_str" : "1085971416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3250409823\/637ea88abd3f514ac6a2384f168672f3_normal.jpeg",
      "id" : 1085971416,
      "verified" : false
    }
  },
  "id" : 818585824635813892,
  "created_at" : "2017-01-09 22:30:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818581497363865600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087444622973, 8.818758748084331 ]
  },
  "id_str" : "818582061749571584",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice any time! &amp;fwiw: in my experience important not to beat oneself up about it. Productive days follow the less productive ones \uD83C\uDF1F\uD83D\uDE1A",
  "id" : 818582061749571584,
  "in_reply_to_status_id" : 818581497363865600,
  "created_at" : "2017-01-09 22:15:46 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818551529389047809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085368933969, 8.818710171935676 ]
  },
  "id_str" : "818580686361817088",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice we\u2019ve all been there. *hugs* \uD83D\uDC36",
  "id" : 818580686361817088,
  "in_reply_to_status_id" : 818551529389047809,
  "created_at" : "2017-01-09 22:10:18 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 0, 11 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818546197321449473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083655105537, 8.81879254155389 ]
  },
  "id_str" : "818577167651115010",
  "in_reply_to_user_id" : 191004758,
  "text" : "@PygmyLoris yes, it\u2019s like you don\u2019t even know them at all.",
  "id" : 818577167651115010,
  "in_reply_to_status_id" : 818546197321449473,
  "created_at" : "2017-01-09 21:56:19 +0000",
  "in_reply_to_screen_name" : "PygmyLoris",
  "in_reply_to_user_id_str" : "191004758",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818484672552374272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06098030943306, 8.818593142280008 ]
  },
  "id_str" : "818563726257377280",
  "in_reply_to_user_id" : 14286491,
  "text" : "Don\u2019t document your artisanal file formats. Spending the evening reverse engineering your off-by-one errors is what makes bioinfo fun! \uD83E\uDD37\u200D\u2640\uFE0F",
  "id" : 818563726257377280,
  "in_reply_to_status_id" : 818484672552374272,
  "created_at" : "2017-01-09 21:02:55 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818548186843385856",
  "text" : "RT @ashedryden: We paid a designer to color-fill our logo, please ignore that our CEO supports the incoming hate-filled president https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/76rVxUMzmj",
        "expanded_url" : "https:\/\/www.ibm.com\/blogs\/policy\/diversity-rainbow-8bar\/",
        "display_url" : "ibm.com\/blogs\/policy\/d\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "818484685131153408",
    "geo" : { },
    "id_str" : "818529095176822784",
    "in_reply_to_user_id" : 9510922,
    "text" : "We paid a designer to color-fill our logo, please ignore that our CEO supports the incoming hate-filled president https:\/\/t.co\/76rVxUMzmj",
    "id" : 818529095176822784,
    "in_reply_to_status_id" : 818484685131153408,
    "created_at" : "2017-01-09 18:45:18 +0000",
    "in_reply_to_screen_name" : "ashedryden",
    "in_reply_to_user_id_str" : "9510922",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/931565323794382848\/TplIrNn5_normal.jpg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 818548186843385856,
  "created_at" : "2017-01-09 20:01:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818542877882122240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099468417442, 8.818538117825986 ]
  },
  "id_str" : "818547307910230016",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney does not require much imagination to think that it was deliberately phrased like this\u2026",
  "id" : 818547307910230016,
  "in_reply_to_status_id" : 818542877882122240,
  "created_at" : "2017-01-09 19:57:40 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818530361370034178",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608920492698, 8.818583060064183 ]
  },
  "id_str" : "818540055098785792",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes very familiar sentiments \uD83D\uDE02\uD83D\uDE0A",
  "id" : 818540055098785792,
  "in_reply_to_status_id" : 818530361370034178,
  "created_at" : "2017-01-09 19:28:51 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 3, 16 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PublicHealthGenetics",
      "indices" : [ 39, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818539819940900864",
  "text" : "RT @blueyedgenes: Early thoughts on my #PublicHealthGenetics dissertation research interviews with developers of third party tools for DTC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PublicHealthGenetics",
        "indices" : [ 21, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/DmKkunvXVJ",
        "expanded_url" : "https:\/\/twitter.com\/blueyedgenes\/status\/818528204780609536",
        "display_url" : "twitter.com\/blueyedgenes\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "818530361370034178",
    "text" : "Early thoughts on my #PublicHealthGenetics dissertation research interviews with developers of third party tools for DTC genetic data https:\/\/t.co\/DmKkunvXVJ",
    "id" : 818530361370034178,
    "created_at" : "2017-01-09 18:50:20 +0000",
    "user" : {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "protected" : false,
      "id_str" : "760870811494297600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760884999918800896\/WyAaxXFj_normal.jpg",
      "id" : 760870811494297600,
      "verified" : false
    }
  },
  "id" : 818539819940900864,
  "created_at" : "2017-01-09 19:27:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06097025242639, 8.818593537443148 ]
  },
  "id_str" : "818539581742153728",
  "text" : "When your commute takes so long that you begin to wonder whether you could have driven to Switzerland instead. \uD83D\uDE14",
  "id" : 818539581742153728,
  "created_at" : "2017-01-09 19:26:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 144, 167 ],
      "url" : "https:\/\/t.co\/6irnqWMQdi",
      "expanded_url" : "https:\/\/twitter.com\/kaythaney\/status\/818507081384951808",
      "display_url" : "twitter.com\/kaythaney\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11286150859534, 8.67858590931687 ]
  },
  "id_str" : "818520656719572992",
  "text" : "I didn\u2019t know the NIH developed the commons. In the same vein: nature was invented by npg &amp; we had no science before AAAS came along. \uD83D\uDE02\uD83E\uDD37\u200D\u2640\uFE0F https:\/\/t.co\/6irnqWMQdi",
  "id" : 818520656719572992,
  "created_at" : "2017-01-09 18:11:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dani\u00EBl Lakens",
      "screen_name" : "lakens",
      "indices" : [ 3, 10 ],
      "id_str" : "17387342",
      "id" : 17387342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818518756309815297",
  "text" : "RT @lakens: Help out our German colleagues fighting El$evier. 1) Go to Google Scholar, search for own name 2) make sure every paper is free\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lakens\/status\/818103276801589248\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/u57kIgmG70",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C1p8XehWgAAiUqr.jpg",
        "id_str" : "818103025092952064",
        "id" : 818103025092952064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1p8XehWgAAiUqr.jpg",
        "sizes" : [ {
          "h" : 1539,
          "resize" : "fit",
          "w" : 1222
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 953
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 1539,
          "resize" : "fit",
          "w" : 1222
        } ],
        "display_url" : "pic.twitter.com\/u57kIgmG70"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "818103276801589248",
    "text" : "Help out our German colleagues fighting El$evier. 1) Go to Google Scholar, search for own name 2) make sure every paper is freely available https:\/\/t.co\/u57kIgmG70",
    "id" : 818103276801589248,
    "created_at" : "2017-01-08 14:33:15 +0000",
    "user" : {
      "name" : "Dani\u00EBl Lakens",
      "screen_name" : "lakens",
      "protected" : false,
      "id_str" : "17387342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875950390952554496\/G07USELb_normal.jpg",
      "id" : 17387342,
      "verified" : true
    }
  },
  "id" : 818518756309815297,
  "created_at" : "2017-01-09 18:04:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 8, 17 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818512349724295175",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.13699183235152, 8.671061269232105 ]
  },
  "id_str" : "818514297668177920",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @SuicideC but I totally get the initial puzzling. To me it also seems like I\u2019m wearing mine 18 hours a day \uD83E\uDD13\uD83D\uDE02",
  "id" : 818514297668177920,
  "in_reply_to_status_id" : 818512349724295175,
  "created_at" : "2017-01-09 17:46:30 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/mJ0RX6NJNc",
      "expanded_url" : "https:\/\/twitter.com\/janedaily\/status\/817157386817282049",
      "display_url" : "twitter.com\/janedaily\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818510611990638592",
  "text" : "RT @bella_velo: Summit is months away. We need you and your harebrained schemes! https:\/\/t.co\/mJ0RX6NJNc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/mJ0RX6NJNc",
        "expanded_url" : "https:\/\/twitter.com\/janedaily\/status\/817157386817282049",
        "display_url" : "twitter.com\/janedaily\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "818489080396791808",
    "text" : "Summit is months away. We need you and your harebrained schemes! https:\/\/t.co\/mJ0RX6NJNc",
    "id" : 818489080396791808,
    "created_at" : "2017-01-09 16:06:18 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 818510611990638592,
  "created_at" : "2017-01-09 17:31:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 8, 17 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818508664285831169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1731298822839, 8.625708337373847 ]
  },
  "id_str" : "818509561514618880",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @SuicideC washing ones face\/taking a shower, cuddling with people, getting dressed,\u2026 things like that? :)",
  "id" : 818509561514618880,
  "in_reply_to_status_id" : 818508664285831169,
  "created_at" : "2017-01-09 17:27:41 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818508397708382208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17315761404559, 8.626649549025338 ]
  },
  "id_str" : "818509246908297216",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 fair enough :D",
  "id" : 818509246908297216,
  "in_reply_to_status_id" : 818508397708382208,
  "created_at" : "2017-01-09 17:26:26 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/Vevnf1PgD6",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/818026481146331136",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "818026481146331136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234078209398, 8.627632356171057 ]
  },
  "id_str" : "818503131768258562",
  "in_reply_to_user_id" : 14286491,
  "text" : "About sixty answers on the poll so far. Getting 100 would be awesome. \uD83E\uDD13\uD83D\uDE0E https:\/\/t.co\/Vevnf1PgD6",
  "id" : 818503131768258562,
  "in_reply_to_status_id" : 818026481146331136,
  "created_at" : "2017-01-09 17:02:08 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818484044157583360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722762270058, 8.627509567754114 ]
  },
  "id_str" : "818484672552374272",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest sorry, I meant \u201Eartisanal\u201C, that\u2019s how we\u2019re calling it these days, right. \uD83D\uDE02",
  "id" : 818484672552374272,
  "in_reply_to_status_id" : 818484044157583360,
  "created_at" : "2017-01-09 15:48:47 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 19, 27 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818484044157583360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240310933848, 8.627771176940874 ]
  },
  "id_str" : "818484381807443968",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @kopshtik @kaiblin don\u2019t forget to put it in the most arcane compressed format you can find.",
  "id" : 818484381807443968,
  "in_reply_to_status_id" : 818484044157583360,
  "created_at" : "2017-01-09 15:47:37 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 9, 17 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818476389275930624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228485877806, 8.62752736495757 ]
  },
  "id_str" : "818476723369021440",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @o_guest *puts link to the github repo in a txt file, gzips it*",
  "id" : 818476723369021440,
  "in_reply_to_status_id" : 818476389275930624,
  "created_at" : "2017-01-09 15:17:12 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 0, 15 ],
      "id_str" : "173968705",
      "id" : 173968705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/inHKrSPhaD",
      "expanded_url" : "https:\/\/scholar.google.nl\/citations?user=qGuYgMsAAAAJ&hl=en",
      "display_url" : "scholar.google.nl\/citations?user\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "818443909512777728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240662652728, 8.62777842877204 ]
  },
  "id_str" : "818469775366062080",
  "in_reply_to_user_id" : 173968705,
  "text" : "@professor_dave https:\/\/t.co\/inHKrSPhaD \uD83D\uDE09",
  "id" : 818469775366062080,
  "in_reply_to_status_id" : 818443909512777728,
  "created_at" : "2017-01-09 14:49:35 +0000",
  "in_reply_to_screen_name" : "professor_dave",
  "in_reply_to_user_id_str" : "173968705",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isabel Lacurie",
      "screen_name" : "HITSabel",
      "indices" : [ 0, 9 ],
      "id_str" : "1886531798",
      "id" : 1886531798
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 10, 20 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818469063068360706",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240662652728, 8.62777842877204 ]
  },
  "id_str" : "818469190382272512",
  "in_reply_to_user_id" : 1886531798,
  "text" : "@HITSabel @Fischblog Ich glaube nicht alle, aber die Sammelkarte liegt trotzdem noch auf meinem Schreibtisch :)",
  "id" : 818469190382272512,
  "in_reply_to_status_id" : 818469063068360706,
  "created_at" : "2017-01-09 14:47:16 +0000",
  "in_reply_to_screen_name" : "HITSabel",
  "in_reply_to_user_id_str" : "1886531798",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Isabel Lacurie",
      "screen_name" : "HITSabel",
      "indices" : [ 11, 20 ],
      "id_str" : "1886531798",
      "id" : 1886531798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/K3bVqTG0Dc",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/-9Ht9phwvv\/",
      "display_url" : "instagram.com\/p\/-9Ht9phwvv\/"
    } ]
  },
  "in_reply_to_status_id_str" : "818439813451943937",
  "geo" : { },
  "id_str" : "818468843614040065",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @HITSabel \uD83C\uDF1F\uD83C\uDF1F\uD83C\uDF1F\uD83C\uDF1F\uD83C\uDF1F. would go again. \uD83D\uDE02 https:\/\/t.co\/K3bVqTG0Dc",
  "id" : 818468843614040065,
  "in_reply_to_status_id" : 818439813451943937,
  "created_at" : "2017-01-09 14:45:53 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "POOD",
      "screen_name" : "mckellogs",
      "indices" : [ 3, 13 ],
      "id_str" : "898512982380077056",
      "id" : 898512982380077056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818461956923342848",
  "text" : "RT @McKellogs: This. \nPro tip for Male Academics : be sensitive to this &amp; what it means to close a door. Always ask before shutting a stude\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 144, 167 ],
        "url" : "https:\/\/t.co\/pFRtcK7c6J",
        "expanded_url" : "https:\/\/twitter.com\/oldelectricity\/status\/818133156847124482",
        "display_url" : "twitter.com\/oldelectricity\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "818133717575155714",
    "text" : "This. \nPro tip for Male Academics : be sensitive to this &amp; what it means to close a door. Always ask before shutting a student in with you. https:\/\/t.co\/pFRtcK7c6J",
    "id" : 818133717575155714,
    "created_at" : "2017-01-08 16:34:13 +0000",
    "user" : {
      "name" : "stephanie mckellop",
      "screen_name" : "mckelldogs",
      "protected" : false,
      "id_str" : "1011480529",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927355989724196864\/SmY0aTdO_normal.jpg",
      "id" : 1011480529,
      "verified" : false
    }
  },
  "id" : 818461956923342848,
  "created_at" : "2017-01-09 14:18:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CATHERINE COSTE",
      "screen_name" : "cathcoste",
      "indices" : [ 2, 12 ],
      "id_str" : "121684992",
      "id" : 121684992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818457358041051136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231980600837, 8.627599420107542 ]
  },
  "id_str" : "818458931613892608",
  "in_reply_to_user_id" : 121684992,
  "text" : ". @cathcoste Dunno, Aubrey de Grey mostly strikes me as being Deepak Chopra-esk, while maybe using a bit more long, sciencey words.",
  "id" : 818458931613892608,
  "in_reply_to_status_id" : 818457358041051136,
  "created_at" : "2017-01-09 14:06:30 +0000",
  "in_reply_to_screen_name" : "cathcoste",
  "in_reply_to_user_id_str" : "121684992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/DQ2zCUdVia",
      "expanded_url" : "https:\/\/twitter.com\/cathcoste\/status\/818342744997380097",
      "display_url" : "twitter.com\/cathcoste\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231980600837, 8.627599420107542 ]
  },
  "id_str" : "818456843269894149",
  "text" : "Spoiler: Nope, it won\u2019t. https:\/\/t.co\/DQ2zCUdVia",
  "id" : 818456843269894149,
  "created_at" : "2017-01-09 13:58:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/7tRP8tmt4v",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/rm6feiyq7f2xuc8\/Photo%2008-01-2017%2C%2010%2022%2002.jpg?dl=0",
      "display_url" : "dropbox.com\/s\/rm6feiyq7f2x\u2026"
    }, {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/vyaoN1fxyP",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/l7rir1dk4ds0jce\/Photo%2008-01-2017%2C%2010%2021%2045.jpg?dl=0",
      "display_url" : "dropbox.com\/s\/l7rir1dk4ds0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818450292404584448",
  "text" : "RT @gedankenstuecke: How do you put your \uD83D\uDC53\uD83D\uDD76 down? Upright (https:\/\/t.co\/7tRP8tmt4v), upside-down (https:\/\/t.co\/vyaoN1fxyP) or folded (https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/7tRP8tmt4v",
        "expanded_url" : "https:\/\/www.dropbox.com\/s\/rm6feiyq7f2xuc8\/Photo%2008-01-2017%2C%2010%2022%2002.jpg?dl=0",
        "display_url" : "dropbox.com\/s\/rm6feiyq7f2x\u2026"
      }, {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/vyaoN1fxyP",
        "expanded_url" : "https:\/\/www.dropbox.com\/s\/l7rir1dk4ds0jce\/Photo%2008-01-2017%2C%2010%2021%2045.jpg?dl=0",
        "display_url" : "dropbox.com\/s\/l7rir1dk4ds0\u2026"
      }, {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/lj3d3e2SQG",
        "expanded_url" : "https:\/\/www.dropbox.com\/s\/3oi7jab1wnae5m7\/Photo%2008-01-2017%2C%2010%2022%2019.jpg?dl=0",
        "display_url" : "dropbox.com\/s\/3oi7jab1wnae\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "818026481146331136",
    "text" : "How do you put your \uD83D\uDC53\uD83D\uDD76 down? Upright (https:\/\/t.co\/7tRP8tmt4v), upside-down (https:\/\/t.co\/vyaoN1fxyP) or folded (https:\/\/t.co\/lj3d3e2SQG)?",
    "id" : 818026481146331136,
    "created_at" : "2017-01-08 09:28:05 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 818450292404584448,
  "created_at" : "2017-01-09 13:32:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/ZX6BYauNLA",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/sIE0hveuiwCNG\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/sIE0hveu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233697549592, 8.627634809697591 ]
  },
  "id_str" : "818381912708448260",
  "text" : "Already confronting too much \u201EDo as I say, not as I do\u201C this year\u2026 https:\/\/t.co\/ZX6BYauNLA",
  "id" : 818381912708448260,
  "created_at" : "2017-01-09 09:00:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818192909564608512",
  "geo" : { },
  "id_str" : "818193063310983168",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest none broken during the drunken early 20s, that must count for something \uD83D\uDE02",
  "id" : 818193063310983168,
  "in_reply_to_status_id" : 818192909564608512,
  "created_at" : "2017-01-08 20:30:02 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/818192644606193666\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/tNj5yrbZph",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C1rNudWW8AAEnKU.jpg",
      "id_str" : "818192480357249024",
      "id" : 818192480357249024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1rNudWW8AAEnKU.jpg",
      "sizes" : [ {
        "h" : 481,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 420
      } ],
      "display_url" : "pic.twitter.com\/tNj5yrbZph"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/cwY14bLflw",
      "expanded_url" : "https:\/\/twitter.com\/johannes_mono\/status\/818173022532235264",
      "display_url" : "twitter.com\/johannes_mono\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818192644606193666",
  "text" : "Amazing! https:\/\/t.co\/cwY14bLflw https:\/\/t.co\/tNj5yrbZph",
  "id" : 818192644606193666,
  "created_at" : "2017-01-08 20:28:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818191362650767366",
  "geo" : { },
  "id_str" : "818191545618808832",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest got first pair in my teens(?) iirc, but didn\u2019t consistently use them until 20 I think.",
  "id" : 818191545618808832,
  "in_reply_to_status_id" : 818191362650767366,
  "created_at" : "2017-01-08 20:24:00 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818189968959041540",
  "geo" : { },
  "id_str" : "818190240594690048",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest \uD83D\uDC4D only broke a single pair so far. Ironically while putting it in the transport case\u2026",
  "id" : 818190240594690048,
  "in_reply_to_status_id" : 818189968959041540,
  "created_at" : "2017-01-08 20:18:49 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818166697945427968",
  "geo" : { },
  "id_str" : "818188798051909632",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest why not upside-down? :)",
  "id" : 818188798051909632,
  "in_reply_to_status_id" : 818166697945427968,
  "created_at" : "2017-01-08 20:13:05 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 10, 21 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/AMjBnq3uZ9",
      "expanded_url" : "https:\/\/twitter.com\/BrianPardy\/status\/818138236908371968",
      "display_url" : "twitter.com\/BrianPardy\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "818026866548310017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11146187005302, 8.754573469971941 ]
  },
  "id_str" : "818141194307903488",
  "in_reply_to_user_id" : 14286491,
  "text" : "Thanks to @BrianPardy it\u2019s now also a phenotype on openSNP! \uD83D\uDE0E https:\/\/t.co\/AMjBnq3uZ9",
  "id" : 818141194307903488,
  "in_reply_to_status_id" : 818026866548310017,
  "created_at" : "2017-01-08 17:03:55 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818139130739757059",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11145211927001, 8.7545786271019 ]
  },
  "id_str" : "818139652087496704",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC didn\u2019t think about it when drafting poll. For me it\u2019s upside-down regardless of time. Assume you\u2019re folded for the night? :D",
  "id" : 818139652087496704,
  "in_reply_to_status_id" : 818139130739757059,
  "created_at" : "2017-01-08 16:57:48 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818135252577189888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11355906729597, 8.754233680673646 ]
  },
  "id_str" : "818135579292471297",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy please create one if you want! I have a pet theory that it correlates with another phenotype. Will happily share after poll :)",
  "id" : 818135579292471297,
  "in_reply_to_status_id" : 818135252577189888,
  "created_at" : "2017-01-08 16:41:36 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818126298992308229",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10775983803915, 8.753422563903735 ]
  },
  "id_str" : "818133609202798592",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC i know, hard to put it all inside the poll. Am especially interested in the \u201Cjust putting them down for 5-10 minutes\u201D case.",
  "id" : 818133609202798592,
  "in_reply_to_status_id" : 818126298992308229,
  "created_at" : "2017-01-08 16:33:47 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Tx2z4vLxV8",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/818066795038969856",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "818066795038969856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11217333283533, 8.753436022487508 ]
  },
  "id_str" : "818069396044337153",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABI knew you\u2019d come around eventually. There are no atheists in ice cream parlors\u2026\u00BB https:\/\/t.co\/Tx2z4vLxV8",
  "id" : 818069396044337153,
  "in_reply_to_status_id" : 818066795038969856,
  "created_at" : "2017-01-08 12:18:37 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403826055545, 8.753414621652723 ]
  },
  "id_str" : "818066795038969856",
  "text" : "\u00ABWhy are you doing this to me, God? Your own son didn\u2019t have to suffer that much!\u00BB Me, figuring out the \uD83C\uDF68\uD83C\uDF66is not as tasty as I had hoped.",
  "id" : 818066795038969856,
  "created_at" : "2017-01-08 12:08:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 0, 14 ],
      "id_str" : "636216638",
      "id" : 636216638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818027059150786560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403709108583, 8.753424481485998 ]
  },
  "id_str" : "818027499896578048",
  "in_reply_to_user_id" : 636216638,
  "text" : "@DaniRabaiotti that really us terrifying! \uD83D\uDE31\uD83D\uDE02",
  "id" : 818027499896578048,
  "in_reply_to_status_id" : 818027059150786560,
  "created_at" : "2017-01-08 09:32:08 +0000",
  "in_reply_to_screen_name" : "DaniRabaiotti",
  "in_reply_to_user_id_str" : "636216638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/Vevnf1PgD6",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/818026481146331136",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "818026481146331136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114037635857, 8.75342201502288 ]
  },
  "id_str" : "818026866548310017",
  "in_reply_to_user_id" : 14286491,
  "text" : "This one has a poll attached, please give your vote. \uD83D\uDE0E\uD83E\uDD13 https:\/\/t.co\/Vevnf1PgD6",
  "id" : 818026866548310017,
  "in_reply_to_status_id" : 818026481146331136,
  "created_at" : "2017-01-08 09:29:37 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/7tRP8tmt4v",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/rm6feiyq7f2xuc8\/Photo%2008-01-2017%2C%2010%2022%2002.jpg?dl=0",
      "display_url" : "dropbox.com\/s\/rm6feiyq7f2x\u2026"
    }, {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/vyaoN1fxyP",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/l7rir1dk4ds0jce\/Photo%2008-01-2017%2C%2010%2021%2045.jpg?dl=0",
      "display_url" : "dropbox.com\/s\/l7rir1dk4ds0\u2026"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/lj3d3e2SQG",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/3oi7jab1wnae5m7\/Photo%2008-01-2017%2C%2010%2022%2019.jpg?dl=0",
      "display_url" : "dropbox.com\/s\/3oi7jab1wnae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818026481146331136",
  "text" : "How do you put your \uD83D\uDC53\uD83D\uDD76 down? Upright (https:\/\/t.co\/7tRP8tmt4v), upside-down (https:\/\/t.co\/vyaoN1fxyP) or folded (https:\/\/t.co\/lj3d3e2SQG)?",
  "id" : 818026481146331136,
  "created_at" : "2017-01-08 09:28:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/AJYx9nziJJ",
      "expanded_url" : "http:\/\/www.haaretz.com\/israel-news\/.premium-1.763280",
      "display_url" : "haaretz.com\/israel-news\/.p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "817844339711873026",
  "text" : "Gaza: No water, no electricity and children dying unnecessarily https:\/\/t.co\/AJYx9nziJJ",
  "id" : 817844339711873026,
  "created_at" : "2017-01-07 21:24:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/OlP34xRTlo",
      "expanded_url" : "https:\/\/s-media-cache-ak0.pinimg.com\/236x\/95\/99\/75\/95997547ed2a26077b83c760ab2cfb18.jpg",
      "display_url" : "s-media-cache-ak0.pinimg.com\/236x\/95\/99\/75\/\u2026"
    }, {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Dx1Qg90JeY",
      "expanded_url" : "https:\/\/image.freepik.com\/free-icon\/empty-set-mathematical-symbol_318-59301.jpg",
      "display_url" : "image.freepik.com\/free-icon\/empt\u2026"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/jGHbm9nQVL",
      "expanded_url" : "https:\/\/twitter.com\/EmilyGorcenski\/status\/817455139963293697",
      "display_url" : "twitter.com\/EmilyGorcenski\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395142308763, 8.75355275264907 ]
  },
  "id_str" : "817473062991958016",
  "text" : "Typical polyamorous relationship graph: https:\/\/t.co\/OlP34xRTlo\n\nThe network of Wikileaks: https:\/\/t.co\/Dx1Qg90JeY https:\/\/t.co\/jGHbm9nQVL",
  "id" : 817473062991958016,
  "created_at" : "2017-01-06 20:49:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 16, 24 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "Dnavid",
      "screen_name" : "davidweisss",
      "indices" : [ 25, 37 ],
      "id_str" : "19355816",
      "id" : 19355816
    }, {
      "name" : "Ethan White",
      "screen_name" : "ethanwhite",
      "indices" : [ 38, 49 ],
      "id_str" : "34540379",
      "id" : 34540379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817449571244642304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403730351375, 8.753420775496625 ]
  },
  "id_str" : "817469130517446657",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski @dhimmel @davidweisss @ethanwhite in general virtually nothing in biology is a true binary, best to avoid all those.",
  "id" : 817469130517446657,
  "in_reply_to_status_id" : 817449571244642304,
  "created_at" : "2017-01-06 20:33:23 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 3, 12 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Mozilla",
      "screen_name" : "mozilla",
      "indices" : [ 79, 87 ],
      "id_str" : "106682853",
      "id" : 106682853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/e6ZfGgwQsG",
      "expanded_url" : "https:\/\/medium.com\/read-write-participate\/are-you-building-in-the-open-join-forces-with-mozilla-a791dbb5c74b",
      "display_url" : "medium.com\/read-write-par\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "817419874813300737",
  "text" : "RT @abbycabs: Want to level up your #opensource skills? 2 wks left to apply to @mozilla's Open Leadership Training! \nhttps:\/\/t.co\/e6ZfGgwQsG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla",
        "screen_name" : "mozilla",
        "indices" : [ 65, 73 ],
        "id_str" : "106682853",
        "id" : 106682853
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 22, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/e6ZfGgwQsG",
        "expanded_url" : "https:\/\/medium.com\/read-write-participate\/are-you-building-in-the-open-join-forces-with-mozilla-a791dbb5c74b",
        "display_url" : "medium.com\/read-write-par\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "817356043093233664",
    "text" : "Want to level up your #opensource skills? 2 wks left to apply to @mozilla's Open Leadership Training! \nhttps:\/\/t.co\/e6ZfGgwQsG",
    "id" : 817356043093233664,
    "created_at" : "2017-01-06 13:04:01 +0000",
    "user" : {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "protected" : false,
      "id_str" : "395367768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789110152070823938\/O_ena-j7_normal.jpg",
      "id" : 395367768,
      "verified" : false
    }
  },
  "id" : 817419874813300737,
  "created_at" : "2017-01-06 17:17:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403714937102, 8.753421593605236 ]
  },
  "id_str" : "817419221227503616",
  "text" : "By coincidence: Book #666 on my Goodreads bookshelf was Amos Oz\u2019s Judas. \uD83D\uDE02",
  "id" : 817419221227503616,
  "created_at" : "2017-01-06 17:15:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817344079252045824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234459108187, 8.627628257322908 ]
  },
  "id_str" : "817344795203010560",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 yep, Ich glaube theoretisch schon!",
  "id" : 817344795203010560,
  "in_reply_to_status_id" : 817344079252045824,
  "created_at" : "2017-01-06 12:19:19 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 57, 68 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/4HtjxglmRX",
      "expanded_url" : "https:\/\/twitter.com\/CBCToronto\/status\/817054255991373824",
      "display_url" : "twitter.com\/CBCToronto\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247971604958, 8.627597026715847 ]
  },
  "id_str" : "817317865544187904",
  "text" : "I really know which city I need to visit this year. \/cc  @LouWoodley https:\/\/t.co\/4HtjxglmRX",
  "id" : 817317865544187904,
  "created_at" : "2017-01-06 10:32:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233678032687, 8.62763441811341 ]
  },
  "id_str" : "817303324659687425",
  "text" : "At least there\u2019s some benefit of the iCloud sync of reminders being so broken: you get to cross off a lot of tasks from your To-Do twice\u2026",
  "id" : 817303324659687425,
  "created_at" : "2017-01-06 09:34:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 3, 17 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817302424545333249",
  "text" : "RT @AprilHathcock: A ton of WOC w\/activist expertise put in a ton of work to make these marches successful realities. Just sayin. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/n3zNUKclgz",
        "expanded_url" : "https:\/\/twitter.com\/aprilhathcock\/status\/817151667477086208",
        "display_url" : "twitter.com\/aprilhathcock\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "817151884448460804",
    "text" : "A ton of WOC w\/activist expertise put in a ton of work to make these marches successful realities. Just sayin. https:\/\/t.co\/n3zNUKclgz",
    "id" : 817151884448460804,
    "created_at" : "2017-01-05 23:32:45 +0000",
    "user" : {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "protected" : false,
      "id_str" : "3209949862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925100168277618693\/8UJUY3i2_normal.jpg",
      "id" : 3209949862,
      "verified" : false
    }
  },
  "id" : 817302424545333249,
  "created_at" : "2017-01-06 09:30:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817254866720391168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403600028008, 8.753445044704195 ]
  },
  "id_str" : "817265211564380160",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 okay! :)",
  "id" : 817265211564380160,
  "in_reply_to_status_id" : 817254866720391168,
  "created_at" : "2017-01-06 07:03:05 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/OZvL3IV75i",
      "expanded_url" : "http:\/\/callingbullshit.org\/",
      "display_url" : "callingbullshit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "817177544780840960",
  "text" : "Calling Bullshit (In the Age of Big Data). Best course idea I\u2019ve seen in a while. https:\/\/t.co\/OZvL3IV75i",
  "id" : 817177544780840960,
  "created_at" : "2017-01-06 01:14:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817135241538236417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403506946899, 8.753440278850418 ]
  },
  "id_str" : "817149254011682817",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 same here! \uD83C\uDF89 are you on Goodreads? :D",
  "id" : 817149254011682817,
  "in_reply_to_status_id" : 817135241538236417,
  "created_at" : "2017-01-05 23:22:18 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Rx7TVmaLVu",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Bessie_Coleman",
      "display_url" : "en.m.wikipedia.org\/wiki\/Bessie_Co\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "817146507329683456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403554125499, 8.7534400726605 ]
  },
  "id_str" : "817147903470866432",
  "in_reply_to_user_id" : 14286491,
  "text" : "And TIL about Bessie Coleman, first African &amp; Native American pilot. At FRA there\u2019s a street named after her. \u2708\uFE0F https:\/\/t.co\/Rx7TVmaLVu",
  "id" : 817147903470866432,
  "in_reply_to_status_id" : 817146507329683456,
  "created_at" : "2017-01-05 23:16:56 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/jUHxJaipNq",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Annie_Londonderry",
      "display_url" : "en.m.wikipedia.org\/wiki\/Annie_Lon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "817146507329683456",
  "text" : "TIL about Annie Londonderry, the first woman to bicycle around the world. \uD83D\uDC96\uD83D\uDEB2\uD83C\uDF0E\uD83C\uDF0D\uD83C\uDF0F https:\/\/t.co\/jUHxJaipNq",
  "id" : 817146507329683456,
  "created_at" : "2017-01-05 23:11:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817043018733780992",
  "geo" : { },
  "id_str" : "817083619655241732",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek oh, that\u2019s a nice one, hadn\u2019t seen it back then. \uD83D\uDC4D",
  "id" : 817083619655241732,
  "in_reply_to_status_id" : 817043018733780992,
  "created_at" : "2017-01-05 19:01:30 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816985126303399936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235459956449, 8.627601742255678 ]
  },
  "id_str" : "816985303881752576",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab yeah, also 16S is not really metagenomes. \uD83E\uDD37\u200D\u2640\uFE0F\uD83D\uDE1E",
  "id" : 816985303881752576,
  "in_reply_to_status_id" : 816985126303399936,
  "created_at" : "2017-01-05 12:30:49 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 128, 151 ],
      "url" : "https:\/\/t.co\/PlFi2I2JC3",
      "expanded_url" : "https:\/\/twitter.com\/jeroenson\/status\/816960756784762880",
      "display_url" : "twitter.com\/jeroenson\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234623988379, 8.627608034308036 ]
  },
  "id_str" : "816962784084852736",
  "text" : "That\u2019s good news as far as I can tell: more and more journals and similar alternatives popped up, diversifying the whole space. https:\/\/t.co\/PlFi2I2JC3",
  "id" : 816962784084852736,
  "created_at" : "2017-01-05 11:01:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/UYuzUMfze9",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0169563",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816949057721696256",
  "text" : "Assessment of Common and Emerging Bioinformatics Pipelines for Targeted Metagenomics (well, 16S\u2026) https:\/\/t.co\/UYuzUMfze9",
  "id" : 816949057721696256,
  "created_at" : "2017-01-05 10:06:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upulie Divisekera",
      "screen_name" : "upulie",
      "indices" : [ 3, 10 ],
      "id_str" : "187518287",
      "id" : 187518287
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/upulie\/status\/816889160090808321\/photo\/1",
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/nyDJsrd0wJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C1YsWwZUQAAckDV.jpg",
      "id_str" : "816889151874154496",
      "id" : 816889151874154496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1YsWwZUQAAckDV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 494,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 494,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 494,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/nyDJsrd0wJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816945039909621760",
  "text" : "RT @upulie: https:\/\/t.co\/nyDJsrd0wJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/upulie\/status\/816889160090808321\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/nyDJsrd0wJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C1YsWwZUQAAckDV.jpg",
        "id_str" : "816889151874154496",
        "id" : 816889151874154496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1YsWwZUQAAckDV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/nyDJsrd0wJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "816889160090808321",
    "text" : "https:\/\/t.co\/nyDJsrd0wJ",
    "id" : 816889160090808321,
    "created_at" : "2017-01-05 06:08:47 +0000",
    "user" : {
      "name" : "Upulie Divisekera",
      "screen_name" : "upulie",
      "protected" : false,
      "id_str" : "187518287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928194559242207233\/e-VpA9dJ_normal.jpg",
      "id" : 187518287,
      "verified" : true
    }
  },
  "id" : 816945039909621760,
  "created_at" : "2017-01-05 09:50:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 0, 15 ],
      "id_str" : "173968705",
      "id" : 173968705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816914274866106368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17181663760505, 8.626528637954845 ]
  },
  "id_str" : "816937591622737920",
  "in_reply_to_user_id" : 173968705,
  "text" : "@professor_dave Not only to a nearly 4 yo. Where can I get one? \uD83D\uDE02",
  "id" : 816937591622737920,
  "in_reply_to_status_id" : 816914274866106368,
  "created_at" : "2017-01-05 09:21:14 +0000",
  "in_reply_to_screen_name" : "professor_dave",
  "in_reply_to_user_id_str" : "173968705",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alp Ozcelik",
      "screen_name" : "alplicable",
      "indices" : [ 3, 14 ],
      "id_str" : "22981298",
      "id" : 22981298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/zVlhDG3RP3",
      "expanded_url" : "https:\/\/twitter.com\/dominicholden\/status\/816724946416259078",
      "display_url" : "twitter.com\/dominicholden\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816802961351475200",
  "text" : "RT @alplicable: Reminder: PrEP is *amazing* but it does not prevent any other diseases.\n\nMake smart choices. https:\/\/t.co\/zVlhDG3RP3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/zVlhDG3RP3",
        "expanded_url" : "https:\/\/twitter.com\/dominicholden\/status\/816724946416259078",
        "display_url" : "twitter.com\/dominicholden\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "816727524625575936",
    "text" : "Reminder: PrEP is *amazing* but it does not prevent any other diseases.\n\nMake smart choices. https:\/\/t.co\/zVlhDG3RP3",
    "id" : 816727524625575936,
    "created_at" : "2017-01-04 19:26:30 +0000",
    "user" : {
      "name" : "Alp Ozcelik",
      "screen_name" : "alplicable",
      "protected" : false,
      "id_str" : "22981298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903674617922912256\/tRJEJFTx_normal.jpg",
      "id" : 22981298,
      "verified" : true
    }
  },
  "id" : 816802961351475200,
  "created_at" : "2017-01-05 00:26:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 3, 16 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openSNP",
      "indices" : [ 62, 70 ]
    }, {
      "text" : "openscience",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/jsEQ5NMaak",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/816236483547906048",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816746798773583878",
  "text" : "RT @RaoOfPhysics: I support this project, and you should too! #openSNP #openscience https:\/\/t.co\/jsEQ5NMaak",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openSNP",
        "indices" : [ 44, 52 ]
      }, {
        "text" : "openscience",
        "indices" : [ 53, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/jsEQ5NMaak",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/816236483547906048",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "816742225287716864",
    "text" : "I support this project, and you should too! #openSNP #openscience https:\/\/t.co\/jsEQ5NMaak",
    "id" : 816742225287716864,
    "created_at" : "2017-01-04 20:24:55 +0000",
    "user" : {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "protected" : false,
      "id_str" : "67529128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925102556090683399\/lwyWTMw0_normal.jpg",
      "id" : 67529128,
      "verified" : false
    }
  },
  "id" : 816746798773583878,
  "created_at" : "2017-01-04 20:43:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816742225287716864",
  "geo" : { },
  "id_str" : "816746786714951681",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics thanks! \uD83D\uDC96\uD83D\uDE18",
  "id" : 816746786714951681,
  "in_reply_to_status_id" : 816742225287716864,
  "created_at" : "2017-01-04 20:43:03 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/MGUYXt5KGJ",
      "expanded_url" : "http:\/\/sci-hub.cc\/doi\/10.1080\/15295036.2016.1266683",
      "display_url" : "sci-hub.cc\/doi\/10.1080\/15\u2026"
    }, {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/MTdlAeqMSZ",
      "expanded_url" : "https:\/\/twitter.com\/leotanczt\/status\/816645427474923520",
      "display_url" : "twitter.com\/leotanczt\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816647321408667649",
  "text" : "Very cool! Use this link to get free full text access to the paper.  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/MGUYXt5KGJ https:\/\/t.co\/MTdlAeqMSZ",
  "id" : 816647321408667649,
  "created_at" : "2017-01-04 14:07:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 3, 17 ],
      "id_str" : "12984852",
      "id" : 12984852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/bYmr3YYNcs",
      "expanded_url" : "http:\/\/cameronneylon.net\/blog\/transmission-and-mediation-of-knowledge\/",
      "display_url" : "cameronneylon.net\/blog\/transmiss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816628175832776705",
  "text" : "RT @CameronNeylon: Some reflections on Scharrer et al, Ravetz, Fleck and circulation of knowledge claims:\n\nhttps:\/\/t.co\/bYmr3YYNcs\n\ncf http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/bYmr3YYNcs",
        "expanded_url" : "http:\/\/cameronneylon.net\/blog\/transmission-and-mediation-of-knowledge\/",
        "display_url" : "cameronneylon.net\/blog\/transmiss\u2026"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ZdkPFu50tD",
        "expanded_url" : "http:\/\/doi.org\/10.1177\/0963662516680311",
        "display_url" : "doi.org\/10.1177\/096366\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "816599441457213440",
    "text" : "Some reflections on Scharrer et al, Ravetz, Fleck and circulation of knowledge claims:\n\nhttps:\/\/t.co\/bYmr3YYNcs\n\ncf https:\/\/t.co\/ZdkPFu50tD",
    "id" : 816599441457213440,
    "created_at" : "2017-01-04 10:57:33 +0000",
    "user" : {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "protected" : false,
      "id_str" : "12984852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1766127492\/image1326973990_normal.png",
      "id" : 12984852,
      "verified" : false
    }
  },
  "id" : 816628175832776705,
  "created_at" : "2017-01-04 12:51:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sydette",
      "screen_name" : "Blackamazon",
      "indices" : [ 3, 15 ],
      "id_str" : "18052474",
      "id" : 18052474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816626961288196097",
  "text" : "RT @Blackamazon: No matter where you are ? Your librarian is going harder for your rights than your congressman . Make this a priority http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/paOaQn7mhN",
        "expanded_url" : "https:\/\/twitter.com\/_becca_donnelly\/status\/815719582312890368",
        "display_url" : "twitter.com\/_becca_donnell\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "815943856348917760",
    "text" : "No matter where you are ? Your librarian is going harder for your rights than your congressman . Make this a priority https:\/\/t.co\/paOaQn7mhN",
    "id" : 815943856348917760,
    "created_at" : "2017-01-02 15:32:29 +0000",
    "user" : {
      "name" : "Sydette",
      "screen_name" : "Blackamazon",
      "protected" : false,
      "id_str" : "18052474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932477544787533824\/3D6RFizB_normal.jpg",
      "id" : 18052474,
      "verified" : true
    }
  },
  "id" : 816626961288196097,
  "created_at" : "2017-01-04 12:46:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Spencer",
      "screen_name" : "charlotteis",
      "indices" : [ 3, 15 ],
      "id_str" : "894482883628457984",
      "id" : 894482883628457984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/4pQNbrlqFj",
      "expanded_url" : "https:\/\/enbytech.github.io",
      "display_url" : "enbytech.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "816625779840876544",
  "text" : "RT @Charlotteis: \u2728\uD83C\uDF38\u2728\uD83C\uDF38\u2728\uD83C\uDF38\u2728\n\nIts live! A list of non-binary speakers in tech.\n\nTake a look, add yourself!\n\nhttps:\/\/t.co\/4pQNbrlqFj\n\nPlease Ret\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/4pQNbrlqFj",
        "expanded_url" : "https:\/\/enbytech.github.io",
        "display_url" : "enbytech.github.io"
      }, {
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/CV8brgTKIE",
        "expanded_url" : "https:\/\/twitter.com\/Charlotteis\/status\/810086600331894784",
        "display_url" : "twitter.com\/Charlotteis\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "810950099555729408",
    "text" : "\u2728\uD83C\uDF38\u2728\uD83C\uDF38\u2728\uD83C\uDF38\u2728\n\nIts live! A list of non-binary speakers in tech.\n\nTake a look, add yourself!\n\nhttps:\/\/t.co\/4pQNbrlqFj\n\nPlease Retweet!\n\n\u2728\uD83C\uDF38\u2728\uD83C\uDF38\u2728\uD83C\uDF38\u2728 https:\/\/t.co\/CV8brgTKIE",
    "id" : 810950099555729408,
    "created_at" : "2016-12-19 20:49:05 +0000",
    "user" : {
      "name" : "\uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBB\uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBB @varjmes@mastodon.technology \uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBB\uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBB",
      "screen_name" : "varjmes",
      "protected" : false,
      "id_str" : "25183606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889093236194766849\/ApXECZYk_normal.jpg",
      "id" : 25183606,
      "verified" : false
    }
  },
  "id" : 816625779840876544,
  "created_at" : "2017-01-04 12:42:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lena Reinhard",
      "screen_name" : "lrnrd",
      "indices" : [ 3, 9 ],
      "id_str" : "324960013",
      "id" : 324960013
    }, {
      "name" : "Bonnie Eisenman \uD83E\uDD44",
      "screen_name" : "brindelle",
      "indices" : [ 114, 124 ],
      "id_str" : "28632036",
      "id" : 28632036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/WQvQtwgDfS",
      "expanded_url" : "http:\/\/buff.ly\/2j6obyJ",
      "display_url" : "buff.ly\/2j6obyJ"
    } ]
  },
  "geo" : { },
  "id_str" : "816624632098865152",
  "text" : "RT @lrnrd: \"\u2026how technology assumes a lot about its users.\" \u2014 \nFitbit for the spoonies\nhttps:\/\/t.co\/WQvQtwgDfS by @brindelle https:\/\/t.co\/2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bonnie Eisenman \uD83E\uDD44",
        "screen_name" : "brindelle",
        "indices" : [ 103, 113 ],
        "id_str" : "28632036",
        "id" : 28632036
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lrnrd\/status\/816563524591828992\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/2NaC6SXn8H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C1UEMnaWEAAijMp.jpg",
        "id_str" : "816563522222034944",
        "id" : 816563522222034944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1UEMnaWEAAijMp.jpg",
        "sizes" : [ {
          "h" : 687,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/2NaC6SXn8H"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/WQvQtwgDfS",
        "expanded_url" : "http:\/\/buff.ly\/2j6obyJ",
        "display_url" : "buff.ly\/2j6obyJ"
      } ]
    },
    "geo" : { },
    "id_str" : "816563524591828992",
    "text" : "\"\u2026how technology assumes a lot about its users.\" \u2014 \nFitbit for the spoonies\nhttps:\/\/t.co\/WQvQtwgDfS by @brindelle https:\/\/t.co\/2NaC6SXn8H",
    "id" : 816563524591828992,
    "created_at" : "2017-01-04 08:34:49 +0000",
    "user" : {
      "name" : "Lena Reinhard",
      "screen_name" : "lrnrd",
      "protected" : false,
      "id_str" : "324960013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853988049499435008\/ftRtoA_t_normal.jpg",
      "id" : 324960013,
      "verified" : false
    }
  },
  "id" : 816624632098865152,
  "created_at" : "2017-01-04 12:37:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816599868668055552",
  "text" : "RT @gedankenstuecke: Since January 1st openSNP is again a fully community-financed project. Consider chipping in a buck per month at https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/OprjH129UP",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
        "display_url" : "patreon.com\/openSNP"
      } ]
    },
    "in_reply_to_status_id_str" : "815914713657786368",
    "geo" : { },
    "id_str" : "816236483547906048",
    "in_reply_to_user_id" : 14286491,
    "text" : "Since January 1st openSNP is again a fully community-financed project. Consider chipping in a buck per month at https:\/\/t.co\/OprjH129UP",
    "id" : 816236483547906048,
    "in_reply_to_status_id" : 815914713657786368,
    "created_at" : "2017-01-03 10:55:17 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 816599868668055552,
  "created_at" : "2017-01-04 10:59:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Fugard",
      "screen_name" : "inductivestep",
      "indices" : [ 3, 17 ],
      "id_str" : "50617017",
      "id" : 50617017
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/inductivestep\/status\/816560833195114496\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/u7AgYvbrZa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C1UBv-EWEAAfnCd.jpg",
      "id_str" : "816560831064313856",
      "id" : 816560831064313856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1UBv-EWEAAfnCd.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1318
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 989
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1318
      } ],
      "display_url" : "pic.twitter.com\/u7AgYvbrZa"
    } ],
    "hashtags" : [ {
      "text" : "poetry",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816594829715079173",
  "text" : "RT @inductivestep: Mammogram, by Marie Cadden #poetry https:\/\/t.co\/u7AgYvbrZa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdfireapp.com\" rel=\"nofollow\"\u003ECrowdfire - Go Big\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/inductivestep\/status\/816560833195114496\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/u7AgYvbrZa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C1UBv-EWEAAfnCd.jpg",
        "id_str" : "816560831064313856",
        "id" : 816560831064313856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1UBv-EWEAAfnCd.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1318
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 989
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1318
        } ],
        "display_url" : "pic.twitter.com\/u7AgYvbrZa"
      } ],
      "hashtags" : [ {
        "text" : "poetry",
        "indices" : [ 27, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "816560833195114496",
    "text" : "Mammogram, by Marie Cadden #poetry https:\/\/t.co\/u7AgYvbrZa",
    "id" : 816560833195114496,
    "created_at" : "2017-01-04 08:24:08 +0000",
    "user" : {
      "name" : "Andy Fugard",
      "screen_name" : "inductivestep",
      "protected" : false,
      "id_str" : "50617017",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/901422485626925056\/kKQ3VhIb_normal.jpg",
      "id" : 50617017,
      "verified" : false
    }
  },
  "id" : 816594829715079173,
  "created_at" : "2017-01-04 10:39:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    }, {
      "name" : "WIRED UK",
      "screen_name" : "WiredUK",
      "indices" : [ 14, 22 ],
      "id_str" : "22363802",
      "id" : 22363802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816446904208760832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087060467578, 8.81866779934058 ]
  },
  "id_str" : "816558560750485504",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes @WiredUK and your own, once you can\u2019t afford food any longer.",
  "id" : 816558560750485504,
  "in_reply_to_status_id" : 816446904208760832,
  "created_at" : "2017-01-04 08:15:06 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/tPvxonay7C",
      "expanded_url" : "https:\/\/twitter.com\/raichoo\/status\/816358844867690497",
      "display_url" : "twitter.com\/raichoo\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078431022003, 8.81869778385799 ]
  },
  "id_str" : "816426633745879040",
  "text" : "Or in life in general\u2026 https:\/\/t.co\/tPvxonay7C",
  "id" : 816426633745879040,
  "created_at" : "2017-01-03 23:30:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scholastica",
      "screen_name" : "scholasticahq",
      "indices" : [ 3, 17 ],
      "id_str" : "270546697",
      "id" : 270546697
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 124, 140 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/7asTQJt6tl",
      "expanded_url" : "http:\/\/bit.ly\/2hsH8e3",
      "display_url" : "bit.ly\/2hsH8e3"
    } ]
  },
  "geo" : { },
  "id_str" : "816419053623476224",
  "text" : "RT @scholasticahq: \"Most of the challenges of #openscience are also true for society &amp; culture\" https:\/\/t.co\/7asTQJt6tl @gedankenstuecke #o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 105, 121 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 27, 39 ]
      }, {
        "text" : "openaccess",
        "indices" : [ 122, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/7asTQJt6tl",
        "expanded_url" : "http:\/\/bit.ly\/2hsH8e3",
        "display_url" : "bit.ly\/2hsH8e3"
      } ]
    },
    "geo" : { },
    "id_str" : "816402253410091009",
    "text" : "\"Most of the challenges of #openscience are also true for society &amp; culture\" https:\/\/t.co\/7asTQJt6tl @gedankenstuecke #openaccess",
    "id" : 816402253410091009,
    "created_at" : "2017-01-03 21:53:59 +0000",
    "user" : {
      "name" : "scholastica",
      "screen_name" : "scholasticahq",
      "protected" : false,
      "id_str" : "270546697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455833465636651008\/6leKIXzy_normal.jpeg",
      "id" : 270546697,
      "verified" : false
    }
  },
  "id" : 816419053623476224,
  "created_at" : "2017-01-03 23:00:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roland Krause",
      "screen_name" : "spitshine",
      "indices" : [ 0, 10 ],
      "id_str" : "14567800",
      "id" : 14567800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816410882540453888",
  "in_reply_to_user_id" : 14567800,
  "text" : "@spitshine that nearly made me die laughing!",
  "id" : 816410882540453888,
  "created_at" : "2017-01-03 22:28:17 +0000",
  "in_reply_to_screen_name" : "spitshine",
  "in_reply_to_user_id_str" : "14567800",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816397275517820928",
  "text" : "RT @EmilyGorcenski: If you haven't had the privilege to pursue your calling earlier in life, don't stop now. It's never too late to do some\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "816353584207925248",
    "geo" : { },
    "id_str" : "816354254818414592",
    "in_reply_to_user_id" : 1483064670,
    "text" : "If you haven't had the privilege to pursue your calling earlier in life, don't stop now. It's never too late to do something great.",
    "id" : 816354254818414592,
    "in_reply_to_status_id" : 816353584207925248,
    "created_at" : "2017-01-03 18:43:16 +0000",
    "in_reply_to_screen_name" : "EmilyGorcenski",
    "in_reply_to_user_id_str" : "1483064670",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 816397275517820928,
  "created_at" : "2017-01-03 21:34:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816323072533917696",
  "geo" : { },
  "id_str" : "816330200703176704",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna but that\u2019s nothing you can sell for tons of money, so why would you give that secret away\u2026",
  "id" : 816330200703176704,
  "in_reply_to_status_id" : 816323072533917696,
  "created_at" : "2017-01-03 17:07:41 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/zeL08S8fgG",
      "expanded_url" : "https:\/\/pbs.twimg.com\/profile_images\/488694014728626176\/eOWzoXq5.jpeg",
      "display_url" : "pbs.twimg.com\/profile_images\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816298060716318720",
  "text" : "Every time I have to google an image of Thomas Kuhn for a talk I\u2019m tempted to use this one. \uD83D\uDE02 https:\/\/t.co\/zeL08S8fgG",
  "id" : 816298060716318720,
  "created_at" : "2017-01-03 14:59:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/tiV7FzJjQD",
      "expanded_url" : "https:\/\/twitter.com\/WiredUK\/status\/816198918086066176",
      "display_url" : "twitter.com\/WiredUK\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06094120314039, 8.818778934510203 ]
  },
  "id_str" : "816295214138687488",
  "text" : "Spoiler: no it isn\u2019t, everyone who tells you differently is selling you snake oil. \uD83D\uDC0D\uD83C\uDFFA\uD83E\uDD26\u200D\u2640\uFE0F\uD83E\uDD37\u200D\u2640\uFE0F https:\/\/t.co\/tiV7FzJjQD",
  "id" : 816295214138687488,
  "created_at" : "2017-01-03 14:48:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Silvester Klement",
      "screen_name" : "silvestah",
      "indices" : [ 0, 10 ],
      "id_str" : "29628515",
      "id" : 29628515
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 11, 22 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/mZXhs3ujiy",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=bLE7zsJk4AI",
      "display_url" : "m.youtube.com\/watch?v=bLE7zs\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "814814100949757953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06761320405646, 8.801379706718773 ]
  },
  "id_str" : "816292630137110528",
  "in_reply_to_user_id" : 29628515,
  "text" : "@silvestah @plaetzchen #9 wird dann \u201CPhilipmitdoppelp\u201D https:\/\/t.co\/mZXhs3ujiy",
  "id" : 816292630137110528,
  "in_reply_to_status_id" : 814814100949757953,
  "created_at" : "2017-01-03 14:38:23 +0000",
  "in_reply_to_screen_name" : "silvestah",
  "in_reply_to_user_id_str" : "29628515",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 3, 17 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 32, 47 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 51, 66 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816273999558754304",
  "text" : "RT @annakrystalli: Working with @MozillaScience on @MozOpenLeaders program was one of the best years ever! An opportunity not to miss! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla Science Lab",
        "screen_name" : "MozillaScience",
        "indices" : [ 13, 28 ],
        "id_str" : "1428575976",
        "id" : 1428575976
      }, {
        "name" : "Mozilla Open Leaders",
        "screen_name" : "MozOpenLeaders",
        "indices" : [ 32, 47 ],
        "id_str" : "791070237949034496",
        "id" : 791070237949034496
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/QMl9Wg2ufr",
        "expanded_url" : "https:\/\/goo.gl\/9bA3tE",
        "display_url" : "goo.gl\/9bA3tE"
      } ]
    },
    "geo" : { },
    "id_str" : "816273335046828032",
    "text" : "Working with @MozillaScience on @MozOpenLeaders program was one of the best years ever! An opportunity not to miss! https:\/\/t.co\/QMl9Wg2ufr",
    "id" : 816273335046828032,
    "created_at" : "2017-01-03 13:21:43 +0000",
    "user" : {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "protected" : false,
      "id_str" : "15090415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871473821446025216\/VfW1yVvV_normal.jpg",
      "id" : 15090415,
      "verified" : false
    }
  },
  "id" : 816273999558754304,
  "created_at" : "2017-01-03 13:24:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/816265603199762432\/photo\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/rE0EJudw6n",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C1P1OujW8AE37l3.jpg",
      "id_str" : "816265590847500289",
      "id" : 816265590847500289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C1P1OujW8AE37l3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/rE0EJudw6n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816264443474706433",
  "geo" : { },
  "id_str" : "816265603199762432",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon https:\/\/t.co\/rE0EJudw6n",
  "id" : 816265603199762432,
  "in_reply_to_status_id" : 816264443474706433,
  "created_at" : "2017-01-03 12:50:59 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816263670019878912",
  "geo" : { },
  "id_str" : "816263809002258432",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon und jeder Hike zwischen den beiden wird dann zum Wanderhoden, perfekt. \uD83D\uDC4D",
  "id" : 816263809002258432,
  "in_reply_to_status_id" : 816263670019878912,
  "created_at" : "2017-01-03 12:43:52 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816244328867696640",
  "geo" : { },
  "id_str" : "816263351605018624",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon und mein Hirn versucht krampfhaft nicht in \u201Ehihihi, ausser Hoden\u201C zu verfallen. \uD83D\uDE44",
  "id" : 816263351605018624,
  "in_reply_to_status_id" : 816244328867696640,
  "created_at" : "2017-01-03 12:42:03 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RGSoC 2017",
      "screen_name" : "RailsGirlsSoC",
      "indices" : [ 3, 17 ],
      "id_str" : "1370240701",
      "id" : 1370240701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816260795944280064",
  "text" : "RT @RailsGirlsSoC: \uD83C\uDF89 Are you ready for RGSoC 2017? We are! OSS Project Submissions are now OPEN until Jan 31st!\nApply here \uD83D\uDC49 https:\/\/t.co\/x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RailsGirlsSoC\/status\/804328063794343936\/photo\/1",
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/VOhLJK7gRJ",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CymKhV3XgAgE_He.jpg",
        "id_str" : "804326313872031752",
        "id" : 804326313872031752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CymKhV3XgAgE_He.jpg",
        "sizes" : [ {
          "h" : 394,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/VOhLJK7gRJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/xT0bjfr0ga",
        "expanded_url" : "http:\/\/www.railsgirlssummerofcode.org\/blog\/2016-12-01-rgsoc-2017-project-submissions-open",
        "display_url" : "railsgirlssummerofcode.org\/blog\/2016-12-0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "804328063794343936",
    "text" : "\uD83C\uDF89 Are you ready for RGSoC 2017? We are! OSS Project Submissions are now OPEN until Jan 31st!\nApply here \uD83D\uDC49 https:\/\/t.co\/xT0bjfr0ga https:\/\/t.co\/VOhLJK7gRJ",
    "id" : 804328063794343936,
    "created_at" : "2016-12-01 14:15:28 +0000",
    "user" : {
      "name" : "RGSoC 2017",
      "screen_name" : "RailsGirlsSoC",
      "protected" : false,
      "id_str" : "1370240701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3767942211\/5d122cdf7e08a30ab07180cf92122cbc_normal.png",
      "id" : 1370240701,
      "verified" : false
    }
  },
  "id" : 816260795944280064,
  "created_at" : "2017-01-03 12:31:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/OprjH129UP",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
      "display_url" : "patreon.com\/openSNP"
    } ]
  },
  "in_reply_to_status_id_str" : "815914713657786368",
  "geo" : { },
  "id_str" : "816236483547906048",
  "in_reply_to_user_id" : 14286491,
  "text" : "Since January 1st openSNP is again a fully community-financed project. Consider chipping in a buck per month at https:\/\/t.co\/OprjH129UP",
  "id" : 816236483547906048,
  "in_reply_to_status_id" : 815914713657786368,
  "created_at" : "2017-01-03 10:55:17 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 3, 17 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Melissa Haendel",
      "screen_name" : "ontowonka",
      "indices" : [ 93, 103 ],
      "id_str" : "777135943",
      "id" : 777135943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/9c1ZfguV3e",
      "expanded_url" : "https:\/\/www.force11.org\/blog\/musings-about-open-science-prize",
      "display_url" : "force11.org\/blog\/musings-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816234221324869632",
  "text" : "RT @CameronNeylon: Thinking about how to evaluate the openness of projects. Great stuff from @ontowonka \n\nhttps:\/\/t.co\/9c1ZfguV3e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Melissa Haendel",
        "screen_name" : "ontowonka",
        "indices" : [ 74, 84 ],
        "id_str" : "777135943",
        "id" : 777135943
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/9c1ZfguV3e",
        "expanded_url" : "https:\/\/www.force11.org\/blog\/musings-about-open-science-prize",
        "display_url" : "force11.org\/blog\/musings-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "815912888242229248",
    "text" : "Thinking about how to evaluate the openness of projects. Great stuff from @ontowonka \n\nhttps:\/\/t.co\/9c1ZfguV3e",
    "id" : 815912888242229248,
    "created_at" : "2017-01-02 13:29:26 +0000",
    "user" : {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "protected" : false,
      "id_str" : "12984852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1766127492\/image1326973990_normal.png",
      "id" : 12984852,
      "verified" : false
    }
  },
  "id" : 816234221324869632,
  "created_at" : "2017-01-03 10:46:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/X9Lq1fiHos",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.2000933",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816228927089872896",
  "text" : "Languages Are Still a Major Barrier to Global Science. https:\/\/t.co\/X9Lq1fiHos",
  "id" : 816228927089872896,
  "created_at" : "2017-01-03 10:25:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/xjqedYZamN",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/monty-hall-problems",
      "display_url" : "smbc-comics.com\/comic\/monty-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816228073850998784",
  "text" : "That explains why I sleep rather uneasy these days! https:\/\/t.co\/xjqedYZamN",
  "id" : 816228073850998784,
  "created_at" : "2017-01-03 10:21:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816210250399444993",
  "text" : "Speak of adding insult to injury. The uni decided to turn off the water for the people who\u2019re already back in the office\u2026 \uD83D\uDC4D",
  "id" : 816210250399444993,
  "created_at" : "2017-01-03 09:11:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/816052127592312833\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/m78LLBGMUd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C1MzEyqW8AAf-b7.jpg",
      "id_str" : "816052114896121856",
      "id" : 816052114896121856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1MzEyqW8AAf-b7.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/m78LLBGMUd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/veT2YMxAV8",
      "expanded_url" : "https:\/\/www.goodreads.com\/user_challenges\/7273215",
      "display_url" : "goodreads.com\/user_challenge\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088379309518, 8.818719852723943 ]
  },
  "id_str" : "816052127592312833",
  "text" : "Let\u2019s start this year\u2019s reading challenge with some required reading for our times\u2026 https:\/\/t.co\/veT2YMxAV8 https:\/\/t.co\/m78LLBGMUd",
  "id" : 816052127592312833,
  "created_at" : "2017-01-02 22:42:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "indices" : [ 3, 12 ],
      "id_str" : "19530289",
      "id" : 19530289
    }, {
      "name" : "John Scalzi",
      "screen_name" : "scalzi",
      "indices" : [ 80, 87 ],
      "id_str" : "14202817",
      "id" : 14202817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/FhOIG3VHGq",
      "expanded_url" : "http:\/\/whatever.scalzi.com\/2017\/01\/01\/the-new-year-and-the-bend-of-the-arc\/",
      "display_url" : "whatever.scalzi.com\/2017\/01\/01\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816044194896678912",
  "text" : "RT @PennyRed: The arc of the universe bends towards justice, but not by itself. @scalzi saying true things. https:\/\/t.co\/FhOIG3VHGq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Scalzi",
        "screen_name" : "scalzi",
        "indices" : [ 66, 73 ],
        "id_str" : "14202817",
        "id" : 14202817
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/FhOIG3VHGq",
        "expanded_url" : "http:\/\/whatever.scalzi.com\/2017\/01\/01\/the-new-year-and-the-bend-of-the-arc\/",
        "display_url" : "whatever.scalzi.com\/2017\/01\/01\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "815972169868001280",
    "text" : "The arc of the universe bends towards justice, but not by itself. @scalzi saying true things. https:\/\/t.co\/FhOIG3VHGq",
    "id" : 815972169868001280,
    "created_at" : "2017-01-02 17:24:59 +0000",
    "user" : {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "protected" : false,
      "id_str" : "19530289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887966692877504512\/hrvuIg4n_normal.jpg",
      "id" : 19530289,
      "verified" : true
    }
  },
  "id" : 816044194896678912,
  "created_at" : "2017-01-02 22:11:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816028530941296640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06079956986041, 8.81868676860885 ]
  },
  "id_str" : "816028953580343300",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute so let\u2019s rather do open science \uD83D\uDD2C when moving you out :D",
  "id" : 816028953580343300,
  "in_reply_to_status_id" : 816028530941296640,
  "created_at" : "2017-01-02 21:10:38 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816027803397353474",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086123839627, 8.81871406336896 ]
  },
  "id_str" : "816028352549126144",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute yeah, but not really willing to come to an event where actually doing open science takes the backseat to old dudes talking. :(",
  "id" : 816028352549126144,
  "in_reply_to_status_id" : 816027803397353474,
  "created_at" : "2017-01-02 21:08:14 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/d6PSJEwR62",
      "expanded_url" : "https:\/\/twitter.com\/undarkmag\/status\/815956840194408448",
      "display_url" : "twitter.com\/undarkmag\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0607383199948, 8.818818523890942 ]
  },
  "id_str" : "816007130155249664",
  "text" : "This so closely resembles the same issues around species going extinct! https:\/\/t.co\/d6PSJEwR62",
  "id" : 816007130155249664,
  "created_at" : "2017-01-02 19:43:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815981397043277828",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06079105791814, 8.818642490542599 ]
  },
  "id_str" : "815998979242598401",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute probably not. I mean: that looks like it\u2019s only settled professors?!",
  "id" : 815998979242598401,
  "in_reply_to_status_id" : 815981397043277828,
  "created_at" : "2017-01-02 19:11:31 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815972110111834113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05966569133962, 8.8169978103755 ]
  },
  "id_str" : "815979200939233281",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute what\u2019s that?",
  "id" : 815979200939233281,
  "in_reply_to_status_id" : 815972110111834113,
  "created_at" : "2017-01-02 17:52:56 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/10q5ALk2kc",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/4715-correlating-the-sci-hub-data-with-world-bank-indicators-and-identifying-academic-use",
      "display_url" : "thewinnower.com\/papers\/4715-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "815943892696760321",
  "text" : "Interesting: Seems the increasing boycott of Elsevier is sparking new interest in my analysis of the Sci-Hub usage. https:\/\/t.co\/10q5ALk2kc",
  "id" : 815943892696760321,
  "created_at" : "2017-01-02 15:32:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 28, 33 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/HrBRjIbfAY",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/814814369989136384",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "815940558896173056",
  "text" : "\uD83D\uDC4D for the mention of Fleck. @li5a might be something for you! https:\/\/t.co\/HrBRjIbfAY",
  "id" : 815940558896173056,
  "created_at" : "2017-01-02 15:19:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815915917494210560",
  "geo" : { },
  "id_str" : "815917118759768064",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch group high fives! \uD83D\uDE4F",
  "id" : 815917118759768064,
  "in_reply_to_status_id" : 815915917494210560,
  "created_at" : "2017-01-02 13:46:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Qp8xYCPFTs",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/815914713657786368",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "815914713657786368",
  "geo" : { },
  "id_str" : "815916866279538689",
  "in_reply_to_user_id" : 14286491,
  "text" : "My guesstimate is that in ~12 months we\u2019ll have more members than the German Pirate Party. \uD83D\uDE02\uD83D\uDE1B https:\/\/t.co\/Qp8xYCPFTs",
  "id" : 815916866279538689,
  "in_reply_to_status_id" : 815914713657786368,
  "created_at" : "2017-01-02 13:45:14 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 83, 96 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 97, 109 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/pfh4D2U2YU",
      "expanded_url" : "https:\/\/opensnp.org\/statistics",
      "display_url" : "opensnp.org\/statistics"
    } ]
  },
  "geo" : { },
  "id_str" : "815914713657786368",
  "text" : "Guess which project passed it\u2019s 3000th genotyping on 2016-11-17 and missed it! \uD83C\uDF89\uD83C\uDF86\uD83C\uDF88 @PhilippBayer @helgerausch https:\/\/t.co\/pfh4D2U2YU",
  "id" : 815914713657786368,
  "created_at" : "2017-01-02 13:36:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/3d7JpwuuEA",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BOwtsI_DVou\/",
      "display_url" : "instagram.com\/p\/BOwtsI_DVou\/"
    } ]
  },
  "geo" : { },
  "id_str" : "815890022578655233",
  "text" : "And there goes the snow https:\/\/t.co\/3d7JpwuuEA",
  "id" : 815890022578655233,
  "created_at" : "2017-01-02 11:58:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "Christine Bryant-Ryback \uD83C\uDF42",
      "screen_name" : "hootbot",
      "indices" : [ 16, 24 ],
      "id_str" : "15574998",
      "id" : 15574998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815761245257289728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233758480908, 8.627634933156367 ]
  },
  "id_str" : "815888436863401984",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski @hootbot omg, that\u2019s so cool. \uD83D\uDE0D",
  "id" : 815888436863401984,
  "in_reply_to_status_id" : 815761245257289728,
  "created_at" : "2017-01-02 11:52:16 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233668907079, 8.627634242170586 ]
  },
  "id_str" : "815870984993513472",
  "text" : "According to RescueTime my productivity increased \u201C2900% from day before\u201D. And what can I say, I did leave my bed after all.",
  "id" : 815870984993513472,
  "created_at" : "2017-01-02 10:42:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/ltTExyzmsk",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/815648409675767808",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "815856947278790656",
  "text" : "And there goes my year too. Well done my friends! https:\/\/t.co\/ltTExyzmsk",
  "id" : 815856947278790656,
  "created_at" : "2017-01-02 09:47:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/815841820177469440\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/CHqvcwV3rI",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C1JzzkBXgAAtH3Z.jpg",
      "id_str" : "815841812187414528",
      "id" : 815841812187414528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C1JzzkBXgAAtH3Z.jpg",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/CHqvcwV3rI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815841820177469440",
  "text" : "The view from my office today https:\/\/t.co\/CHqvcwV3rI",
  "id" : 815841820177469440,
  "created_at" : "2017-01-02 08:47:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 0, 10 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815597520139251712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403928575583, 8.753421388635779 ]
  },
  "id_str" : "815598004807860224",
  "in_reply_to_user_id" : 347340056,
  "text" : "@vortacist \u201CMy 2017 will be sure that I\u2019ll try and get you a new book.\u201D That sounds about right.",
  "id" : 815598004807860224,
  "in_reply_to_status_id" : 815597520139251712,
  "created_at" : "2017-01-01 16:38:12 +0000",
  "in_reply_to_screen_name" : "vortacist",
  "in_reply_to_user_id_str" : "347340056",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina",
      "screen_name" : "trotzdemda",
      "indices" : [ 0, 11 ],
      "id_str" : "339564605",
      "id" : 339564605
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 19, 28 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815575888041570306",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403686782648, 8.753436985683935 ]
  },
  "id_str" : "815576156590239744",
  "in_reply_to_user_id" : 339564605,
  "text" : "@trotzdemda @Lobot @Senficon makes great \uD83E\uDD5E! \uD83D\uDC69\u200D\uD83C\uDF73",
  "id" : 815576156590239744,
  "in_reply_to_status_id" : 815575888041570306,
  "created_at" : "2017-01-01 15:11:23 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Tina",
      "screen_name" : "trotzdemda",
      "indices" : [ 21, 32 ],
      "id_str" : "339564605",
      "id" : 339564605
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 33, 42 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815573922196426753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140423056127, 8.753441070075988 ]
  },
  "id_str" : "815575547656937472",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i don\u2019t know! @trotzdemda @Senficon? :p",
  "id" : 815575547656937472,
  "in_reply_to_status_id" : 815573922196426753,
  "created_at" : "2017-01-01 15:08:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403973935791, 8.753416011862981 ]
  },
  "id_str" : "815551425984036865",
  "text" : "Cooking \uD83E\uDD5E with a \u201Cfoods before dudes\u201D-spatula. That\u2019s a good start. \uD83C\uDF89\uD83D\uDC96",
  "id" : 815551425984036865,
  "created_at" : "2017-01-01 13:33:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815534991610417152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403885652862, 8.753421453052406 ]
  },
  "id_str" : "815543461923483649",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks thanks for all the support, it\u2019s much appreciated. And a happy new year! \uD83C\uDF86\uD83D\uDC96\uD83D\uDE18\uD83C\uDF89",
  "id" : 815543461923483649,
  "in_reply_to_status_id" : 815534991610417152,
  "created_at" : "2017-01-01 13:01:28 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]
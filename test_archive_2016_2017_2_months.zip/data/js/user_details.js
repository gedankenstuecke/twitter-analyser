var user_details =  {
  "screen_name" : "gedankenstuecke",
  "location" : "Berkeley, CA, USA",
  "full_name" : "Bastian Greshake Tzovaras",
  "bio" : "Co-Founder @openSNPorg. Director of Research @OpenHumansOrg. Nearly a PhD in #bioinformatics (Ecology|Evolution|Genomics).  Loves open(science|culture|.*)",
  "id" : "14286491",
  "created_at" : "2008-04-02 19:12:51 +0000"
}